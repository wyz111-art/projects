"""Parse the 56 official Excel exports into tidy monthly interim CSVs."""

from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import MONTHLY_RAW, MONTHLY_INTERIM  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

EXPORT = MONTHLY_RAW / "export"
MONTH_PAT = re.compile(r"^(\d{4})年(\d{1,2})月$")

IND_NAME = {"M0101": "规模以上工业增加值", "M0201": "规模以上服务业营业收入",
            "M0301": "固定资产投资", "M0401": "社会消费品零售总额"}


def parse_sheet(path: Path) -> list[dict]:
    wb = load_workbook(path, read_only=True, data_only=True)
    ws = wb[wb.sheetnames[0]]
    grid = [[c for c in row] for row in ws.iter_rows(values_only=True)]
    wb.close()
    grid = [r for r in grid if any(c is not None and str(c).strip() for c in r)]
    if not grid:
        return []
    meta_region = meta_time = ""
    for r in grid[:3]:
        txt = str(r[0] or "")
        if txt.startswith("地区："):
            meta_region = txt.split("：", 1)[1].strip()
        elif txt.startswith("时间："):
            meta_time = txt.split("：", 1)[1].strip()
    head_idx = next((i for i, r in enumerate(grid)
                     if any(str(c or "").find("增长") >= 0 for c in r)), None)
    if head_idx is None:
        return []
    headers = []
    for c in grid[head_idx]:
        t = re.sub(r"\s+", "", str(c or ""))
        headers.append(t)
    out = []
    for r in grid[head_idx + 1:]:
        label = str(r[0] or "").strip()
        m = MONTH_PAT.match(label)
        if not m:
            continue
        month = f"{m.group(1)}-{int(m.group(2)):02d}"
        for ci in range(1, len(headers)):
            h = headers[ci]
            if not h:
                continue
            val = r[ci] if ci < len(r) else None
            if val is None or str(val).strip() == "":
                continue
            name = h.split("_", 1)[1] if "_" in h else h
            um = re.search(r"\((.+)\)$", name)
            unit = um.group(1) if um else ""
            sub = name[:um.start()] if um else name
            out.append({"地区": meta_region, "统计月份": month,
                        "子指标名称": sub, "单位": unit, "数值": str(val).strip(),
                        "导出时间选择": meta_time})
    return out


def main() -> None:
    files = sorted(EXPORT.glob("djsyd_*_202308-202607.xlsx"))
    print(f"导出文件: {len(files)}")
    allrows: list[dict] = []
    summary = []
    for f in files:
        stem = f.stem  # djsyd_M0101_GX3200_202308-202607
        _, ind, reg, _ = stem.split("_")
        rows = parse_sheet(f)
        months = sorted({r["统计月份"] for r in rows})
        for r in rows:
            r["指标代码"] = ind
            r["指标名称"] = IND_NAME.get(ind, ind)
            r["地区代码"] = reg
        allrows += rows
        meta_region = rows[0]["地区"] if rows else ""
        summary.append({"文件": f.name, "指标代码": ind, "地区代码": reg,
                        "表内地区": meta_region, "月份数": len(months),
                        "最早月份": months[0] if months else "",
                        "最晚月份": months[-1] if months else "",
                        "数据行数": len(rows)})
        print(f"  {ind} {reg}: {len(months)} 月 / {len(rows)} 行")
    fields = ["指标代码", "指标名称", "地区代码", "地区", "统计月份",
              "子指标名称", "单位", "数值", "导出时间选择"]
    with (MONTHLY_INTERIM / "monthly_export_long.csv").open(
            "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for r in allrows:
            w.writerow({k: r.get(k, "") for k in fields})
    with (MONTHLY_INTERIM / "monthly_export_index.csv").open(
            "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(summary[0].keys()))
        w.writeheader()
        w.writerows(summary)
    print(f"{len(allrows)} rows -> monthly_export_long.csv")


if __name__ == "__main__":
    main()
