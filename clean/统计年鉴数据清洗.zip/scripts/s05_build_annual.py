"""Build annual/integrated/annual_city_attributes.csv from the interim tables.

Priority rules (fixed in the agreed plan):
  * population / urbanisation  -> newest edition's cross-year table 3-6
  * GDP, industry shares, per-capita GDP -> newest yearbook edition that
    contains the year (i.e. the latest revised series), then older editions
  * green indicators -> the edition whose data year matches (single-year table)
  * 2025 -> platform quarterly dataset only (preliminary accounting)
"""

from __future__ import annotations

import csv
import html as htmllib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_INTERIM, ANNUAL_INTEGRATED, DOCS, fetch, save_raw  # noqa: E402

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)

CITY_BASE = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
             "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]
CITY_ROWS = [c + "市" for c in CITY_BASE]
REGION_ROWS = ["苏南", "苏中", "苏北"]
CODE = {c + "市": f"GX32{i+1:02d}" for i, c in enumerate(CITY_BASE)}
CODE["全省"] = "GX3200"

YEARS = [str(y) for y in range(2014, 2026)]

INDICATORS = [
    ("POP_YE", "年末常住人口", "万人", "全市域"),
    ("GDP", "地区生产总值", "亿元", "全市域"),
    ("GDP_P2_SHARE", "第二产业增加值占GDP比重", "%", "全市域"),
    ("GDP_P3_SHARE", "第三产业增加值占GDP比重", "%", "全市域"),
    ("GDP_PC", "人均地区生产总值", "元", "全市域"),
    ("GREEN_COVER_RATE", "建成区绿化覆盖率", "%", "市区（市辖区）"),
    ("BUILTUP_AREA", "建成区面积", "平方公里", "市区（市辖区）"),
    ("PARK_GREEN_PC", "人均公园绿地面积", "平方米", "市区（市辖区）"),
    ("URBANIZATION", "城镇化率", "%", "全市域"),
]

FIELDS = ["层级", "地区", "地区代码", "指标代码", "指标名称", "统计年份", "数值",
          "单位", "空间口径", "值类型", "年鉴版本", "是否修订版", "数据来源",
          "来源类型", "原始链接", "状态", "备注"]


def norm_panel(name: str) -> str:
    """Strip the English tail / unit suffix that older and newer editions add."""
    s = name or ""
    m = re.match(r"^[\s\u3000]*([\u4e00-\u9fff（）\s\u3000]+)", s)
    if m:
        s = re.sub(r"[\s\u3000]+", "", m.group(1))
    return re.sub(r"（元）$", "", s)


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def load(name: str) -> list[dict]:
    path = ANNUAL_INTERIM / name
    if not path.exists():
        return []
    return list(csv.DictReader(path.open(encoding="utf-8-sig")))


def url_map() -> dict[str, str]:
    manifest = DOCS / "raw_manifest.json"
    out: dict[str, str] = {}
    if manifest.exists():
        for e in json.loads(manifest.read_text(encoding="utf-8")):
            note = e.get("note") or ""
            if note and note not in out:
                out[note] = e["url"]
    return out


def layer(region: str) -> str:
    if region == "全省":
        return "全省"
    if region in REGION_ROWS:
        return "区域"
    return "设区市"


# ------------------------------------------------------------------ province 2-1
def fetch_province_gdp() -> list[dict]:
    """2-1 主要年份地区生产总值 -> province GDP with three industries."""
    url = "http://tj.jiangsu.gov.cn/2025/nj02/nj0201.htm"
    res = fetch(url)
    if res["status"] != 200:
        return []
    save_raw(ANNUAL_INTERNAL_RAW := (ANNUAL_INTERIM.parent / "raw" / "yearbook" / "2025"
                                     / "2-1_主要年份地区生产总值.html"),
             res["content"], url, bool(res.get("reused")), note="2-1 主要年份地区生产总值")
    out = []
    for r in (cells(x) for x in TR.findall(res["text"])):
        if len(r) >= 5 and re.match(r"^(19|20)\d\d$", r[0]):
            for idx, code in ((1, "GDP"), (2, "P1"), (3, "P2"), (4, "P3")):
                if idx < len(r):
                    out.append({"年份": r[0], "指标": code, "数值": r[idx].replace(",", "")})
    return out


def main() -> None:
    urls = url_map()
    rows: list[dict] = []

    def emit(region, code, name, unit, scope, year, value, yb, revised,
             source, source_type, url, note="", vtype="官方发布"):
        rows.append({
            "层级": layer(region), "地区": region,
            "地区代码": CODE.get(region, ""), "指标代码": code,
            "指标名称": name, "统计年份": year, "数值": value, "单位": unit,
            "空间口径": scope, "值类型": vtype, "年鉴版本": yb,
            "是否修订版": revised, "数据来源": source, "来源类型": source_type,
            "原始链接": url,
            "状态": "已确认有数据" if value not in ("", None) else "未找到",
            "备注": note})

    # ---------------- population & urbanisation (cross-year table 3-6) -------
    pop = load("yb2025_population.csv")
    panel_pop = "总人口(万人)TotalPopulation （10000 persons）"
    panel_urb = "城镇人口比重(%)Proportion of Urban Population（%）"
    src_pop = "《江苏统计年鉴2025》表3-6 按地区分常住人口（跨年修订序列）"
    url_pop = urls.get("3-6 按地区分常住人口", "http://tj.jiangsu.gov.cn/2025/nj03/nj0306.htm")
    for r in pop:
        if r["年份"] not in YEARS:
            continue
        if r["面板"] == panel_pop:
            emit(r["地区"], "POP_YE", "年末常住人口", "万人", "全市域",
                 r["年份"], r["数值"], "2025", "是", src_pop, "官方统计年鉴",
                 url_pop, "跨年修订序列，反映最新修订结果")
        elif r["面板"] == panel_urb:
            emit(r["地区"], "URBANIZATION", "城镇化率", "%", "全市域",
                 r["年份"], r["数值"], "2025", "是", src_pop, "官方统计年鉴",
                 url_pop, "官方发布的城镇人口比重")

    # ---------------- GDP family: yearbook cross-year tables -----------------
    gdp_files = [("yb2025_gdp.csv", 2025), ("yb_older_gdp.csv", None)]
    best: dict[tuple, dict] = {}
    for fname, fixed_ver in gdp_files:
        for r in load(fname):
            ver = int(r["年鉴版本"])
            key = (norm_panel(r["面板"]), r["年份"], r["地区"])
            cur = best.get(key)
            if cur is None or int(cur["年鉴版本"]) < ver:
                best[key] = r
    PANEL2CODE = {"地区生产总值": "GDP", "人均地区生产总值": "GDP_PC",
                  "第一产业增加值": "P1", "第二产业增加值": "P2",
                  "第三产业增加值": "P3"}
    unit_of = {"GDP": "亿元", "GDP_PC": "元",
               "P1": "亿元", "P2": "亿元", "P3": "亿元"}
    NAME_OF = {c: n for c, n, _, _ in INDICATORS}
    NAME_OF.update({"P1": "第一产业增加值", "P2": "第二产业增加值",
                    "P3": "第三产业增加值"})
    for (panel, year, region), r in best.items():
        if year not in YEARS or panel not in PANEL2CODE:
            continue
        code = PANEL2CODE[panel]
        emit(region, code, NAME_OF[code],
             unit_of[code], "全市域", year, r["数值"], r["年鉴版本"], "是",
             f"《江苏统计年鉴{r['年鉴版本']}》{r['表名']}（跨年修订序列）",
             "官方统计年鉴", urls.get(r["表名"], ""),
             "取自最新版年鉴；未修订的早期单年值不参与")

    comp = {}
    for fname in ("yb2025_gdp_composition.csv", "yb_older_gdp_composition.csv"):
        for r in load(fname):
            ver = int(r["年鉴版本"])
            key = (norm_panel(r["面板"]), r["年份"], r["地区"])
            if key not in comp or int(comp[key]["年鉴版本"]) < ver:
                comp[key] = r
    P2P3 = {"第二产业增加值": ("GDP_P2_SHARE", "第二产业增加值占GDP比重"),
            "第三产业增加值": ("GDP_P3_SHARE", "第三产业增加值占GDP比重")}
    for (panel, year, region), r in comp.items():
        if year not in YEARS or panel not in P2P3:
            continue
        code, name = P2P3[panel]
        emit(region, code, name, "%", "全市域", year, r["数值"], r["年鉴版本"],
             "是", f"《江苏统计年鉴{r['年鉴版本']}》{r['表名']}（跨年修订序列）",
             "官方统计年鉴", urls.get(r["表名"], ""), "官方发布的结构比重")

    # ---------------- province GDP series (table 2-1) ------------------------
    prov = fetch_province_gdp()
    pcode = {"GDP": ("GDP", "地区生产总值", "亿元"),
             "P1": ("P1", "第一产业增加值", "亿元"),
             "P2": ("P2", "第二产业增加值", "亿元"),
             "P3": ("P3", "第三产业增加值", "亿元")}
    P1_ALL = {}
    prov_gdp = {}
    for r in prov:
        if r["年份"] in YEARS:
            code, name, unit = pcode[r["指标"]]
            P1_ALL[(r["年份"], code)] = r["数值"]
            if code == "GDP":
                prov_gdp[r["年份"]] = r["数值"]
            emit("全省", code, name, unit, "全市域", r["年份"], r["数值"], "2025",
                 "是", "《江苏统计年鉴2025》表2-1 主要年份地区生产总值",
                 "官方统计年鉴",
                 "http://tj.jiangsu.gov.cn/2025/nj02/nj0201.htm",
                 "全省口径，来自省级主要年份序列表")
    for year in YEARS:
        g = P1_ALL.get((year, "GDP"), "")
        for code_in, code_out, name in (("P2", "GDP_P2_SHARE", "第二产业增加值占GDP比重"),
                                        ("P3", "GDP_P3_SHARE", "第三产业增加值占GDP比重")):
            p = P1_ALL.get((year, code_in), "")
            if g and p:
                try:
                    v = f"{float(p) / float(g) * 100:.1f}"
                except (ValueError, ZeroDivisionError):
                    v = ""
                emit("全省", code_out, name, "%", "全市域", year, v, "2025", "是",
                     "由《江苏统计年鉴2025》表2-1 官方增加值计算", "官方统计年鉴",
                     "http://tj.jiangsu.gov.cn/2025/nj02/nj0201.htm",
                     "计算值＝第二/三产业增加值÷地区生产总值×100", vtype="计算值")

    # ---------------- green indicators (single-year tables) ------------------
    green_rows = load("yb2025_green.csv") + load("yb_older_green.csv")
    GC = {"GREEN_COVER_RATE": ("建成区绿化覆盖率", "%"),
          "BUILTUP_AREA": ("建成区面积", "平方公里"),
          "PARK_GREEN_PC": ("人均公园绿地面积", "平方米")}
    for r in green_rows:
        if r["年份"] not in YEARS or r["指标代码"] not in GC:
            continue
        name, unit = GC[r["指标代码"]]
        emit(r["地区"], r["指标代码"], name, unit, "市区（市辖区）", r["年份"],
             r["数值"], r["年鉴版本"], "否",
             f"《江苏统计年鉴{r['年鉴版本']}》{r['表名']}", "官方统计年鉴",
             urls.get(r["表名"], ""), "单年表口径，年鉴未再修订；市区（市辖区）范围")

    # ---------------- 2025 from the platform quarterly dataset ---------------
    q = [r for r in load("platform_djsjd_gdp.csv") if r["统计期"] == "202512"]
    qmap = {(r["地区"], r["指标代码"]): r["数值"] for r in q}
    srcq = "江苏省统计局统计数据平台·设区市季度（djsjd，2025年第四季度累计）"
    urlq = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0202"
    QI = {"Q010102": ("GDP", "地区生产总值", "亿元"),
          "Q010103": ("GDP_GROWTH", "地区生产总值增速", "%"),
          "Q010104": ("P1", "第一产业增加值", "亿元"),
          "Q010106": ("P2", "第二产业增加值", "亿元"),
          "Q010108": ("P3", "第三产业增加值", "亿元")}
    for (region, code), val in sorted(qmap.items()):
        if code not in QI:
            continue
        c, name, unit = QI[code]
        emit(region, c, name, unit, "全市域", "2025", val, "—", "否", srcq,
             "官方数据平台", urlq,
             "2025年第四季度累计值＝全年；平台为初步核算数，未经最终核实")
    for region in sorted({r["地区"] for r in q}):
        g = qmap.get((region, "Q010102"))
        p2 = qmap.get((region, "Q010106"))
        p3 = qmap.get((region, "Q010108"))
        for p, code, name in ((p2, "GDP_P2_SHARE", "第二产业增加值占GDP比重"),
                              (p3, "GDP_P3_SHARE", "第三产业增加值占GDP比重")):
            if g and p:
                try:
                    v = f"{float(p) / float(g) * 100:.1f}"
                except (ValueError, ZeroDivisionError):
                    v = ""
                emit(region, code, name, "%", "全市域", "2025", v, "—", "否",
                     srcq + "（由官方增加值与GDP计算）", "官方数据平台", urlq,
                     "计算值；与《2025年常州市统计公报》公布的46.2/52.2一致",
                     vtype="计算值")

    # ---------------- fill the expected grid with explicit status ------------
    have = {(r["地区"], r["指标代码"], r["统计年份"]) for r in rows}
    regions = ["全省"] + CITY_ROWS + REGION_ROWS
    for region in regions:
        for code, name, unit, scope in INDICATORS:
            for year in YEARS:
                if (region, code, year) in have:
                    continue
                if code in GC and region not in CITY_ROWS:
                    status, note = "未找到", "年鉴18篇城市园林绿化表仅覆盖13个市区，无省级/区域口径"
                elif region in REGION_ROWS and year == "2025":
                    status, note = "未找到", "平台季度数据集不含苏南/苏中/苏北汇总"
                elif region == "全省" and code in ("GDP_PC", "GREEN_COVER_RATE",
                                                   "BUILTUP_AREA", "PARK_GREEN_PC") and year < "2020":
                    status, note = "未找到", "该指标省级序列在本项目已采集来源中不可得"
                else:
                    status, note = "未找到", "已核查本项目采集的全部官方来源，无该值"
                emit(region, code, name, unit, scope, year, "", "", "", "", "", "",
                     note)
                rows[-1]["状态"] = status
                rows[-1]["值类型"] = ""

    rows.sort(key=lambda r: (r["指标代码"], r["地区"], r["统计年份"]))
    dest = ANNUAL_INTEGRATED / "annual_city_attributes.csv"
    with dest.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    filled = sum(1 for r in rows if r["状态"] == "已确认有数据")
    print(f"{len(rows)} rows ({filled} with data) -> {dest}")


if __name__ == "__main__":
    main()
