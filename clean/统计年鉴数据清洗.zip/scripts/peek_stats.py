"""Print the annual section of docs/collection_stats.json in a readable table."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
d = json.loads((ROOT / "docs" / "collection_stats.json").read_text(encoding="utf-8"))
print("月度总行数", d["monthly_total_rows"], d["monthly_status"])
print("年度总行数", d["annual_total_rows"], d["annual_status"])
print()
print("年度指标（13 市口径）:")
for r in d["annual_by_indicator"]:
    print(f"  {r['指标代码']:16s} {r['指标名称'][:16]:18s} 记录 {r['13市记录数']:3d}"
          f"  有数据 {r['13市已确认有数据']:3d}  年份 {r['13市覆盖年份']:12s}"
          f"  全表未找到 {r['全表未找到']:3d}")
