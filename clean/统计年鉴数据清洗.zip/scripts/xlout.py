"""CSV -> XLSX mirror writer.

The XLSX file always carries exactly the same cell content as the CSV, which
stays the authoritative version.  Excel limits are checked explicitly instead
of silently truncating.
"""

from __future__ import annotations

import csv
import re
from pathlib import Path

from openpyxl import Workbook
from openpyxl.utils import get_column_letter

MAX_ROWS = 1_048_576
MAX_COLS = 16_384
MAX_CELL_CHARS = 32_767

NUM = re.compile(r"^-?\d+(\.\d+)?$")


def _coerce(s: str):
    if NUM.match(s):
        return float(s) if "." in s else int(s)
    return s


def csv_to_xlsx(csv_path: Path, xlsx_path: Path, sheet_name: str = "data",
                force_text_cols: set[str] | None = None) -> dict:
    rows = list(csv.reader(csv_path.open(encoding="utf-8-sig")))
    if len(rows) > MAX_ROWS:
        raise ValueError(f"{csv_path.name}: {len(rows)} rows exceeds Excel limit")
    if rows and len(rows[0]) > MAX_COLS:
        raise ValueError(f"{csv_path.name}: {len(rows[0])} cols exceeds Excel limit")
    header = rows[0] if rows else []
    text_idx = {i for i, h in enumerate(header)
                if force_text_cols and h in force_text_cols}

    wb = Workbook(write_only=True)
    ws = wb.create_sheet(title=sheet_name[:31])
    truncated = 0
    for r_i, row in enumerate(rows):
        out = []
        for c_i, cell in enumerate(row):
            if len(cell) > MAX_CELL_CHARS:
                cell = cell[:MAX_CELL_CHARS]
                truncated += 1
            out.append(cell if (r_i == 0 or c_i in text_idx) else _coerce(cell))
        ws.append(out)
    wb.save(xlsx_path)
    return {"csv": csv_path.name, "xlsx": xlsx_path.name, "rows": len(rows),
            "cols": len(header), "truncated_cells": truncated}
