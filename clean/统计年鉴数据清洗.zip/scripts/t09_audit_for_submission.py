"""Pre-submission audit of the organised city-attribute data.

Read-only. Writes a machine-readable summary to docs/submission_audit.json and
prints a human-readable digest. Nothing in the data directories is modified.
"""

from __future__ import annotations

import csv
import json
import re
from collections import Counter
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
OUT = ROOT / "docs" / "submission_audit.json"

CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]

# plausible ranges used only to flag suspects for human review
SANITY = {
    "年末常住人口(万人)": (100, 2000),
    "城镇化率(%)": (30, 100),
    "地区生产总值(亿元)": (500, 40000),
    "地区生产总值增速(%)": (-30, 30),
    "第二产业增加值占GDP比重(%)": (10, 80),
    "第三产业增加值占GDP比重(%)": (20, 90),
    "人均地区生产总值(元)": (30000, 400000),
    "建成区绿化覆盖率(%)": (20, 60),
    "建成区面积(平方公里)": (20, 1500),
    "人均公园绿地面积(平方米)": (3, 30),
}


def audit_file(p: Path, freq: str) -> dict:
    raw = p.read_bytes()
    has_bom = raw.startswith(b"\xef\xbb\xbf")
    text = raw.decode("utf-8-sig")
    rows = list(csv.reader(text.splitlines()))
    header, body = rows[0], [r for r in rows[1:] if any(c.strip() for c in r)]
    blank_rows = len(rows) - 1 - len(body)

    df = pd.read_csv(p, dtype=str, keep_default_na=False).fillna("")
    time_col = "年份" if freq == "annual" else "年月"
    ind_cols = [c for c in df.columns
                if c not in ("城市", time_col, "数据来源", "原始链接", "状态说明")]

    # numeric parseability of indicator columns
    non_numeric = {}
    for c in ind_cols:
        vals = df[c][df[c] != ""]
        bad = [v for v in vals if not re.fullmatch(r"-?\d+(\.\d+)?", v)]
        if bad:
            non_numeric[c] = bad[:3]

    num = df[ind_cols].apply(pd.to_numeric, errors="coerce")
    extremes = {}
    for c in ind_cols:
        if c in SANITY and num[c].notna().any():
            lo, hi = SANITY[c]
            out = num[c][(num[c] < lo) | (num[c] > hi)]
            if len(out):
                extremes[c] = {
                    "低于下限": int((out < lo).sum()),
                    "高于上限": int((out > hi).sum()),
                    "示例": [round(v, 2) for v in out.head(3).tolist()],
                }

    return {
        "文件": str(p.relative_to(ROOT)),
        "字节": len(raw),
        "编码": "UTF-8" + ("（含 BOM）" if has_bom else "（无 BOM）"),
        "行数(数据行)": len(body),
        "列数": len(header),
        "字段": header,
        "空白行": blank_rows,
        "城市列取值": sorted(set(df["城市"])) if "城市" in df.columns else [],
        "城市与文件名一致": (set(df["城市"]) == {p.stem}) if "城市" in df.columns else None,
        "时间列": time_col,
        "时间点个数": df[time_col].nunique(),
        "时间最小值": df[time_col].min(),
        "时间最大值": df[time_col].max(),
        "重复时间点": int(df[time_col].duplicated().sum()),
        "完全重复行": int(df.duplicated().sum()),
        "指标列数": len(ind_cols),
        "指标列": ind_cols,
        "缺失单元格": int((df[ind_cols] == "").sum().sum()),
        "总指标单元格": len(df) * len(ind_cols),
        "非数字内容": non_numeric,
        "疑似越界值": extremes,
        "各列缺失": {c: int((df[c] == "").sum()) for c in ind_cols},
    }


def audit_integrated() -> dict:
    out = {}
    for label, path, key in [
        ("年度长表", ROOT / "annual" / "integrated" / "annual_city_attributes.csv",
         ["地区", "指标代码", "统计年份"]),
        ("月度长表", ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv",
         ["地区", "指标名称", "子指标名称", "统计月份"]),
    ]:
        df = pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")
        out[label] = {
            "文件": str(path.relative_to(ROOT)),
            "行数": len(df),
            "列数": len(df.columns),
            "字段": list(df.columns),
            "重复键": int(df.duplicated(key).sum()),
            "空数值行": int((df["数值"] == "").sum()),
            "非空数值行": int((df["数值"] != "").sum()),
        }
    return out


def main() -> None:
    report = {"annual": [], "monthly": [], "integrated": audit_integrated()}
    for freq, sub in (("annual", "annual"), ("monthly", "monthly")):
        for c in CITIES:
            p = DATA / sub / f"{c}.csv"
            if p.exists():
                report[freq].append(audit_file(p, freq))
            else:
                report[freq].append({"文件": str(p), "缺失": True})

    # cross-file header consistency
    for freq in ("annual", "monthly"):
        heads = {tuple(x["字段"]) for x in report[freq] if "字段" in x}
        report[f"{freq}_表头一致"] = (len(heads) == 1)

    OUT.write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")

    for freq, name in (("annual", "年度"), ("monthly", "月度")):
        files = report[freq]
        print(f"===== {name}：{len(files)} 个文件 =====")
        for x in files:
            if x.get("缺失"):
                print(f"  [缺失] {x['文件']}")
                continue
            print(f"  {Path(x['文件']).stem:6s} 行{x['行数(数据行)']:3d} 列{x['列数']:3d} "
                  f"指标{x['指标列数']:2d} 缺{x['缺失单元格']:3d}/{x['总指标单元格']:3d} "
                  f"时间{x['时间最小值']}—{x['时间最大值']} 重复时间{x['重复时间点']} "
                  f"重复行{x['完全重复行']} 空白行{x['空白行']} "
                  f"非数字{len(x['非数字内容'])} 越界{len(x['疑似越界值'])}")
        print(f"  表头一致: {report[freq + '_表头一致']}")
        print()

    print("===== 长表 =====")
    for k, v in report["integrated"].items():
        print(f"  {k}: {v['行数']} 行 × {v['列数']} 列，重复键 {v['重复键']}，"
              f"空数值 {v['空数值行']}，非空 {v['非空数值行']}")
    print(f"\n-> {OUT}")


if __name__ == "__main__":
    main()
