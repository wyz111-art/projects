"""Parse the four target tables of 《江苏统计年鉴2025》 (data year 2024).

Saves the raw HTML under annual/raw/yearbook/2025/ and writes tidy CSVs to
annual/interim/.  Table numbers drift between editions, so nothing here relies
on a table number; every panel is identified by its printed name.
"""

from __future__ import annotations

import csv
import html as htmllib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_RAW, ANNUAL_INTERIM, fetch, save_raw  # noqa: E402

YB_BASE = "http://tj.jiangsu.gov.cn/2025/"
YB_VERSION = "2025"

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)

CITY_ROWS = ["南京市", "无锡市", "徐州市", "常州市", "苏州市", "南通市",
             "连云港市", "淮安市", "盐城市", "扬州市", "镇江市", "泰州市", "宿迁市"]
REGION_ROWS = ["苏南", "苏中", "苏北"]

TABLES = {
    "3-6": ("nj03/nj0306.htm", "3-6 按地区分常住人口"),
    "2-9": ("nj02/nj0209.htm", "2-9 分市地区生产总值"),
    "2-10": ("nj02/nj0210.htm", "2-10 分市地区生产总值构成"),
    "18-14": ("nj18/nj1814.htm", "18-14 城市园林绿化情况"),
}


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def load(key: str) -> list[list[str]]:
    rel, label = TABLES[key]
    url = YB_BASE + rel
    res = fetch(url)
    assert res["status"] == 200, f"{url} -> {res['status']}"
    save_raw(ANNUAL_RAW / "yearbook" / YB_VERSION / f"{label.replace(' ', '_')}.html",
             res["content"], url, bool(res.get("reused")), note=label)
    rows = [cells(r) for r in TR.findall(res["text"])]
    return [r for r in rows if any(r)]


def tidy(name: str, rows: list[dict], fieldnames: list[str]) -> Path:
    path = ANNUAL_INTERIM / name
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)
    print(f"  -> {name}: {len(rows)} rows")
    return path


def num(s: str) -> str:
    s = (s or "").replace(",", "").strip()
    return s


def norm_region(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


# ---------------------------------------------------------------- 3-6 人口
def parse_population() -> None:
    rows = load("3-6")
    out: list[dict] = []
    panel = ""
    panels_seen = []
    for r in rows:
        if len(r) == 19 and re.match(r"^20\d\d$", r[1] or ""):
            if r[0].strip():
                panel = r[0]
                panels_seen.append(panel)
            year, vals = r[1], r[2:]
        elif len(r) == 18 and re.match(r"^20\d\d$", r[0] or "") and panel:
            year, vals = r[0], r[1:]
        else:
            continue
        if len(vals) != 17:
            continue
        names = ["全省"] + CITY_ROWS + REGION_ROWS
        for nm, v in zip(names, vals):
            out.append({"表名": TABLES["3-6"][1], "面板": panel, "年份": year,
                        "地区": nm, "数值": num(v), "年鉴版本": YB_VERSION})
    print(f"3-6 面板: {panels_seen}")
    tidy("yb2025_population.csv", out,
         ["表名", "面板", "年份", "地区", "数值", "年鉴版本"])


# ------------------------------------------------------- 2-9 / 2-10 通用面板
def parse_panelled(key: str, out_name: str) -> None:
    rows = load(key)
    out: list[dict] = []
    panel = ""
    unit = ""
    years: list[str] = []
    panels_seen = []
    for r in rows:
        # the real header row is exactly [地 区, Region, <panel name>];
        # the "按区域分 / Grouped by Region" row must NOT be treated as one
        if len(r) >= 3 and (r[1] or "").strip() == "Region":
            if (r[2] or "").strip():
                panel = r[2]
                panels_seen.append(panel)
            continue
        if r and all(re.match(r"^20\d\d$", x or "") for x in r) and len(r) >= 5:
            years = list(r)
            continue
        if r and ("单位" in r[0]):
            m = re.search(r"单位：(.+)", r[0])
            if m:
                unit = m.group(1).strip()
            continue
        nm = norm_region(r[0]) if r else ""
        if nm in CITY_ROWS + REGION_ROWS and panel and years:
            vals = [num(x) for x in r[2:2 + len(years)]]
            for y, v in zip(years, vals):
                out.append({"表名": TABLES[key][1], "面板": panel, "单位": unit,
                            "年份": y, "地区": nm, "数值": v,
                            "年鉴版本": YB_VERSION})
    print(f"{key} 面板: {panels_seen}")
    tidy(out_name, out, ["表名", "面板", "单位", "年份", "地区", "数值", "年鉴版本"])


# ---------------------------------------------------------------- 18-14 绿化
GREEN_COLS = [
    (7, "PARK_GREEN_PC", "人均公园绿地面积", "平方米"),
    (8, "BUILTUP_AREA", "建成区面积", "平方公里"),
    (9, "GREEN_COVER_RATE", "建成区绿化覆盖率", "%"),
]


def parse_green() -> None:
    rows = load("18-14")
    out: list[dict] = []
    for r in rows:
        if len(r) != 10:
            continue
        raw = norm_region(r[0])
        city = (raw[:-2] + "市") if raw.endswith("市区") else raw
        if city not in CITY_ROWS:
            continue
        for idx, code, name, unit in GREEN_COLS:
            out.append({"表名": TABLES["18-14"][1], "年份": "2024", "地区": city,
                        "指标代码": code, "指标名称": name, "数值": num(r[idx]),
                        "单位": unit, "空间口径": "市区（市辖区）",
                        "年鉴版本": YB_VERSION})
    tidy("yb2025_green.csv", out,
         ["表名", "年份", "地区", "指标代码", "指标名称", "数值", "单位",
          "空间口径", "年鉴版本"])


def main() -> None:
    print("== 解析《江苏统计年鉴2025》==")
    parse_population()
    parse_panelled("2-9", "yb2025_gdp.csv")
    parse_panelled("2-10", "yb2025_gdp_composition.csv")
    parse_green()


if __name__ == "__main__":
    main()
