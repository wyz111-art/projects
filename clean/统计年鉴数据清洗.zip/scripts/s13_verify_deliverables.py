"""Final check: every deliverable exists and CSV/XLSX contents agree."""

from __future__ import annotations

import csv
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ROOT  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

PAIRS = [
    "annual/integrated/annual_city_attributes",
    "annual/integrated/annual_coverage_matrix",
    "annual/integrated/annual_status_summary",
    "annual/integrated/annual_cross_source_diff",
    "monthly/integrated/monthly_city_attributes",
    "monthly/integrated/monthly_coverage_matrix",
    "monthly/integrated/monthly_status_summary",
    "monthly/integrated/monthly_export_vs_api_check",
    "docs/availability_matrix",
    "docs/raw_manifest",
    "docs/data_sources",
]


def main() -> None:
    ok = True
    print(f"{'文件':52s} {'CSV行':>7s} {'XLSX行':>7s} {'列':>4s} 一致")
    for stem in PAIRS:
        c = ROOT / f"{stem}.csv"
        x = ROOT / f"{stem}.xlsx"
        if not c.exists() or not x.exists():
            print(f"{stem:52s} 缺失（csv={c.exists()} xlsx={x.exists()}）")
            ok = False
            continue
        rows = list(csv.reader(c.open(encoding="utf-8-sig")))
        wb = load_workbook(x, read_only=True, data_only=True)
        ws = wb[wb.sheetnames[0]]
        xls = [list(r) for r in ws.iter_rows(values_only=True)]
        wb.close()
        same_shape = len(rows) == len(xls) and len(rows[0]) == len(xls[0])
        # spot check a few cells
        same_vals = True
        def norm(v):
            """CSV writes '' for a missing value; XLSX stores a truly empty cell."""
            return "" if v is None else str(v).strip()
        for i in (1, len(rows) // 2, len(rows) - 1):
            for j in range(len(rows[0])):
                cv, xv = norm(rows[i][j]), norm(xls[i][j])
                if cv == xv:
                    continue
                try:
                    if float(cv) == float(xv):
                        continue
                except (ValueError, TypeError):
                    pass
                same_vals = False
        flag = "OK" if (same_shape and same_vals) else "差异"
        if flag != "OK":
            ok = False
        print(f"{stem:52s} {len(rows):>7d} {len(xls):>7d} {len(rows[0]):>4d} {flag}")

    print("\n原始数据文件：")
    for rel in ["annual/raw/yearbook", "annual/raw/platform",
                "monthly/raw/export", "monthly/raw/platform",
                "monthly/raw/policy"]:
        n = len(list((ROOT / rel).rglob("*.*")))
        print(f"  {rel:32s} {n} 个文件")
    print(f"\n{'全部通过' if ok else '存在问题，见上表'}")


if __name__ == "__main__":
    main()
