"""Coverage / status summary for a long-format integrated table."""

from __future__ import annotations

import csv
import sys
from collections import Counter, defaultdict
from pathlib import Path


def main() -> None:
    path = Path(sys.argv[1])
    rows = list(csv.DictReader(path.open(encoding="utf-8-sig")))
    period_key = "统计年份" if "统计年份" in rows[0] else "统计月份"
    print(f"# {path.name}: {len(rows)} rows")
    print("状态分布:", dict(Counter(r["状态"] for r in rows)))

    by_ind: dict[str, Counter] = defaultdict(Counter)
    years: dict[str, set] = defaultdict(set)
    for r in rows:
        by_ind[r["指标代码"]][r["状态"]] += 1
        if r["状态"] == "已确认有数据":
            years[r["指标代码"]].add(r[period_key])
    print("\n指标 | 有数据 | 未找到 | 年份范围")
    for code in sorted(by_ind):
        c = by_ind[code]
        ys = sorted(years.get(code, []))
        rng = f"{ys[0]}–{ys[-1]} ({len(ys)}年)" if ys else "-"
        print(f"  {code:18s} {c.get('已确认有数据', 0):5d} {c.get('未找到', 0):5d}  {rng}")

    print("\n按地区 × 指标 的有数据计数（年度）")
    grid: dict[str, Counter] = defaultdict(Counter)
    for r in rows:
        if r["状态"] == "已确认有数据":
            grid[r["地区"]][r["指标代码"]] += 1
    codes = sorted(by_ind)
    print("  地区        " + " ".join(f"{c[:9]:>9s}" for c in codes))
    for reg in sorted(grid, key=lambda x: (x != "全省", x not in ("苏南", "苏中", "苏北"), x)):
        print(f"  {reg:10s} " + " ".join(f"{grid[reg].get(c, 0):>9d}" for c in codes))


if __name__ == "__main__":
    main()
