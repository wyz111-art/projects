"""Cross-source checks, coverage matrices, availability matrix and XLSX mirrors."""

from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import (ANNUAL_INTEGRATED, ANNUAL_INTERIM, DOCS,  # noqa: E402
                     MONTHLY_INTEGRATED, MONTHLY_INTERIM, ROOT)
from xlout import csv_to_xlsx  # noqa: E402


def read(path: Path) -> list[dict]:
    return list(csv.DictReader(path.open(encoding="utf-8-sig")))


def write(path: Path, rows: list[dict], fields: list[str]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"  -> {path.name}: {len(rows)} rows")


# --------------------------------------------------------------- annual checks
def annual_reports() -> None:
    rows = read(ANNUAL_INTEGRATED / "annual_city_attributes.csv")
    regions = ["全省"] + [c + "市" for c in
                          ["南京", "无锡", "徐州", "常州", "苏州", "南通",
                           "连云港", "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]] \
              + ["苏南", "苏中", "苏北"]
    codes = sorted({r["指标代码"] for r in rows})
    grid = defaultdict(Counter)
    for r in rows:
        if r["状态"] == "已确认有数据":
            grid[r["地区"]][r["指标代码"]] += 1
    matrix = []
    for reg in regions:
        row = {"地区": reg}
        for c in codes:
            row[c] = grid[reg].get(c, 0)
        matrix.append(row)
    write(ANNUAL_INTEGRATED / "annual_coverage_matrix.csv", matrix,
          ["地区"] + codes)

    summary = []
    for c in codes:
        cnt = Counter(r["状态"] for r in rows if r["指标代码"] == c)
        years = sorted({r["统计年份"] for r in rows
                        if r["指标代码"] == c and r["状态"] == "已确认有数据"})
        summary.append({"指标代码": c, "已确认有数据": cnt.get("已确认有数据", 0),
                        "已确认无数据": cnt.get("已确认无数据", 0),
                        "不适用": cnt.get("不适用", 0),
                        "未找到": cnt.get("未找到", 0),
                        "待核实": cnt.get("待核实", 0),
                        "最早年份": years[0] if years else "",
                        "最晚年份": years[-1] if years else ""})
    write(ANNUAL_INTEGRATED / "annual_status_summary.csv", summary,
          ["指标代码", "已确认有数据", "已确认无数据", "不适用", "未找到",
           "待核实", "最早年份", "最晚年份"])

    # cross-source: yearbook vs platform djsnd (2020-2024)
    plat = read(ANNUAL_INTERIM / "platform_djsnd_annual.csv")
    pmap = {}
    for r in plat:
        pmap[(r["地区"], r["指标名称"], r["统计年份"])] = r["数值"]
    diff = []
    A = {"GDP": "地区生产总值", "GDP_PC": "人均地区生产总值"}
    for r in rows:
        if r["指标代码"] not in A or r["状态"] != "已确认有数据":
            continue
        pv = pmap.get((r["地区"], A[r["指标代码"]], r["统计年份"]))
        if pv is None:
            continue
        try:
            a, b = float(r["数值"]), float(pv)
            rel = abs(a - b) / b * 100 if b else 0.0
        except ValueError:
            continue
        diff.append({"地区": r["地区"], "指标代码": r["指标代码"],
                     "统计年份": r["统计年份"], "年鉴值": r["数值"],
                     "年鉴版本": r["年鉴版本"], "平台值": pv,
                     "相对差异(%)": f"{rel:.3f}",
                     "是否一致": "一致" if abs(a - b) < 1e-9 else "不一致"})
    write(ANNUAL_INTEGRATED / "annual_cross_source_diff.csv", diff,
          ["地区", "指标代码", "统计年份", "年鉴值", "年鉴版本", "平台值",
           "相对差异(%)", "是否一致"])


# -------------------------------------------------------------- monthly checks
def monthly_reports() -> None:
    rows = read(MONTHLY_INTEGRATED / "monthly_city_attributes.csv")
    codes = sorted({r["指标代码"] for r in rows})
    regions = ["全省"] + [c + "市" for c in
                          ["南京", "无锡", "徐州", "常州", "苏州", "南通",
                           "连云港", "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]]
    per = defaultdict(Counter)
    for r in rows:
        if r["状态"] == "已确认有数据":
            per[(r["指标代码"], r["地区"])][r["统计月份"]] += 1
    matrix = []
    for c in codes:
        for reg in regions:
            months = sorted(per.get((c, reg), {}))
            matrix.append({"指标代码": c, "地区": reg,
                           "有数据月份数": len(months),
                           "最早月份": months[0] if months else "",
                           "最晚月份": months[-1] if months else ""})
    write(MONTHLY_INTEGRATED / "monthly_coverage_matrix.csv", matrix,
          ["指标代码", "地区", "有数据月份数", "最早月份", "最晚月份"])

    summary = []
    for c in codes:
        cnt = Counter(r["状态"] for r in rows if r["指标代码"] == c)
        summary.append({"指标代码": c, "已确认有数据": cnt.get("已确认有数据", 0),
                        "已确认无数据": cnt.get("已确认无数据", 0),
                        "不适用": cnt.get("不适用", 0),
                        "待核实": cnt.get("待核实", 0)})
    write(MONTHLY_INTEGRATED / "monthly_status_summary.csv", summary,
          ["指标代码", "已确认有数据", "已确认无数据", "不适用", "待核实"])

    # export vs api snapshot on the overlapping months
    api = read(MONTHLY_INTERIM / "api_snapshot_djsyd.csv")
    IND_NAME = {"M0101": "规模以上工业增加值", "M0201": "规模以上服务业营业收入",
                "M0301": "固定资产投资", "M0401": "社会消费品零售总额"}
    amap = {}
    for r in api:
        if not r["数值"]:
            continue
        month = f"{r['统计月份'][:4]}-{r['统计月份'][4:]}"
        sub = r["子指标名称"].replace(IND_NAME.get(r["指标代码"], ""), "", 1)
        amap[(r["指标代码"], r["地区"], month, sub)] = r["数值"]
    checks = []
    for r in rows:
        if r["状态"] != "已确认有数据":
            continue
        k = (r["指标代码"], r["地区"], r["统计月份"], r["子指标名称"])
        if k not in amap:
            continue
        same = abs(float(r["数值"]) - float(amap[k])) < 1e-9
        checks.append({"指标代码": r["指标代码"], "地区": r["地区"],
                       "统计月份": r["统计月份"], "子指标名称": r["子指标名称"],
                       "导出值": r["数值"], "接口值": amap[k],
                       "是否一致": "一致" if same else "不一致"})
    write(MONTHLY_INTEGRATED / "monthly_export_vs_api_check.csv", checks,
          ["指标代码", "地区", "统计月份", "子指标名称", "导出值", "接口值",
           "是否一致"])
    bad = [c for c in checks if c["是否一致"] != "一致"]
    print(f"     导出 vs 接口 共核对 {len(checks)} 格，不一致 {len(bad)} 格")


def availability_matrix() -> None:
    a = read(ANNUAL_INTEGRATED / "annual_status_summary.csv")
    m = read(MONTHLY_INTEGRATED / "monthly_status_summary.csv")
    aw = {r["指标代码"]: r for r in a}
    rows = []
    for code, name, freq, scope, src in [
        ("POP_YE", "年末常住人口", "年度", "全市域", "《江苏统计年鉴》表3-6（跨年修订序列）"),
        ("URBANIZATION", "城镇化率", "年度", "全市域", "《江苏统计年鉴》表3-6 城镇人口比重"),
        ("GDP", "地区生产总值", "年度 + 季度", "全市域", "年鉴2-9/2-10 + 省平台季度"),
        ("GDP_P2_SHARE", "第二产业增加值占GDP比重", "年度", "全市域", "年鉴分市构成表；2025为计算值"),
        ("GDP_P3_SHARE", "第三产业增加值占GDP比重", "年度", "全市域", "年鉴分市构成表；2025为计算值"),
        ("GDP_PC", "人均地区生产总值", "年度", "全市域", "《江苏统计年鉴》分市地区生产总值表"),
        ("GREEN_COVER_RATE", "建成区绿化覆盖率", "年度", "市区（市辖区）", "《江苏统计年鉴》城市园林绿化情况表"),
        ("BUILTUP_AREA", "建成区面积", "年度", "市区（市辖区）", "同上"),
        ("PARK_GREEN_PC", "人均公园绿地面积", "年度", "市区（市辖区）", "同上"),
        ("M0101", "规模以上工业增加值", "月度", "全市域", "省统计平台·设区市月度（页面导出）"),
        ("M0201", "规模以上服务业营业收入", "月度", "全市域", "省统计平台·设区市月度（页面导出）"),
        ("M0301", "固定资产投资", "月度", "全市域", "省统计平台·设区市月度（页面导出）"),
        ("M0401", "社会消费品零售总额", "月度", "全市域", "省统计平台·设区市月度（页面导出）"),
    ]:
        rec = {"指标代码": code, "指标名称": name, "时间粒度": freq,
               "空间口径": scope, "主要来源": src}
        if code in aw:
            rec.update({"年度最早": aw[code]["最早年份"], "年度最晚": aw[code]["最晚年份"],
                        "年度有数据格": aw[code]["已确认有数据"],
                        "年度未找到格": aw[code]["未找到"]})
        else:
            rec.update({"年度最早": "", "年度最晚": "", "年度有数据格": "",
                        "年度未找到格": ""})
        rec["是否有月度观测"] = "是" if code in {x["指标代码"] for x in m} else "否"
        rows.append(rec)
    write(DOCS / "availability_matrix.csv", rows,
          ["指标代码", "指标名称", "时间粒度", "空间口径", "主要来源", "是否有月度观测",
           "年度最早", "年度最晚", "年度有数据格", "年度未找到格"])


def mirror_to_xlsx() -> None:
    targets = [
        (ANNUAL_INTEGRATED, ["annual_city_attributes.csv",
                             "annual_coverage_matrix.csv",
                             "annual_status_summary.csv",
                             "annual_cross_source_diff.csv"]),
        (MONTHLY_INTEGRATED, ["monthly_city_attributes.csv",
                              "monthly_coverage_matrix.csv",
                              "monthly_status_summary.csv",
                              "monthly_export_vs_api_check.csv"]),
        (DOCS, ["availability_matrix.csv", "raw_manifest.csv",
                "data_sources.csv"]),
    ]
    report = []
    for folder, names in targets:
        for n in names:
            p = folder / n
            if not p.exists():
                continue
            info = csv_to_xlsx(p, p.with_suffix(".xlsx"))
            report.append(info)
            print(f"  xlsx {info['xlsx']}: {info['rows']}x{info['cols']} "
                  f"truncated={info['truncated_cells']}")
    (DOCS / "xlsx_mirror_report.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")


def manifest_csv() -> None:
    p = DOCS / "raw_manifest.json"
    if not p.exists():
        return
    data = json.loads(p.read_text(encoding="utf-8"))
    write(DOCS / "raw_manifest.csv", data,
          ["url", "saved_as", "bytes", "sha256", "reused_from_survey_cache", "note"])


def main() -> None:
    print("年度报表:")
    annual_reports()
    print("月度报表:")
    monthly_reports()
    print("可得性矩阵:")
    availability_matrix()
    print("原始清单:")
    manifest_csv()
    print("XLSX 镜像:")
    mirror_to_xlsx()


if __name__ == "__main__":
    main()
