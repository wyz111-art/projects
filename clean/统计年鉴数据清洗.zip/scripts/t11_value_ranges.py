"""Actual min / max of every indicator column across the 13 city files."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]


def summarise(folder: Path, meta: set[str]) -> None:
    frames = []
    for c in CITIES:
        df = pd.read_csv(folder / f"{c}.csv", dtype=str, keep_default_na=False)
        frames.append(df)
    all_df = pd.concat(frames, ignore_index=True)
    cols = [c for c in all_df.columns if c not in meta]
    print(f"== {folder.name}: {len(all_df)} 行合计 ==")
    for c in cols:
        s = pd.to_numeric(all_df[c].replace("", pd.NA), errors="coerce").dropna()
        if len(s) == 0:
            print(f"  {c:34s} 全部为空")
            continue
        print(f"  {c:34s} n={len(s):4d}  min={s.min():>10.2f}  max={s.max():>10.2f}")
    print()


summarise(ROOT / "data" / "annual",
          {"城市", "年份", "数据来源", "原始链接", "状态说明"})
summarise(ROOT / "data" / "monthly",
          {"城市", "年月", "数据来源", "原始链接", "状态说明"})
