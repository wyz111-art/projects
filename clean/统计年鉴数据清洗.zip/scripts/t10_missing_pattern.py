"""Show the per-column missing pattern for one annual and one monthly city file."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def show(path: Path, time_col: str) -> None:
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    meta = {"城市", time_col, "数据来源", "原始链接", "状态说明"}
    cols = [c for c in df.columns if c not in meta]
    print(f"== {path.name}: {len(df)} 行 × {len(cols)} 指标列")
    for c in cols:
        miss = df.loc[df[c] == "", time_col].tolist()
        lst = "、".join(miss)
        if len(lst) > 66:
            lst = lst[:66] + "…"
        print(f"  {c:34s} 缺 {len(miss):2d}/{len(df)}   {lst}")
    print()


city = sys.argv[1] if len(sys.argv) > 1 else "南京"
show(ROOT / "data" / "annual" / f"{city}.csv", "年份")
show(ROOT / "data" / "monthly" / f"{city}.csv", "年月")
