"""Fetch the platform JSON snapshot for djsyd (the only months the API exposes)."""

from __future__ import annotations

import csv
import json
import sys
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import MONTHLY_RAW, MONTHLY_INTERIM, fetch  # noqa: E402

BASE = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm"
REF = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0201"
H = {"X-Requested-With": "XMLHttpRequest",
     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
     "Accept": "application/json, text/javascript, */*; q=0.01",
     "Origin": "https://data.jsstjj.cn:30443"}

REG = {"GX3200": "全省", "GX3201": "南京市", "GX3202": "无锡市", "GX3203": "徐州市",
       "GX3204": "常州市", "GX3205": "苏州市", "GX3206": "南通市", "GX3207": "连云港市",
       "GX3208": "淮安市", "GX3209": "盐城市", "GX3210": "扬州市", "GX3211": "镇江市",
       "GX3212": "泰州市", "GX3213": "宿迁市"}
IND = ["M0101", "M0201", "M0301", "M0401"]


def main() -> None:
    fetch(REF)
    fetch("https://data.jsstjj.cn:30443/acmr-passport//online.htm", referer=REF)
    rows: list[dict] = []
    for code in IND:
        body = {"rowcode": "reg", "colcode": "sj", "selwds": "[]",
                "bxwds": json.dumps([{"wdcode": "zb", "valuecode": code}])}
        res = fetch(f"{BASE}?m=queryData&dbcode=djsyd", method="POST",
                    data=urllib.parse.urlencode(body), extra_headers=H,
                    referer=REF, allow_cache=False)
        try:
            rd = json.loads(res["text"])["returndata"]
        except Exception:
            rd = {}
        nodes = (rd.get("wdnodes") or [{}])[0].get("nodes", []) if rd else []
        names = {n["code"]: (n.get("name") or "").strip() for n in nodes}
        units = {n["code"]: n.get("unitname") for n in nodes}
        got = 0
        for dn in rd.get("datanodes", []):
            wds = dn["wdinfo"]["wds"]
            zb = next((w["valuecode"] for w in wds if w["wdcode"] == "zb"), "")
            reg = next((w["valuecode"] for w in wds if w["wdcode"] == "reg"), "")[:6]
            per = next((w["valuecode"] for w in wds if w["wdcode"] == "sj"), "")
            rows.append({"指标代码": code, "子指标代码": zb,
                         "子指标名称": names.get(zb, ""),
                         "单位": units.get(zb, ""),
                         "地区": REG.get(reg, reg), "统计月份": per,
                         "数值": (dn["data"].get("strdata") or "").strip()})
            got += 1
        print(f"  {code}: {got} 条")
    (MONTHLY_RAW / "platform" / "djsyd_api_snapshot.json").write_text(
        json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    with (MONTHLY_INTERIM / "api_snapshot_djsyd.csv").open(
            "w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    months = sorted({r["统计月份"] for r in rows})
    print(f"{len(rows)} rows, 月份={months} -> api_snapshot_djsyd.csv")


if __name__ == "__main__":
    main()
