"""Print the panel header (3rd cell) of every sub-table in 2-9 / 2-10."""

from __future__ import annotations

import html as htmllib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import fetch  # noqa: E402

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def main() -> None:
    YB = "http://tj.jiangsu.gov.cn/2025/"
    for label, url in [("2-9 GDP", YB + "nj02/nj0209.htm"),
                       ("2-10 构成", YB + "nj02/nj0210.htm")]:
        rows = [cells(r) for r in TR.findall(fetch(url)["text"])]
        rows = [r for r in rows if any(r)]
        print(f"\n===== {label} rows={len(rows)}")
        for i, r in enumerate(rows):
            if len(r) >= 3 and ("地区" in r[0] or "Region" in r[1]):
                print(f"  header row {i:03d}: cells={len(r)} "
                      f"| c2={r[2][:60]!r} | last={r[-1][:24]!r}")
            elif len(r) == 2:
                print(f"  note  row {i:03d}: {r[0][:60]!r}")


if __name__ == "__main__":
    main()
