"""Inspect the annual / monthly integrated tables before splitting by city.

Read-only. Records file paths, field structure, city names (including spacing
and suffix variants), time coverage, indicator counts, record counts and any
duplicate (city, time, indicator) keys.
"""

from __future__ import annotations

import csv
import json
import re
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AN = ROOT / "annual" / "integrated" / "annual_city_attributes.csv"
MO = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
OUT = ROOT / "docs" / "split_input_inventory.json"

EXPECT13 = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
            "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]


def read(p: Path) -> list[dict]:
    return list(csv.DictReader(p.open(encoding="utf-8-sig")))


def canon(name: str) -> str:
    """Strip spaces / suffix so naming variants can be compared."""
    s = re.sub(r"[\s\u3000]+", "", name or "")
    return s[:-1] if s.endswith("市") else s


def describe(path: Path, kind: str) -> dict:
    rows = read(path)
    fields = list(rows[0].keys())
    city_col = "地区"
    raw_cities = sorted({r[city_col] for r in rows})
    canon_cities = sorted({canon(c) for c in raw_cities})
    time_col = "统计年份" if kind == "annual" else "统计月份"
    ind_col = "指标代码" if kind == "annual" else None
    sub_col = None if kind == "annual" else "子指标名称"
    name_col = "指标名称"

    inds = sorted({(r[ind_col], r[name_col], r["单位"])
                   for r in rows}) if ind_col else \
        sorted({(r[name_col], r[sub_col], r["单位"]) for r in rows})

    keys = Counter((r[city_col], r[time_col],
                    r[ind_col] if ind_col else f'{r[name_col]}|{r[sub_col]}')
                   for r in rows)
    dupes = {k: v for k, v in keys.items() if v > 1}

    per_city = Counter(r[city_col] for r in rows)
    per_city_valid = Counter(r[city_col] for r in rows if r["数值"].strip())
    years = sorted({r[time_col] for r in rows})

    d = {
        "文件": str(path.relative_to(ROOT)),
        "行数": len(rows),
        "字段": fields,
        "城市原始值": raw_cities,
        "城市规范化": canon_cities,
        "缺少的预期城市": [c for c in EXPECT13 if c not in canon_cities],
        "非13市的城市": [c for c in canon_cities if c not in EXPECT13],
        "时间粒度": kind,
        "时间取值范围": [years[0], years[-1]],
        "时间点个数": len(years),
        "指标数": len(inds),
        "指标清单": [list(x) for x in inds],
        "状态分布": dict(Counter(r["状态"] for r in rows)),
        "非空数值记录数": sum(1 for r in rows if r["数值"].strip()),
        "空数值记录数": sum(1 for r in rows if not r["数值"].strip()),
        "重复键数量": len(dupes),
        "每城市记录数": dict(sorted(per_city.items())),
        "每城市非空数值数": dict(sorted(per_city_valid.items())),
    }
    return d


def main() -> None:
    out = {"annual": describe(AN, "annual"), "monthly": describe(MO, "monthly")}
    print(json.dumps(out, ensure_ascii=False, indent=1))
    OUT.write_text(json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\n-> {OUT}")


if __name__ == "__main__":
    main()
