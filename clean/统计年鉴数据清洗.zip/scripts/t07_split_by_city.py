"""Split the integrated tables into one wide CSV per city.

Inputs (read-only, never modified):
  annual/integrated/annual_city_attributes.csv          1925 行
  monthly/integrated/monthly_city_attributes_updated.csv 3024 行

Outputs:
  data/annual/<城市>.csv    每行一个年份，每列一个年度指标
  data/monthly/<城市>.csv   每行一个年月，每列一个月度指标（含子指标）

Run:  python scripts/t07_split_by_city.py
"""

from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
AN_SRC = ROOT / "annual" / "integrated" / "annual_city_attributes.csv"
MO_SRC = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
OUT_AN = ROOT / "data" / "annual"
OUT_MO = ROOT / "data" / "monthly"
REPORT_JSON = ROOT / "docs" / "split_verification.json"

CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]
CITY_FULL = [c + "市" for c in CITIES]

# presentation order; names are "<指标名称>(<单位>)" so the unit stays visible
ANNUAL_ORDER = [
    "年末常住人口(万人)", "城镇化率(%)",
    "地区生产总值(亿元)", "地区生产总值增速(%)",
    "第一产业增加值(亿元)", "第二产业增加值(亿元)", "第三产业增加值(亿元)",
    "第二产业增加值占GDP比重(%)", "第三产业增加值占GDP比重(%)",
    "人均地区生产总值(元)",
    "建成区绿化覆盖率(%)", "建成区面积(平方公里)", "人均公园绿地面积(平方米)",
]
MONTHLY_ORDER = [
    "规模以上工业增加值_同比增长(%)", "规模以上工业增加值_累计增长(%)",
    "规模以上服务业营业收入_累计增长(%)", "固定资产投资_累计增长(%)",
    "社会消费品零售总额_同比增长(%)", "社会消费品零售总额_累计增长(%)",
]


def read(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, dtype=str, keep_default_na=False).fillna("")


def assert_no_dupes(df: pd.DataFrame, keys: list[str], label: str) -> dict:
    """Rule 10/12: never silently aggregate or drop duplicated observations."""
    dup = df[df.duplicated(keys, keep=False)]
    if len(dup):
        print(f"[!] {label}: 发现 {len(dup)} 条重复键记录，前 5 条：")
        print(dup.head().to_string())
        raise SystemExit(f"{label} 存在重复键，需先人工分析，脚本停止")
    return {"重复键记录数": 0, "唯一键": keys}


def split_annual() -> dict:
    df = read(AN_SRC)
    total_rows = len(df)
    subset = df[df["地区"].isin(CITY_FULL)].copy()
    dropped = total_rows - len(subset)
    dup_info = assert_no_dupes(subset, ["地区", "统计年份", "指标代码"], "年度数据")

    subset["列名"] = subset["指标名称"] + "(" + subset["单位"] + ")"
    wide = subset.pivot(index=["地区", "统计年份"], columns="列名",
                        values="数值")
    wide = wide.reindex(columns=ANNUAL_ORDER)
    wide = wide.reset_index().rename(columns={"地区": "城市_full",
                                              "统计年份": "年份"})
    wide["城市"] = wide["城市_full"].str.replace("市", "", regex=False)

    # row-level provenance: distinct sources / links used for that city-year
    prov = (subset[subset["数据来源"].str.strip() != ""]
            .groupby(["地区", "统计年份"])
            .agg(数据来源=("数据来源", lambda s: "；".join(sorted(set(s)))),
                 原始链接=("原始链接", lambda s: "；".join(sorted(set(s)))))
            .reset_index()
            .rename(columns={"地区": "城市_full", "统计年份": "年份"}))
    wide = wide.merge(prov, on=["城市_full", "年份"], how="left")

    cols = ["城市", "年份"] + ANNUAL_ORDER + ["数据来源", "原始链接"]
    wide["年份"] = wide["年份"].astype(int)
    wide = wide[cols].sort_values("年份")

    OUT_AN.mkdir(parents=True, exist_ok=True)
    stats = {}
    for c in CITIES:
        sub = wide[wide["城市"] == c]
        sub.to_csv(OUT_AN / f"{c}.csv", index=False, encoding="utf-8-sig")
        src = subset[subset["地区"] == c + "市"]
        stats[c] = {
            "源记录数": len(src),
            "源非空观测数": int((src["数值"].str.strip() != "").sum()),
            "输出行数": len(sub),
            "输出非空单元格数": int(sub[ANNUAL_ORDER].ne("").sum().sum()),
            "年份范围": f"{sub['年份'].min()}—{sub['年份'].max()}",
            "指标列数": len(ANNUAL_ORDER),
            "有值指标列数": int((sub[ANNUAL_ORDER].ne("").any()).sum()),
        }
    return {"源文件": str(AN_SRC.relative_to(ROOT)), "源总行数": total_rows,
            "保留13市行数": len(subset), "排除的非13市行数": dropped,
            "排除的地区": sorted(set(df["地区"]) - set(CITY_FULL)),
            **dup_info, "每城市": stats}


def split_monthly() -> dict:
    df = read(MO_SRC)
    total_rows = len(df)
    subset = df[df["地区"].isin(CITY_FULL)].copy()
    dropped = total_rows - len(subset)
    dup_info = assert_no_dupes(subset, ["地区", "统计月份", "指标名称", "子指标名称"],
                               "月度数据")

    subset["列名"] = (subset["指标名称"] + "_" + subset["子指标名称"]
                     + "(" + subset["单位"] + ")")
    wide = subset.pivot(index=["地区", "统计月份"], columns="列名",
                        values="数值")
    wide = wide.reindex(columns=MONTHLY_ORDER)
    wide = wide.reset_index().rename(columns={"地区": "城市_full",
                                              "统计月份": "年月"})
    wide["城市"] = wide["城市_full"].str.replace("市", "", regex=False)

    # compact status note: what is not a normal observation, and why
    def note(g: pd.DataFrame) -> str:
        st = g[g["状态"] != "已确认有数据"]
        if st.empty:
            return ""
        if len(st) == len(g) and set(st["状态"]) == {"不适用"}:
            return "该月全部指标不适用（1—2月合并发布，官方不单独发布1月数据）"
        return "；".join(f"{r['列名']}={r['状态']}" for _, r in st.iterrows())

    sn = (subset.groupby(["地区", "统计月份"], sort=False)
          .apply(note, include_groups=False)
          .reset_index(name="状态说明")
          .rename(columns={"地区": "城市_full", "统计月份": "年月"}))
    wide = wide.merge(sn, on=["城市_full", "年月"], how="left")
    wide["数据来源"] = subset["数据来源"].iloc[0]
    wide["原始链接"] = subset["原始链接"].iloc[0]

    cols = ["城市", "年月"] + MONTHLY_ORDER + ["数据来源", "原始链接", "状态说明"]
    wide = wide[cols].sort_values("年月")

    OUT_MO.mkdir(parents=True, exist_ok=True)
    stats = {}
    for c in CITIES:
        sub = wide[wide["城市"] == c]
        sub.to_csv(OUT_MO / f"{c}.csv", index=False, encoding="utf-8-sig")
        src = subset[subset["地区"] == c + "市"]
        stats[c] = {
            "源记录数": len(src),
            "源非空观测数": int((src["数值"].str.strip() != "").sum()),
            "输出行数": len(sub),
            "输出非空单元格数": int(sub[MONTHLY_ORDER].ne("").sum().sum()),
            "时间范围": f"{sub['年月'].min()} — {sub['年月'].max()}",
            "指标列数": len(MONTHLY_ORDER),
            "有值指标列数": int((sub[MONTHLY_ORDER].ne("").any()).sum()),
            "非正常状态月份数": int((sub["状态说明"].str.strip() != "").sum()),
        }
    return {"源文件": str(MO_SRC.relative_to(ROOT)), "源总行数": total_rows,
            "保留13市行数": len(subset), "排除的非13市行数": dropped,
            "排除的地区": sorted(set(df["地区"]) - set(CITY_FULL)),
            **dup_info, "每城市": stats}


def main() -> None:
    print("=== 年度拆分 ===")
    a = split_annual()
    print(f"  源 {a['源总行数']} 行 → 保留 13 市 {a['保留13市行数']} 行"
          f"（排除 {a['排除的非13市行数']} 行：{a['排除的地区']}）")
    print("=== 月度拆分 ===")
    m = split_monthly()
    print(f"  源 {m['源总行数']} 行 → 保留 13 市 {m['保留13市行数']} 行"
          f"（排除 {m['排除的非13市行数']} 行：{m['排除的地区']}）")

    report = {"annual": a, "monthly": m}
    REPORT_JSON.write_text(json.dumps(report, ensure_ascii=False, indent=1),
                           encoding="utf-8")
    print(f"\n-> {OUT_AN} / {OUT_MO}")
    print(f"-> {REPORT_JSON}")


if __name__ == "__main__":
    main()
