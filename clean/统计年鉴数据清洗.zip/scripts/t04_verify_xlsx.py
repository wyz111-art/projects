"""Read-only check that each XLSX mirrors its CSV exactly (content, not formatting)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
PAIRS = [
    ("monthly/integrated/monthly_city_attributes_updated", "monthly_attributes"),
    ("monthly/integrated/monthly_gap_verification", "gap_verification"),
]


def norm(v) -> str:
    return "" if v is None else str(v).strip()


def main() -> None:
    report = []
    for stem, sheet in PAIRS:
        csv_path = ROOT / f"{stem}.csv"
        xlsx_path = ROOT / f"{stem}.xlsx"
        rows = list(csv.reader(csv_path.open(encoding="utf-8-sig")))
        wb = load_workbook(xlsx_path, read_only=True, data_only=True)
        ws = wb[sheet]
        xls = [list(r) for r in ws.iter_rows(values_only=True)]
        wb.close()

        shape_ok = len(rows) == len(xls) and len(rows[0]) == len(xls[0])
        diffs = []
        for i in range(len(rows)):
            for j in range(len(rows[0])):
                a, b = norm(rows[i][j]), norm(xls[i][j])
                if a == b:
                    continue
                try:
                    if float(a) == float(b):
                        continue
                except (ValueError, TypeError):
                    pass
                diffs.append((i + 1, j + 1, a[:40], b[:40]))
        rec = {"csv": csv_path.name, "xlsx": xlsx_path.name, "sheet": sheet,
               "csv_rows": len(rows), "xlsx_rows": len(xls),
               "cols": len(rows[0]), "shape_ok": shape_ok,
               "cell_diffs": len(diffs), "examples": diffs[:5]}
        report.append(rec)
        print(json.dumps(rec, ensure_ascii=False))

    (ROOT / "docs" / "xlsx_csv_consistency.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    ok = all(r["shape_ok"] and r["cell_diffs"] == 0 for r in report)
    print("\n" + ("全部一致" if ok else "存在差异"))


if __name__ == "__main__":
    main()
