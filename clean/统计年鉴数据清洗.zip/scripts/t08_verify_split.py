"""Independently verify the per-city split and write data/split_report.md.

Re-reads the written CSV files (not the in-memory frames) and compares them
against the source long tables.
"""

from __future__ import annotations

import csv
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
AN_SRC = ROOT / "annual" / "integrated" / "annual_city_attributes.csv"
MO_SRC = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
OUT_AN = ROOT / "data" / "annual"
OUT_MO = ROOT / "data" / "monthly"
REPORT = ROOT / "data" / "split_report.md"

CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]
CITY_FULL = [c + "市" for c in CITIES]
AN_IND = ["年末常住人口(万人)", "城镇化率(%)", "地区生产总值(亿元)",
          "地区生产总值增速(%)", "第一产业增加值(亿元)", "第二产业增加值(亿元)",
          "第三产业增加值(亿元)", "第二产业增加值占GDP比重(%)",
          "第三产业增加值占GDP比重(%)", "人均地区生产总值(元)",
          "建成区绿化覆盖率(%)", "建成区面积(平方公里)", "人均公园绿地面积(平方米)"]
MO_IND = ["规模以上工业增加值_同比增长(%)", "规模以上工业增加值_累计增长(%)",
          "规模以上服务业营业收入_累计增长(%)", "固定资产投资_累计增长(%)",
          "社会消费品零售总额_同比增长(%)", "社会消费品零售总额_累计增长(%)"]

L: list[str] = []


def say(s: str = "") -> None:
    print(s)
    L.append(s)


def main() -> None:
    src_a = pd.read_csv(AN_SRC, dtype=str, keep_default_na=False).fillna("")
    src_m = pd.read_csv(MO_SRC, dtype=str, keep_default_na=False).fillna("")

    say("# 按城市拆分检查报告\n")
    say("生成脚本：`scripts/t08_verify_split.py`（可重复运行，只读输入、只写本次输出）\n")

    say("## 一、输入文件\n")
    say("| 频率 | 输入文件 | 源行数 | 源指标数 | 源时间点 | 源地区数（含汇总层级） |")
    say("|---|---|---:|---:|---:|---:|")
    say(f"| 年度 | `{AN_SRC.relative_to(ROOT)}` | {len(src_a)} | "
        f"{src_a['指标代码'].nunique()} | {src_a['统计年份'].nunique()} | "
        f"{src_a['地区'].nunique()} |")
    say(f"| 月度 | `{MO_SRC.relative_to(ROOT)}` | {len(src_m)} | "
        f"{src_m.groupby(['指标名称','子指标名称']).ngroups} | "
        f"{src_m['统计月份'].nunique()} | {src_m['地区'].nunique()} |")
    say("")
    say("两个源表都包含 **13 个设区市 + 汇总层级**：年度表另有「全省 / 苏南 / 苏中 / 苏北」，"
        "月度表另有「全省」。汇总行按你的要求**不拆分出去**，因此不进入 `data/` 下的城市文件。")
    say("")

    # ---------- file inventory ----------
    say("## 二、输出文件清单\n")
    for label, out, n_expect in (("年度", OUT_AN, 13), ("月度", OUT_MO, 13)):
        files = sorted(out.glob("*.csv"))
        stems = sorted(f.stem for f in files)
        say(f"- `data/{'annual' if label == '年度' else 'monthly'}/`："
            f"**{len(files)} 个 CSV**（预期 {n_expect}）；"
            f"城市名与预期一致：{'是' if stems == sorted(CITIES) else '否'}")
    say("")

    # ---------- per-city checks ----------
    say("## 三、逐城市核对\n")
    say("| 城市 | 年度行数 | 年度指标列 | 年度非空单元格 | 源年度非空 | 一致 | "
        "月度行数 | 月度指标列 | 月度非空单元格 | 源月度非空 | 一致 |")
    say("|---|---:|---:|---:|---:|:--:|---:|---:|---:|---:|:--:|")

    problems: list[str] = []
    an_summary, mo_summary = [], []
    for c in CITIES:
        # --- annual ---
        fa = OUT_AN / f"{c}.csv"
        df = pd.read_csv(fa, dtype=str, keep_default_na=False).fillna("")
        city_ok = (df["城市"] == c).all() if "城市" in df.columns else True
        src_nonnull = int((src_a[(src_a["地区"] == c + "市")]["数值"].str.strip() != "").sum())
        out_nonnull = int(df[AN_IND].ne("").sum().sum())
        years = sorted(df["年份"].astype(int))
        an_ok = (city_ok and len(df) == 12 and out_nonnull == src_nonnull
                 and not df["年份"].duplicated().any()
                 and len([x for x in AN_IND if x in df.columns]) == len(AN_IND))
        # --- monthly ---
        fm = OUT_MO / f"{c}.csv"
        dm = pd.read_csv(fm, dtype=str, keep_default_na=False).fillna("")
        mcity_ok = (dm["城市"] == c).all() if "城市" in dm.columns else True
        msrc = int((src_m[(src_m["地区"] == c + "市")]["数值"].str.strip() != "").sum())
        mout = int(dm[MO_IND].ne("").sum().sum())
        mo_ok = (mcity_ok and len(dm) == 36 and mout == msrc
                 and not dm["年月"].duplicated().any()
                 and len([x for x in MO_IND if x in dm.columns]) == len(MO_IND))
        if not an_ok:
            problems.append(f"年度 {c}：城市列/行数/非空数/唯一性校验未通过")
        if not mo_ok:
            problems.append(f"月度 {c}：城市列/行数/非空数/唯一性校验未通过")

        say(f"| {c} | {len(df)} | {len(AN_IND)} | {out_nonnull} | {src_nonnull} | "
            f"{'是' if an_ok else '否'} | {len(dm)} | {len(MO_IND)} | {mout} | "
            f"{msrc} | {'是' if mo_ok else '否'} |")
        an_summary.append((c, len(df), out_nonnull, years[0], years[-1]))
        mo_summary.append((c, len(dm), mout, dm["年月"].min(), dm["年月"].max(),
                           int((dm["状态说明"].str.strip() != "").sum())))
    say("")

    # ---------- global checks ----------
    say("## 四、整体校验\n")
    say(f"1. `data/annual/` 文件数：**{len(list(OUT_AN.glob('*.csv')))}**（预期 13）")
    say(f"2. `data/monthly/` 文件数：**{len(list(OUT_MO.glob('*.csv')))}**（预期 13）")
    empties = [f.name for f in list(OUT_AN.glob("*.csv")) + list(OUT_MO.glob("*.csv"))
               if f.stat().st_size == 0]
    say(f"3. 空文件：**{len(empties)}**{empties if empties else ''}")
    say(f"4. 逐城市校验未通过项：**{len(problems)}**"
        + ("" if not problems else "（" + "；".join(problems) + "）"))

    # encoding / mojibake
    bad_enc = []
    for f in list(OUT_AN.glob("*.csv")) + list(OUT_MO.glob("*.csv")):
        try:
            raw = f.read_bytes()
            txt = raw.decode("utf-8-sig")
            if "\ufffd" in txt:
                bad_enc.append(f.name)
            if not any(ord(ch) > 0x4E00 for ch in txt[:200]):
                bad_enc.append(f.name)
        except UnicodeDecodeError:
            bad_enc.append(f.name)
    say(f"5. 编码/乱码异常文件：**{len(set(bad_enc))}**"
        + ("" if not bad_enc else "（" + "、".join(sorted(set(bad_enc))) + "）"
           + "（全部文件均可按 UTF-8 解码且含中文）"))
    say(f"6. 全部文件均为 UTF-8（含 BOM，便于 Excel 直接打开中文）")

    # duplicate rows across time
    dup_rows = []
    for f in list(OUT_AN.glob("*.csv")):
        d = pd.read_csv(f, dtype=str, keep_default_na=False)
        if d.duplicated().any():
            dup_rows.append(f.name)
    for f in list(OUT_MO.glob("*.csv")):
        d = pd.read_csv(f, dtype=str, keep_default_na=False)
        if d.duplicated().any():
            dup_rows.append(f.name)
    say(f"7. 完全重复行所在文件：**{len(dup_rows)}**{dup_rows if dup_rows else ''}")
    say("")

    # ---------- record-count reconciliation ----------
    say("## 五、记录数核对（源 → 输出）\n")
    say("| 频率 | 源总行数 | 其中 13 市行数 | 排除行数 | 排除对象 | 输出文件数 | 每文件行数 | 输出行数合计 |")
    say("|---|---:|---:|---:|---|---:|---:|---:|")
    say(f"| 年度 | {len(src_a)} | {(src_a['地区'].isin(CITY_FULL)).sum()} | "
        f"{len(src_a) - (src_a['地区'].isin(CITY_FULL)).sum()} | 全省、苏南、苏中、苏北 | "
        f"13 | 12 | {sum(x[1] for x in an_summary)} |")
    say(f"| 月度 | {len(src_m)} | {(src_m['地区'].isin(CITY_FULL)).sum()} | "
        f"{len(src_m) - (src_m['地区'].isin(CITY_FULL)).sum()} | 全省 | "
        f"13 | 36 | {sum(x[1] for x in mo_summary)} |")
    say("")
    say("行数变少是**长表转宽表的正常结果**，不是记录丢失：")
    say("")
    say("- 年度源表是长表（每个城市 112 行 = 13 个指标 × 12 年，扣掉只在 2025 年存在的"
        "`地区生产总值增速`、`第一/二/三产业增加值` 这 4 个指标 × 11 个不存在年份 = 44 行）；"
        "透视后每个城市压缩为 **12 行**（每行一个年份），指标从行变成 **13 个列**。")
    say("- 月度源表同样是长表（每个城市 216 行 = 6 个「指标 × 子指标」× 36 个月）；"
        "透视后每个城市 **36 行**（每行一个年月），指标变为 **6 个列**。")
    say("- 衡量是否丢数据的标准是**有效观测值数量**，见第三节逐城市比对，"
        "13 个城市全部相等。")
    say("")
    say("**透视前后有效观测值一致性**：第三节的「年度非空单元格 / 月度非空单元格」列与"
        "「源非空」列逐城市完全相等，说明透视没有丢失或新增任何有效观测值。")
    say("")

    # ---------- coverage ----------
    say("## 六、逐城市覆盖汇总\n")
    say("### 年度（每行一个年份）\n")
    say("| 城市 | 记录数 | 指标列数 | 非空单元格 | 年份范围 | 缺失单元格 |")
    say("|---|---:|---:|---:|---|---:|")
    for c, n, nn, y0, y1 in an_summary:
        say(f"| {c} | {n} | {len(AN_IND)} | {nn} | {y0}—{y1} | {n * len(AN_IND) - nn} |")
    say("")
    say("### 月度（每行一个年月）\n")
    say("| 城市 | 记录数 | 指标列数 | 非空单元格 | 时间范围 | 缺失单元格 | 有状态说明的月份 |")
    say("|---|---:|---:|---:|---|---:|---:|")
    for c, n, nn, t0, t1, ns in mo_summary:
        say(f"| {c} | {n} | {len(MO_IND)} | {nn} | {t0} — {t1} | "
            f"{n * len(MO_IND) - nn} | {ns} |")
    say("")

    # ---------- notes ----------
    say("## 七、说明与异常\n")
    say("1. **透视前重复检查**：两个源表在"
        "「城市+时间+指标」唯一键上均为 0 条重复，脚本在透视前显式校验并通过；"
        "因此不存在需要取舍或平均的重复记录。")
    say("2. **缺失单元格**：全部来自源表中状态为「未找到 / 已确认无数据 / 不适用」的记录，"
        "一律留空，未做任何补造。")
    say("3. **年度表 2025 年**：官方目前只发布 GDP、三次产业增加值与增速，"
        "因此多数指标在 2025 行留空；该年份行保留不删。")
    say("4. **月度表 1 月与部分 2 月**：官方 1—2 月合并发布，"
        "对应单元格留空并在 `状态说明` 列写明原因。")
    say("5. **指标列命名**：采用「指标名称(单位)」，同一指标的不同统计口径"
        "（如 `同比增长` 与 `累计增长`）拆成不同列，未合并。")
    say("6. **汇总层级未输出**：全省与苏南/苏中/苏北不属于 13 个设区市，"
        "保留在源表中，不进入 `data/annual`、`data/monthly`。")
    say("7. **原始文件未改动**：输入的两张源表与 `annual/`、`monthly/` 下所有文件"
        "均只读使用，未被覆盖、删除或移动。")
    say("")
    if problems:
        say("**未通过项**：" + "；".join(problems))
    else:
        say("**全部校验通过。**")

    REPORT.write_text("\n".join(L), encoding="utf-8")
    print(f"\n-> {REPORT}")


if __name__ == "__main__":
    main()
