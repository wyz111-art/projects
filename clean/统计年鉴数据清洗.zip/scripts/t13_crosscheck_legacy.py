"""Cross-check the earlier survey-folder city table against the current data/."""

from __future__ import annotations

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / "jiangsu_13city_data_survey" / "results" / "city_attributes_final.csv"
CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]

PAIRS = [
    ("年末常住人口", "年末常住人口(万人)", "2024"),
    ("地区生产总值(GDP)", "地区生产总值(亿元)", "2025"),
    ("人均地区生产总值", "人均地区生产总值(元)", "2024"),
    ("建成区绿化覆盖率", "建成区绿化覆盖率(%)", "2024"),
    ("建成区面积", "建成区面积(平方公里)", "2024"),
    ("人均公园绿地面积", "人均公园绿地面积(平方米)", "2024"),
]


def main() -> None:
    old = pd.read_csv(OLD, dtype=str, keep_default_na=False)
    cur = {c: pd.read_csv(ROOT / "data" / "annual" / f"{c}.csv", dtype=str,
                          keep_default_na=False).set_index("年份")
           for c in CITIES}
    print(f"早期表: {len(old)} 行, 指标 {old['指标名称'].nunique()}, "
          f"年份 {sorted(set(old['统计年份']))}")
    for oname, cname, yr in PAIRS:
        diff, checked = [], 0
        for city in CITIES:
            sub = old[(old["城市"] == city + "市")
                      & (old["指标名称"] == oname)
                      & (old["统计年份"] == yr)]["数值"]
            if not len(sub):
                continue
            checked += 1
            val = cur[city].loc[yr, cname]
            if str(sub.iloc[0]).strip() != str(val).strip():
                diff.append((city, sub.iloc[0], val))
        print(f"  {oname:16s} {yr}  核对 {checked} 市  不一致 {len(diff)}")
        for d in diff[:3]:
            print(f"       {d[0]}: 早期={d[1]} 当前={d[2]}")


if __name__ == "__main__":
    main()
