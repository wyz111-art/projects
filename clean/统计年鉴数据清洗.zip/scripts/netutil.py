"""Shared HTTP helper for the city-attribute panel project.

Design notes
------------
* Cache key matches ``jiangsu_13city_data_survey/scripts/common.py`` exactly
  (``sha1(f"{method}:{url}:{data}")[:16]``) so previously downloaded responses
  can be reused instead of re-hitting government servers.
* Government WAFs on ``*.jiangsu.gov.cn`` reject compressed requests with 403,
  so every request asks for ``Accept-Encoding: identity``.
* Every network call is appended to ``logs/access_log.jsonl``.
"""

from __future__ import annotations

import hashlib
import json
import re
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
SURVEY_RAW = WORKSPACE / "jiangsu_13city_data_survey" / "data" / "raw"

ANNUAL_RAW = ROOT / "annual" / "raw"
MONTHLY_RAW = ROOT / "monthly" / "raw"
ANNUAL_INTERIM = ROOT / "annual" / "interim"
ANNUAL_INTEGRATED = ROOT / "annual" / "integrated"
MONTHLY_INTERIM = ROOT / "monthly" / "interim"
MONTHLY_INTEGRATED = ROOT / "monthly" / "integrated"
DOCS = ROOT / "docs"
LOGS = ROOT / "logs"
CACHE = ROOT / ".cache"

for _d in (ANNUAL_RAW, MONTHLY_RAW, ANNUAL_INTERIM, ANNUAL_INTEGRATED,
           MONTHLY_INTERIM, MONTHLY_INTEGRATED, DOCS, LOGS, CACHE):
    _d.mkdir(parents=True, exist_ok=True)

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36")

HEADERS = {
    "User-Agent": UA,
    "Accept": ("text/html,application/xhtml+xml,application/xml;q=0.9,"
               "image/avif,image/webp,*/*;q=0.8"),
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Accept-Encoding": "identity",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}

SSL_CTX = ssl.create_default_context()
SSL_CTX.check_hostname = False
SSL_CTX.verify_mode = ssl.CERT_NONE

HOST_INTERVAL = 0.8
_last_hit: dict[str, float] = {}
_cookies: dict[str, dict[str, str]] = {}

ACCESS_LOG = LOGS / "access_log.jsonl"
MANIFEST = ROOT / "docs" / "raw_manifest.json"


def slug(key: str) -> str:
    return hashlib.sha1(key.encode("utf-8")).hexdigest()[:16]


def _log(record: dict) -> None:
    record["ts"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    try:
        with ACCESS_LOG.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record, ensure_ascii=False) + "\n")
    except OSError:
        pass


def _manifest_add(entry: dict) -> None:
    data = []
    if MANIFEST.exists():
        try:
            data = json.loads(MANIFEST.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            data = []
    data = [d for d in data if d.get("url") != entry.get("url")
            or d.get("saved_as") != entry.get("saved_as")]
    data.append(entry)
    MANIFEST.write_text(json.dumps(data, ensure_ascii=False, indent=1),
                        encoding="utf-8")


def decode(content: bytes, content_type: str = "") -> str:
    charset = "utf-8"
    m = re.search(r"charset=([\w\-]+)", content_type or "", re.I)
    if m:
        charset = m.group(1)
    else:
        m = re.search(br"charset=[\"']?([\w\-]+)", content[:4000], re.I)
        if m:
            charset = m.group(1).decode("ascii", "ignore")
    if charset.lower() in ("gb2312", "gbk", "gb18030"):
        charset = "gb18030"
    try:
        return content.decode(charset, "replace")
    except LookupError:
        return content.decode("utf-8", "replace")


def _cookie_header(host: str) -> str:
    return "; ".join(f"{k}={v}" for k, v in _cookies.get(host, {}).items())


def _store_cookies(host: str, headers) -> None:
    jar = _cookies.setdefault(host, {})
    for raw in headers.get_all("Set-Cookie") or []:
        pair = raw.split(";", 1)[0].strip()
        if "=" in pair:
            k, v = pair.split("=", 1)
            jar[k.strip()] = v.strip()


def fetch(url: str, *, method: str = "GET", data: str | bytes | None = None,
          referer: str | None = None, extra_headers: dict | None = None,
          timeout: int = 40, retries: int = 2, allow_cache: bool = True) -> dict:
    """Fetch a URL, reusing the survey cache when possible."""
    body = data.encode("utf-8") if isinstance(data, str) else data
    key = f"{method}:{url}:{data if isinstance(data, str) else ''}"
    key_slug = slug(key)
    cache_bin = CACHE / f"{key_slug}.bin"
    cache_meta = CACHE / f"{key_slug}.meta.json"
    reuse_bin = SURVEY_RAW / f"{key_slug}.bin"
    reuse_meta = SURVEY_RAW / f"{key_slug}.meta.json"

    if allow_cache and cache_bin.exists() and cache_meta.exists():
        meta = json.loads(cache_meta.read_text(encoding="utf-8"))
        content = cache_bin.read_bytes()
        return {"status": meta["status"], "url": meta.get("final_url", url),
                "headers": meta.get("headers", {}), "content": content,
                "text": decode(content, meta.get("content_type", "")),
                "reused": meta.get("reused", False), "from_cache": True}

    if allow_cache and reuse_bin.exists() and reuse_meta.exists():
        meta = json.loads(reuse_meta.read_text(encoding="utf-8"))
        content = reuse_bin.read_bytes()
        cache_bin.write_bytes(content)
        meta["reused"] = True
        cache_meta.write_text(json.dumps(meta, ensure_ascii=False, indent=1),
                              encoding="utf-8")
        _log({"url": url, "status": meta["status"], "bytes": len(content),
              "reused": True})
        return {"status": meta["status"], "url": meta.get("final_url", url),
                "headers": meta.get("headers", {}), "content": content,
                "text": decode(content, meta.get("content_type", "")),
                "reused": True, "from_cache": True}

    headers = dict(HEADERS)
    if referer:
        headers["Referer"] = referer
    if extra_headers:
        headers.update(extra_headers)
    host = urllib.parse.urlparse(url).netloc
    if _cookies.get(host):
        headers["Cookie"] = _cookie_header(host)

    gap = HOST_INTERVAL - (time.time() - _last_hit.get(host, 0.0))
    if gap > 0:
        time.sleep(gap)

    last_err = ""
    for attempt in range(retries + 1):
        try:
            req = urllib.request.Request(url, headers=headers, data=body,
                                         method=method)
            with urllib.request.urlopen(req, timeout=timeout,
                                        context=SSL_CTX) as resp:
                content = resp.read()
                _last_hit[host] = time.time()
                _store_cookies(host, resp.headers)
                hdrs = {k: v for k, v in resp.headers.items()}
                result = {"status": resp.status, "url": resp.geturl(),
                          "headers": hdrs, "content": content,
                          "text": decode(content, hdrs.get("Content-Type", "")),
                          "reused": False, "from_cache": False}
                _persist(cache_bin, cache_meta, result)
                _log({"url": url, "status": resp.status, "bytes": len(content),
                      "reused": False})
                return result
        except urllib.error.HTTPError as exc:
            content = exc.read()
            _last_hit[host] = time.time()
            hdrs = {k: v for k, v in exc.headers.items()}
            result = {"status": exc.code, "url": url, "headers": hdrs,
                      "content": content,
                      "text": decode(content, hdrs.get("Content-Type", "")),
                      "reused": False, "from_cache": False}
            _persist(cache_bin, cache_meta, result)
            _log({"url": url, "status": exc.code, "bytes": len(content),
                  "reused": False})
            return result
        except Exception as exc:  # noqa: BLE001
            last_err = f"{type(exc).__name__}: {exc}"
            _last_hit[host] = time.time()
        time.sleep(1.5 * (attempt + 1))

    _log({"url": url, "status": 0, "error": last_err})
    return {"status": 0, "url": url, "headers": {}, "content": b"", "text": "",
            "reused": False, "from_cache": False, "error": last_err}


def _persist(bin_path: Path, meta_path: Path, result: dict) -> None:
    bin_path.write_bytes(result["content"])
    meta_path.write_text(json.dumps({
        "status": result["status"], "final_url": result["url"],
        "headers": result["headers"],
        "content_type": result["headers"].get("Content-Type", ""),
    }, ensure_ascii=False, indent=1), encoding="utf-8")


def save_raw(path: Path, content: bytes, url: str, reused: bool,
             note: str = "") -> None:
    """Persist an official response under annual/raw or monthly/raw."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    _manifest_add({
        "url": url, "saved_as": str(path.relative_to(ROOT)),
        "bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(),
        "reused_from_survey_cache": reused, "note": note,
    })
