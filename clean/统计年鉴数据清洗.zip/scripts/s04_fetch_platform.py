"""Fetch platform data: djsnd (annual 2020-2024, cross-check) and djsjd (2025 GDP)."""

from __future__ import annotations

import csv
import json
import sys
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_RAW, ANNUAL_INTERIM, fetch  # noqa: E402

BASE = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm"
REF = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0203"
REF_Q = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0202"
H = {"X-Requested-With": "XMLHttpRequest",
     "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
     "Accept": "application/json, text/javascript, */*; q=0.01",
     "Origin": "https://data.jsstjj.cn:30443"}

REG = {"GX3200": "全省", "GX3201": "南京市", "GX3202": "无锡市", "GX3203": "徐州市",
       "GX3204": "常州市", "GX3205": "苏州市", "GX3206": "南通市", "GX3207": "连云港市",
       "GX3208": "淮安市", "GX3209": "盐城市", "GX3210": "扬州市", "GX3211": "镇江市",
       "GX3212": "泰州市", "GX3213": "宿迁市"}

DJSND_GROUPS = ["Y0301", "Y0201"]
DJSND_YEARS = ["2020", "2021", "2022", "2023", "2024"]


def post(db: str, body: dict, referer: str) -> dict:
    url = f"{BASE}?m=queryData&dbcode={db}"
    res = fetch(url, method="POST", data=urllib.parse.urlencode(body),
                extra_headers=H, referer=referer, allow_cache=False)
    try:
        return json.loads(res["text"])
    except Exception:
        return {}


def rows_from(resp: dict, period_field: str) -> list[dict]:
    rd = resp.get("returndata") or {}
    nodes = (rd.get("wdnodes") or [{}])[0].get("nodes", []) if rd else []
    names = {n["code"]: (n.get("name") or "").strip() for n in nodes}
    units = {n["code"]: n.get("unitname") for n in nodes}
    out = []
    for dn in rd.get("datanodes", []):
        wds = dn["wdinfo"]["wds"]
        zb = next((w["valuecode"] for w in wds if w["wdcode"] == "zb"), "")
        reg = next((w["valuecode"] for w in wds if w["wdcode"] == "reg"), "")[:6]
        per = next((w["valuecode"] for w in wds if w["wdcode"] == "sj"), "")
        d = dn["data"]
        out.append({"地区": REG.get(reg, reg), "指标代码": zb,
                    "指标名称": names.get(zb, ""), "单位": units.get(zb, ""),
                    period_field: per, "数值": (d.get("strdata") or "").strip(),
                    "有数据": bool(d.get("hasdata"))})
    return out


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def main() -> None:
    fetch(REF)
    fetch("https://data.jsstjj.cn:30443/acmr-passport//online.htm", referer=REF)

    annual_rows: list[dict] = []
    for gid in DJSND_GROUPS:
        for year in DJSND_YEARS:
            body = {"rowcode": "reg", "colcode": "zb",
                    "selwds": json.dumps([{"wdcode": "sj", "valuecode": year}]),
                    "bxwds": json.dumps([{"wdcode": "zb", "valuecode": gid}])}
            rows = rows_from(post("djsnd", body, REF), "统计年份")
            annual_rows += rows
            print(f"  djsnd {gid} {year}: {len(rows)} 条")
    (ANNUAL_RAW / "platform" / "djsnd_annual_2020_2024.json").write_text(
        json.dumps(annual_rows, ensure_ascii=False, indent=1), encoding="utf-8")
    write_csv(ANNUAL_INTERIM / "platform_djsnd_annual.csv", annual_rows)
    print(f"  -> platform_djsnd_annual.csv: {len(annual_rows)} rows")

    # colcode=zb returns every industry indicator for all regions at one period
    qrows: list[dict] = []
    for period in ["202506", "202509", "202512", "202603", "202606"]:
        body = {"rowcode": "reg", "colcode": "zb",
                "selwds": json.dumps([{"wdcode": "sj", "valuecode": period}]),
                "bxwds": "[]"}
        got = rows_from(post("djsjd", body, REF_Q), "统计期")
        qrows += got
        print(f"  djsjd {period}: {len(got)} 条")

    (ANNUAL_RAW / "platform" / "djsjd_gdp_quarterly.json").write_text(
        json.dumps(qrows, ensure_ascii=False, indent=1), encoding="utf-8")
    if qrows:
        write_csv(ANNUAL_INTERIM / "platform_djsjd_gdp.csv", qrows)
        print(f"  -> platform_djsjd_gdp.csv: {len(qrows)} rows")


if __name__ == "__main__":
    main()
