"""Inspect the existing annual / monthly deliverables and print a factual summary.

Read-only: nothing is modified. Output is also written to
docs/existing_data_inventory.md so the check report can quote it verbatim.
"""

from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
AN = ROOT / "annual" / "integrated" / "annual_city_attributes.csv"
MO = ROOT / "monthly" / "integrated" / "monthly_city_attributes.csv"
LOG: list[str] = []


def say(s: str = "") -> None:
    print(s)
    LOG.append(s)


def read(p: Path) -> list[dict]:
    return list(csv.DictReader(p.open(encoding="utf-8-sig")))


def main() -> None:
    say("# 现有数据核查（由 t01_inspect_existing.py 生成）\n")

    # ---------------- annual ----------------
    a = read(AN)
    say(f"## 年度主表 `{AN.relative_to(ROOT)}`")
    say(f"- 行数 {len(a)}；列：{'、'.join(a[0].keys())}")
    say(f"- 状态：{dict(Counter(r['状态'] for r in a))}")
    years = sorted({r["统计年份"] for r in a})
    say(f"- 年份范围：{years[0]}—{years[-1]}")
    say(f"- 地区数：{len({r['地区'] for r in a})}")
    say("")
    say("| 指标代码 | 指标名称 | 单位 | 空间口径 | 记录数 | 13市覆盖年份 |")
    say("|---|---|---|---|---:|---|")
    for code in sorted({r["指标代码"] for r in a}):
        sub = [r for r in a if r["指标代码"] == code]
        ok = [r for r in sub if r["状态"] == "已确认有数据"]
        city = [r for r in ok if r["地区"].endswith("市")]
        cy = sorted({r["统计年份"] for r in city})
        say(f"| {code} | {sub[0]['指标名称']} | {sub[0]['单位']} | "
            f"{sub[0]['空间口径']} | {len(sub)} | "
            f"{cy[0] + '-' + cy[-1] if cy else '—'} |")
    say("")

    # the 8 fields the user listed
    EIGHT = [("POP_YE", "年末常住人口", "万人"),
             ("GDP", "地区生产总值（GDP）", "亿元"),
             ("GDP_P2_SHARE", "第二产业占比", "%"),
             ("GDP_P3_SHARE", "第三产业占比", "%"),
             ("GDP_PC", "人均GDP", "元"),
             ("GREEN_COVER_RATE", "建成区绿化覆盖率", "%"),
             ("BUILTUP_AREA", "建成区面积", "平方公里"),
             ("PARK_GREEN_PC", "人均公园绿地面积", "平方米")]
    say("## 用户列出的 8 个字段在年度表中的核对结果\n")
    say("| 用户字段 | 指标代码 | 在年度表中 | 13市可得年份 | 统计频率 |")
    say("|---|---|---|---|---|")
    for code, name, unit in EIGHT:
        sub = [r for r in a if r["指标代码"] == code]
        ok = [r for r in sub if r["状态"] == "已确认有数据"
              and r["地区"].endswith("市")]
        cy = sorted({r["统计年份"] for r in ok})
        say(f"| {name}（{unit}） | {code} | 是 | "
            f"{cy[0] + '—' + cy[-1] if cy else '无'} | 年度 |")
    say("")
    say("> 这 8 个字段在官方来源中**只有年度数据**，没有任何月度口径。")
    say("")

    # ---------------- monthly ----------------
    m = read(MO)
    say(f"## 月度主表 `{MO.relative_to(ROOT)}`")
    say(f"- 行数 {len(m)}；列：{'、'.join(m[0].keys())}")
    say(f"- 状态：{dict(Counter(r['状态'] for r in m))}")
    months = sorted({r["统计月份"] for r in m})
    say(f"- 月份范围：{months[0]} — {months[-1]}（共 {len(months)} 个月）")
    say(f"- 地区数：{len({r['地区'] for r in m})}")
    say("")
    say("| 指标代码 | 指标名称 | 子指标 | 单位 | 记录数 |")
    say("|---|---|---|---|---:|")
    for k, v in sorted(Counter((r["指标代码"], r["指标名称"], r["子指标名称"],
                                r["单位"]) for r in m).items()):
        say(f"| {k[0]} | {k[1]} | {k[2]} | {k[3]} | {v} |")
    say("")
    say("### 月度缺失明细")
    per = defaultdict(set)
    for r in m:
        if r["状态"] == "已确认有数据":
            per[(r["指标代码"], r["地区"])].add(r["统计月份"])
    ref = max(per.values(), key=len)
    gaps = {k: sorted(ref - v) for k, v in per.items() if ref - v}
    say(f"- 基准完整月份数：{len(ref)}")
    if gaps:
        for k, v in sorted(gaps.items()):
            say(f"- {k[0]} / {k[1]}：缺 {v}")
    else:
        say("- 无缺口")
    say("")
    say("### 月度非“已确认有数据”明细")
    for r in m:
        if r["状态"] != "已确认有数据" and r["统计月份"].endswith("-02"):
            continue
        if r["状态"] != "已确认有数据":
            say(f"- {r['统计月份']} {r['指标代码']} {r['地区']} "
                f"{r['子指标名称']} → {r['状态']}")
    say("")
    say("> 每年 1 月与 2 月部分子指标为“不适用”（官方 1—2 月合并发布），"
        "已在主表逐格标注。")

    out = ROOT / "docs" / "existing_data_inventory.md"
    out.write_text("\n".join(LOG), encoding="utf-8")
    print(f"\n-> {out}")


if __name__ == "__main__":
    main()
