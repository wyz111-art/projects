"""Quick CSV viewer: python peek_csv.py <path> [max_rows] [filter-substr]"""

from __future__ import annotations

import csv
import sys
from pathlib import Path


def main() -> None:
    path = Path(sys.argv[1])
    cap = int(sys.argv[2]) if len(sys.argv) > 2 else 12
    needle = sys.argv[3] if len(sys.argv) > 3 else ""
    rows = list(csv.DictReader(path.open(encoding="utf-8-sig")))
    print(f"# {path}  rows={len(rows)}  cols={list(rows[0].keys()) if rows else []}")
    shown = 0
    for r in rows:
        if needle and needle not in " ".join(str(v) for v in r.values()):
            continue
        print("  " + " | ".join(f"{k}={v}" for k, v in r.items()))
        shown += 1
        if shown >= cap:
            break


if __name__ == "__main__":
    main()
