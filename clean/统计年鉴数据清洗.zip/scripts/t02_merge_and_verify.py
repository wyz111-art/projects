"""Merge the re-verified gap evidence into the monthly deliverable.

No new monthly values could be collected (both gaps were re-queried directly
against the official platform and confirmed absent), so the merge consists of:
  * carrying every existing record over unchanged,
  * upgrading the 12 '已确认无数据' records with the direct-query evidence,
  * emitting a standalone gap-verification table,
  * leaving the annual table untouched (nothing new is available).

Outputs (new files, originals are never overwritten):
  monthly/integrated/monthly_city_attributes_updated.csv
  monthly/integrated/monthly_gap_verification.csv
  docs/annual_update_decision.md
"""

from __future__ import annotations

import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "monthly" / "integrated" / "monthly_city_attributes.csv"
DST = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
GAP = ROOT / "monthly" / "integrated" / "monthly_gap_verification.csv"
DEC = ROOT / "docs" / "annual_update_decision.md"

CHECKED = "2026-10-16"
SRC_URL = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0201"

# direct single-month query results (region -> observed outcome)
M0301_202502 = {
    "全省": "-0.7", "徐州市": "5.9", "苏州市": "6.0",
    "南京市": "未查询到相关数据", "无锡市": "未查询到相关数据",
    "常州市": "未查询到相关数据", "南通市": "未查询到相关数据",
    "连云港市": "未查询到相关数据", "淮安市": "未查询到相关数据",
    "盐城市": "未查询到相关数据", "扬州市": "未查询到相关数据",
    "镇江市": "未查询到相关数据", "泰州市": "未查询到相关数据",
    "宿迁市": "未查询到相关数据",
}

M0401_202309_NOTE = (
    "单月查询该月仅渲染“累计增长”一列（值 7.1），“同比增长”列在结果中不存在；"
    "对照 2023-08 与 2023-10 两个月均同时渲染两列并有值，"
    "说明平台对无数据的子指标会整列省略，该值确属未发布"
)


def main() -> None:
    rows = list(csv.DictReader(SRC.open(encoding="utf-8-sig")))
    fields = list(rows[0].keys())

    gaps: list[dict] = []
    updated = 0
    for r in rows:
        if r["状态"] != "已确认无数据":
            continue
        if r["指标代码"] == "M0301" and r["统计月份"] == "2025-02":
            r["备注"] = (
                "已用平台单月查询直接复核（时间输入 202502）：该地区返回“未查询到相关数据”；"
                "同期全省 -0.7、徐州市 5.9、苏州市 6.0 均可正常返回，"
                "确认为官方未发布，非采集失败。复核日期 " + CHECKED)
            gaps.append({
                "指标代码": "M0301", "指标名称": r["指标名称"],
                "子指标名称": r["子指标名称"], "地区": r["地区"],
                "统计月份": r["统计月份"], "旧状态": "已确认无数据",
                "新状态": "已确认无数据", "核验方式": "平台单月查询（时间=202502）",
                "核验日期": CHECKED, "核验结果": "未查询到相关数据",
                "对照证据": "全省 -0.7 / 徐州市 5.9 / 苏州市 6.0 有值",
                "是否补齐": "否（官方确无此数据）",
            })
        elif r["指标代码"] == "M0401" and r["统计月份"] == "2023-09":
            r["备注"] = M0401_202309_NOTE + "；复核日期 " + CHECKED
            gaps.append({
                "指标代码": "M0401", "指标名称": r["指标名称"],
                "子指标名称": r["子指标名称"], "地区": r["地区"],
                "统计月份": r["统计月份"], "旧状态": "已确认无数据",
                "新状态": "已确认无数据", "核验方式": "平台单月查询（时间=202309）",
                "核验日期": CHECKED, "核验结果": "结果表仅含“累计增长”列（7.1）",
                "对照证据": "2023-08（同比 -0.2/累计 8.1）、2023-10（同比 4.3/累计 6.8）两列齐全",
                "是否补齐": "否（官方确无此数据）",
            })
        else:
            continue
        updated += 1

    with DST.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"{len(rows)} rows（其中 {updated} 行备注已更新）-> {DST.name}")

    gf = ["指标代码", "指标名称", "子指标名称", "地区", "统计月份", "旧状态",
          "新状态", "核验方式", "核验日期", "核验结果", "对照证据", "是否补齐"]
    with GAP.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=gf)
        w.writeheader()
        w.writerows(gaps)
    print(f"{len(gaps)} gap 记录 -> {GAP.name}")

    DEC.write_text(
        "# 年度表更新判定\n\n"
        f"核查日期：{CHECKED}\n\n"
        "**结论：年度数据无更新，因此不生成 `annual_city_attributes_updated.xlsx`。**\n\n"
        "依据：\n\n"
        "1. 年度指标的最新官方来源是《江苏统计年鉴 2025》（数据年 2024）与"
        "江苏省统计数据平台的设区市年度库（2020—2024），两者在 2026-10-13 已完成采集；\n"
        "2. 年鉴 2026（数据年 2025）截至本次核查尚未在官网发布；\n"
        "3. 用户列出的 8 个年度字段（年末常住人口、GDP、第二/三产业占比、人均 GDP、"
        "建成区绿化覆盖率、建成区面积、人均公园绿地面积）**全部已在现有年度表中**，"
        "13 个设区市覆盖 2014—2024（GDP 与二三产占比到 2025）；\n"
        "4. 逐字段核对结果见 `docs/existing_data_inventory.md`。\n\n"
        "如需生成该文件，可随时用 `annual/integrated/annual_city_attributes.csv` 直接导出，"
        "内容与 `annual_city_attributes.xlsx` 完全一致。\n",
        encoding="utf-8")
    print(f"-> {DEC.name}")


if __name__ == "__main__":
    main()
