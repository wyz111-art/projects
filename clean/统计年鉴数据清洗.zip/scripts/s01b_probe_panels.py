"""Print every row's first two cells to reveal sub-panel boundaries."""

from __future__ import annotations

import html as htmllib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import fetch  # noqa: E402

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def dump(label: str, url: str, limit: int) -> None:
    res = fetch(url)
    rows = [cells(r) for r in TR.findall(res["text"])]
    rows = [r for r in rows if any(r)]
    print(f"\n===== {label} rows={len(rows)}")
    for i, r in enumerate(rows[:limit]):
        a = r[0][:46] if r else ""
        b = r[1][:22] if len(r) > 1 else ""
        print(f"  {i:03d} [{len(r):2d}] {a:<48s} | {b}")


def main() -> None:
    YB = "http://tj.jiangsu.gov.cn/2025/"
    dump("3-6 常住人口", YB + "nj03/nj0306.htm", 48)
    dump("2-9 GDP", YB + "nj02/nj0209.htm", 133)


if __name__ == "__main__":
    main()
