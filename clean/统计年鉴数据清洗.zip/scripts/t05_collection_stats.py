"""Compute the exact figures quoted in docs/data_collection_check_report.md."""

from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MO = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
AN = ROOT / "annual" / "integrated" / "annual_city_attributes.csv"

CITY13 = ["南京市", "无锡市", "徐州市", "常州市", "苏州市", "南通市",
          "连云港市", "淮安市", "盐城市", "扬州市", "镇江市", "泰州市", "宿迁市"]


def read(p: Path) -> list[dict]:
    return list(csv.DictReader(p.open(encoding="utf-8-sig")))


def main() -> None:
    out: dict = {}

    m = read(MO)
    out["monthly_total_rows"] = len(m)
    mo = []
    for (code, name, sub), grp in sorted(
            defaultdict(list, {k: v for k, v in
                              (( (r["指标代码"], r["指标名称"], r["子指标名称"]), None)
                               for r in [])}).items()):
        pass
    groups: dict[tuple, list[dict]] = defaultdict(list)
    for r in m:
        groups[(r["指标代码"], r["指标名称"], r["子指标名称"])].append(r)
    for (code, name, sub), rows in sorted(groups.items()):
        c = Counter(r["状态"] for r in rows)
        months = sorted({r["统计月份"] for r in rows
                         if r["状态"] == "已确认有数据"})
        mo.append({
            "指标代码": code, "指标名称": name, "子指标名称": sub,
            "地区数": len({r["地区"] for r in rows}),
            "记录数": len(rows),
            "已确认有数据": c.get("已确认有数据", 0),
            "不适用": c.get("不适用", 0),
            "已确认无数据": c.get("已确认无数据", 0),
            "最早月份": months[0] if months else "",
            "最晚月份": months[-1] if months else "",
            "频次": "月度",
        })
    out["monthly_by_indicator"] = mo

    a = read(AN)
    out["annual_total_rows"] = len(a)
    ag = defaultdict(list)
    for r in a:
        ag[(r["指标代码"], r["指标名称"], r["单位"], r["空间口径"])].append(r)
    ao = []
    for (code, name, unit, scope), rows in sorted(ag.items()):
        city = [r for r in rows if r["地区"] in CITY13]
        ok = [r for r in city if r["状态"] == "已确认有数据"]
        c = Counter(r["状态"] for r in rows)
        yrs = sorted({r["统计年份"] for r in ok})
        ao.append({
            "指标代码": code, "指标名称": name, "单位": unit,
            "空间口径": scope, "频次": "年度",
            "13市记录数": len(city),
            "13市已确认有数据": len(ok),
            "13市覆盖年份": f"{yrs[0]}—{yrs[-1]}" if yrs else "",
            "全表记录数": len(rows),
            "全表未找到": c.get("未找到", 0),
        })
    out["annual_by_indicator"] = ao

    out["monthly_status"] = dict(Counter(r["状态"] for r in m))
    out["annual_status"] = dict(Counter(r["状态"] for r in a))

    print(json.dumps(out, ensure_ascii=False, indent=1))
    (ROOT / "docs" / "collection_stats.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")


if __name__ == "__main__":
    main()
