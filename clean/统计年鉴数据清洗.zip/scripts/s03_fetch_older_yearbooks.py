"""Harvest the same indicators from yearbook editions 2015-2024.

Table numbers drift between editions, so target tables are located by their
printed title on the chapter index page, never by table number.
"""

from __future__ import annotations

import csv
import html as htmllib
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_RAW, ANNUAL_INTERIM, DOCS, fetch, save_raw  # noqa: E402

EDITIONS = list(range(2015, 2025))  # data years 2014..2023
YB = "http://tj.jiangsu.gov.cn/{y}/"

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)
ANCHOR = re.compile(r'<a\s+href="([^"]+?\.htm)"[^>]*>(.*?)</a>', re.I | re.S)

CITY_BASE = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
             "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]
CITY_ROWS = [c + "市" for c in CITY_BASE]
REGION_ROWS = ["苏南", "苏中", "苏北"]

PANEL_PAT = re.compile(
    r"^(地区生产总值|第一产业(?:增加值)?|第二产业(?:增加值)?|"
    r"第三产业(?:增加值)?|全部工业增加值|人均地区生产总值(?:（元）)?)$")

GREEN_META = [("PARK_GREEN_PC", "人均公园绿地面积", "平方米"),
              ("BUILTUP_AREA", "建成区面积", "平方公里"),
              ("GREEN_COVER_RATE", "建成区绿化覆盖率", "%")]

GDP_ORDER = ["地区生产总值", "第一产业增加值", "第二产业增加值",
             "第三产业增加值", "全部工业增加值", "人均地区生产总值"]
COMP_ORDER = ["第一产业增加值", "第二产业增加值", "第三产业增加值",
              "全部工业增加值"]


def zh(s: str) -> str:
    """Leading Chinese run of a cell (editions merge CN + EN, and pad CJK with
    spaces, e.g. ``南 京 市`` or ``淮安市区Huai'an Urban Area``)."""
    m = re.match(r"^[\s\u3000]*([\u4e00-\u9fff（）\s\u3000]+)", s or "")
    return re.sub(r"[\s\u3000]+", "", m.group(1)) if m else ""


def standardise_panel(name: str) -> str:
    n = re.sub(r"（元）$", "", name or "").strip()
    return {
        "第一产业": "第一产业增加值",
        "第二产业": "第二产业增加值",
        "第三产业": "第三产业增加值",
        "工业": "全部工业增加值",
        "全部工业": "全部工业增加值",
        "人均": "人均地区生产总值",
        "人均GDP": "人均地区生产总值",
        "地区生产总值指数": "地区生产总值",
    }.get(n, n)


def is_number(s: str) -> bool:
    try:
        float((s or "").replace(",", ""))
        return True
    except ValueError:
        return False


def std_region(s: str) -> str:
    """Normalise a row label to the canonical region name used in outputs."""
    s = re.sub(r"\s+", "", s or "")
    if s in REGION_ROWS:
        return s
    if s in CITY_ROWS:
        return s
    if s + "市" in CITY_ROWS:
        return s + "市"
    return s

TARGETS = {
    "green": ("城市园林绿化", "nj18"),
    "gdp": ("分市地区生产总值", "nj02"),
    "gdp_comp": ("分市地区生产总值构成", "nj02"),
}


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def norm(s: str) -> str:
    return re.sub(r"\s+", "", s or "")


def num(s: str) -> str:
    return (s or "").replace(",", "").strip()


def chapter_links(year: int, chapter: str) -> dict[str, str]:
    """Return {title: absolute url} for one chapter index page."""
    url = f"{YB.format(y=year)}{chapter}.htm"
    res = fetch(url)
    if res["status"] != 200:
        print(f"    [{year}] {chapter}.htm -> {res['status']}")
        return {}
    out = {}
    for href, text in ANCHOR.findall(res["text"]):
        t = re.sub(r"\s+", " ", htmllib.unescape(re.sub(r"<[^>]+>", "", text))).strip()
        if t and href.endswith(".htm"):
            out[t] = f"http://tj.jiangsu.gov.cn/{year}/" + href.lstrip("/")
    return out


def parse_panelled(rows: list[list[str]], table_name: str, version: str,
                   found: dict | None = None, order: list[str] | None = None
                   ) -> list[dict]:
    """Adaptive parser: handles every layout variation seen in 2015-2025 editions.

    Panel names come from (in priority order) the merged header cell, a
    "续表N <name>" row, a standalone title row, or a positional fallback using
    the table's standard panel order.
    """
    order = list(order or GDP_ORDER)
    out, panel, unit, years = [], "", "", []
    started = 0
    pending = False  # a panel boundary was already announced since the last data row

    def assign(name_hint: str = "") -> str:
        """Name the current panel from a hint, else fall back to panel order."""
        nonlocal panel, started
        nm = standardise_panel(name_hint)
        if nm:
            panel = nm
            if nm in order:
                started = max(started, order.index(nm) + 1)
        else:
            panel = order[started] if started < len(order) else f"面板{started + 1}"
            started += 1
        return panel

    for r in rows:
        n = len(r)
        if n == 0:
            continue
        # unit note (may share a row with other text)
        if "单位" in r[0]:
            m = re.search(r"单位：(.+)", r[0])
            if m:
                unit = m.group(1).strip()
            if n == 1:
                continue
        if n == 1:
            cell = r[0].strip()
            if "续表" in cell:
                tail = re.sub(r"^续表[一二三四五六七八九十]+", "", cell)
                nm = standardise_panel(zh(tail))
                if nm:
                    assign(nm)
                elif not pending:
                    assign("")
                pending = True
                continue
            m = PANEL_PAT.match(standardise_panel(zh(cell)))
            if m and not pending:
                assign(m.group(1))
                pending = True
            continue
        # header row: [地区 | 地区Region, (Region), <panel name>]
        if zh(r[0]) == "地区" and n <= 3:
            cand = standardise_panel(zh(r[-1])) if n > 1 else ""
            if re.match(r"^20\d\d$", cand):
                cand = ""
            if pending and not cand:
                pass  # same boundary the 续表 row already announced
            else:
                assign(cand)
            pending = True
            continue
        # years row
        if all(re.match(r"^20\d\d$", x or "") for x in r):
            years = list(r)
            continue
        # data row
        nm = std_region(zh(r[0]) or r[0])
        if nm in CITY_ROWS + REGION_ROWS and panel and years:
            pending = False
            start = 1 if (n > 1 and is_number(r[1])) else 2
            vals = [num(x) for x in r[start:start + len(years)]]
            if len(vals) < len(years):
                vals += [""] * (len(years) - len(vals))
            for y, v in zip(years, vals):
                out.append({"表名": table_name, "面板": panel, "单位": unit,
                            "年份": y, "地区": nm, "数值": v,
                            "年鉴版本": version})
            if found is not None:
                found.setdefault("years", set()).update(years)
                found.setdefault("panels", set()).add(panel)
    return out


GREEN_COLS = {
    # number of cells -> (人均公园绿地面积, 建成区面积, 建成区绿化覆盖率)
    9: (6, 7, 8),
    10: (7, 8, 9),
}


def parse_green(rows: list[list[str]], table_name: str, version: str,
                data_year: str, found: dict | None = None) -> list[dict]:
    out = []
    for r in rows:
        raw = zh(r[0]) if r else ""
        if not raw.endswith("市区"):
            continue
        city = std_region(raw[:-2])
        if city not in CITY_ROWS or len(r) not in GREEN_COLS:
            continue
        idxs = GREEN_COLS[len(r)]
        for idx, (code, name, unit) in zip(idxs, GREEN_META):
            out.append({"表名": table_name, "年份": data_year, "地区": city,
                        "指标代码": code, "指标名称": name, "数值": num(r[idx]),
                        "单位": unit, "空间口径": "市区（市辖区）",
                        "年鉴版本": version})
    if found is not None:
        found["cities"] = len({o["地区"] for o in out})
    return out


def tidy(name: str, rows: list[dict], fields: list[str]) -> None:
    path = ANNUAL_INTERIM / name
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)
    print(f"  -> {name}: {len(rows)} rows")


def main() -> None:
    log: list[dict] = []
    green_all: list[dict] = []
    gdp_all: list[dict] = []
    comp_all: list[dict] = []

    for y in EDITIONS:
        data_year = str(y - 1)
        print(f"\n=== 年鉴{y}（数据年 {data_year}）===")
        cache: dict[str, dict] = {}
        for key, (kw, chapter) in TARGETS.items():
            if chapter not in cache:
                cache[chapter] = chapter_links(y, chapter)
            links = cache[chapter]
            hit = [(t, u) for t, u in links.items() if kw in t]
            if key == "gdp":
                hit = [(t, u) for t, u in hit if "构成" not in t]
            if not hit:
                print(f"  [{key}] 未找到（关键词 {kw}）")
                log.append({"版本": y, "目标": key, "状态": "未找到"})
                continue
            title, url = hit[0]
            res = fetch(url)
            if res["status"] != 200:
                print(f"  [{key}] {title} -> {res['status']}")
                log.append({"版本": y, "目标": key, "表名": title,
                            "状态": f"HTTP {res['status']}"})
                continue
            safe = re.sub(r"[\\/:*?\"<>|]", "_", title)
            save_raw(ANNUAL_RAW / "yearbook" / str(y) / f"{safe}.html",
                     res["content"], url, bool(res.get("reused")), note=title)
            rows = [cells(r) for r in TR.findall(res["text"])]
            rows = [r for r in rows if any(r)]
            found: dict = {}
            if key == "green":
                parsed = parse_green(rows, title, str(y), data_year, found)
                green_all += parsed
            elif key == "gdp":
                parsed = parse_panelled(rows, title, str(y), found, GDP_ORDER)
                gdp_all += parsed
            else:
                parsed = parse_panelled(rows, title, str(y), found, COMP_ORDER)
                comp_all += parsed
            log.append({"版本": y, "目标": key, "表名": title, "表号": title.split()[0],
                        "状态": "OK", "解析行数": len(parsed),
                        "年份": sorted(found.get("years", [])) if found.get("years") else [],
                        "面板": sorted(found.get("panels", [])) if found.get("panels") else [],
                        "城市数": found.get("cities", "")})
            years_txt = ",".join(sorted(found.get("years", []))) or "-"
            print(f"  [{key}] {title} -> {len(parsed)} rows  年份={years_txt}"
                  + (f"  面板={sorted(found.get('panels', []))}" if found.get("panels") else ""))

    tidy("yb_older_green.csv", green_all,
         ["表名", "年份", "地区", "指标代码", "指标名称", "数值", "单位",
          "空间口径", "年鉴版本"])
    tidy("yb_older_gdp.csv", gdp_all,
         ["表名", "面板", "单位", "年份", "地区", "数值", "年鉴版本"])
    tidy("yb_older_gdp_composition.csv", comp_all,
         ["表名", "面板", "单位", "年份", "地区", "数值", "年鉴版本"])
    (DOCS / "yearbook_table_index.json").write_text(
        json.dumps(log, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"\n表索引 -> docs/yearbook_table_index.json")


if __name__ == "__main__":
    main()
