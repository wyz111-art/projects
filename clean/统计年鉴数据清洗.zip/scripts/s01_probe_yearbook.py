"""Probe the structure of the target yearbook tables so parsers can be written."""

from __future__ import annotations

import html as htmllib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import fetch  # noqa: E402

YB = "http://tj.jiangsu.gov.cn/2025/"
TABLES = [
    ("3-6 按地区分常住人口", YB + "nj03/nj0306.htm"),
    ("2-9 分市地区生产总值", YB + "nj02/nj0209.htm"),
    ("2-10 分市地区生产总值构成", YB + "nj02/nj0210.htm"),
    ("18-14 城市园林绿化情况", YB + "nj18/nj1814.htm"),
]

TR = re.compile(r"<tr[^>]*>(.*?)</tr>", re.I | re.S)
TD = re.compile(r"<t[dh][^>]*>(.*?)</t[dh]>", re.I | re.S)


def cells(row_html: str) -> list[str]:
    out = []
    for c in TD.findall(row_html):
        t = htmllib.unescape(re.sub(r"<[^>]+>", "", c))
        out.append(re.sub(r"[\s\u00a0\u3000]+", " ", t).strip())
    return out


def main() -> None:
    for name, url in TABLES:
        res = fetch(url)
        print(f"\n===== {name}  status={res['status']} reused={res.get('reused')} "
              f"bytes={len(res['content'])}")
        if res["status"] != 200:
            continue
        rows = [cells(r) for r in TR.findall(res["text"])]
        rows = [r for r in rows if any(r)]
        print(f"rows={len(rows)}")
        for i, r in enumerate(rows[:8]):
            print(f"  {i:03d} | " + " || ".join(x[:26] for x in r))
        print("  ...")
        for i, r in enumerate(rows[-3:], start=len(rows) - 3):
            print(f"  {i:03d} | " + " || ".join(x[:26] for x in r))


if __name__ == "__main__":
    main()
