"""Generate docs/data_sources.csv (source-level inventory of this project)."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_RAW, DOCS, MONTHLY_RAW, ROOT  # noqa: E402

ROWS = [
    dict(数据源="《江苏统计年鉴》2015—2025 电子版（11 个版本）",
         内容="分市常住人口与城镇化率（3-6 按地区分常住人口）、分市地区生产总值与"
              "三次产业增加值（2-9等）、分市地区生产总值构成（2-10等）、"
              "城市园林绿化情况（18-5/18-14，市区口径）",
         获取方式="官网 HTML 表格直接解析（旧版无 Excel 导出）",
         类型="官方统计年鉴（政府开放网页）",
         规模或时间范围="数据年 2014—2024；原始 HTML 35 个文件",
         采集时间="2026-10-13",
         关联字段="地区（市名）、年份",
         原始位置=str((ANNUAL_RAW / "yearbook").relative_to(ROOT)),
         许可或说明="公开政府网站；仅用于课程作业，注明来源"),
    dict(数据源="江苏省统计局统计数据平台 · 设区市年度（djsnd）",
         内容="13 设区市 + 全省的年末常住人口、人口密度、GDP 与三次产业增加值、人均 GDP 等",
         获取方式="平台 JSON 接口 queryData（POST）",
         类型="政府开放数据平台",
         规模或时间范围="2020—2024；560 条",
         采集时间="2026-10-13",
         关联字段="地区代码 GX32xx、年份",
         原始位置=str((ANNUAL_RAW / "platform" / "djsnd_annual_2020_2024.json")
                      .relative_to(ROOT)),
         许可或说明="公开平台；本项目中作为年度值的独立交叉核对来源"),
    dict(数据源="江苏省统计局统计数据平台 · 设区市季度（djsjd）",
         内容="13 设区市 + 全省的地区生产总值与三次产业增加值累计值/累计增长",
         获取方式="平台 JSON 接口 queryData（POST，colcode=zb）",
         类型="政府开放数据平台",
         规模或时间范围="2025Q2—2026Q2；560 条；202512=2025 全年",
         采集时间="2026-10-13",
         关联字段="地区代码 GX32xx、季度",
         原始位置=str((ANNUAL_RAW / "platform" / "djsjd_gdp_quarterly.json")
                      .relative_to(ROOT)),
         许可或说明="公开平台；2025 年为初步核算数，未经最终核实"),
    dict(数据源="江苏省统计局统计数据平台 · 设区市月度（djsyd）页面导出",
         内容="规模以上工业增加值、规模以上服务业营业收入、固定资产投资、"
              "社会消费品零售总额的月度增长率（13 市 + 全省）",
         获取方式="官方页面「下载→Excel」（时间选择：最近 36 个月），逐指标逐地区导出",
         类型="政府开放数据平台（人工驱动导出）",
         规模或时间范围="2023-08—2026-07（33 个应有月份）；56 个 xlsx，264,590 字节",
         采集时间="2026-10-13",
         关联字段="地区、月份（YYYY-MM）",
         原始位置=str((MONTHLY_RAW / "export").relative_to(ROOT)),
         许可或说明="公开页面导出；页面注明「数据为月报数据，未经五经普调整」"),
    dict(数据源="江苏省统计局统计数据平台 · 设区市月度 JSON 接口快照",
         内容="同上 4 个指标的接口返回值（仅可回溯最近 5 个月）",
         获取方式="平台 JSON 接口 queryData（POST，rowcode=reg&colcode=sj）",
         类型="政府开放数据平台",
         规模或时间范围="2026-04—2026-08；280 条",
         采集时间="2026-10-13",
         关联字段="地区、月份",
         原始位置=str((MONTHLY_RAW / "platform" / "djsyd_api_snapshot.json")
                      .relative_to(ROOT)),
         许可或说明="用于与页面导出结果交叉核对（224 格全部一致）"),
    dict(数据源="江苏省统计局《主要统计信息发布指南和目录》",
         内容="官方发布计划，含「2月不发布1月份规模以上工业生产、固定资产投资、"
              "社会消费品零售总额、规模以上服务业营业收入等数据」的制度说明",
         获取方式="官网网页保存",
         类型="官方政策/制度文件",
         规模或时间范围="2025、2026 年度；2 个 HTML",
         采集时间="2026-10-13",
         关联字段="—",
         原始位置=str((MONTHLY_RAW / "policy").relative_to(ROOT)),
         许可或说明="用于支撑月度 1 月「不适用」的状态判定"),
]

FIELDS = ["数据源", "内容", "获取方式", "类型", "规模或时间范围", "采集时间",
          "关联字段", "原始位置", "许可或说明"]


def main() -> None:
    with (DOCS / "data_sources.csv").open("w", encoding="utf-8-sig",
                                          newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(ROWS)
    print(f"{len(ROWS)} sources -> docs/data_sources.csv")


if __name__ == "__main__":
    main()
