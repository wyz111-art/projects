"""Run the quality checks quoted in docs/quality_report.md and print the results."""

from __future__ import annotations

import csv
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import ANNUAL_INTEGRATED, DOCS, MONTHLY_INTEGRATED  # noqa: E402


def read(p: Path) -> list[dict]:
    return list(csv.DictReader(p.open(encoding="utf-8-sig")))


def main() -> None:
    out: dict = {}
    a = read(ANNUAL_INTEGRATED / "annual_city_attributes.csv")
    m = read(MONTHLY_INTEGRATED / "monthly_city_attributes.csv")

    # ---- duplicates ----
    ka = Counter((r["地区"], r["指标代码"], r["统计年份"]) for r in a)
    km = Counter((r["地区"], r["指标代码"], r["子指标名称"], r["统计月份"]) for r in m)
    out["annual_duplicates"] = sum(v - 1 for v in ka.values() if v > 1)
    out["monthly_duplicates"] = sum(v - 1 for v in km.values() if v > 1)

    # ---- magnitude ----
    def vals(code, cond=None):
        got = []
        for r in a:
            if r["指标代码"] != code or r["状态"] != "已确认有数据":
                continue
            if cond and not cond(r):
                continue
            try:
                got.append((r["统计年份"], r["地区"], float(r["数值"])))
            except ValueError:
                pass
        return got

    gc = vals("GREEN_COVER_RATE")
    out["green_cover_rate"] = {"n": len(gc), "min": min(v for _, _, v in gc),
                               "max": max(v for _, _, v in gc),
                               "min_year": min(gc)[0], "max_year": max(gc)[0]}
    pg = vals("PARK_GREEN_PC")
    out["park_green_pc"] = {"n": len(pg), "min": min(v for _, _, v in pg),
                            "max": max(v for _, _, v in pg)}
    gap = [v for _, _, v in gc if not (30 <= v <= 50)]
    out["green_cover_rate_out_of_30_50"] = gap
    pgap = [v for _, _, v in pg if not (6 <= v <= 24)]
    out["park_green_pc_out_of_6_24"] = pgap

    # ---- population year-on-year change ----
    pops = defaultdict(dict)
    for r in a:
        if r["指标代码"] != "POP_YE" or r["状态"] != "已确认有数据":
            continue
        if r["地区"] in ("苏南", "苏中", "苏北"):
            continue
        pops[r["地区"]][r["统计年份"]] = float(r["数值"])
    worst = []
    for reg, d in pops.items():
        ys = sorted(d)
        for y0, y1 in zip(ys, ys[1:]):
            if d[y0]:
                worst.append((abs(d[y1] - d[y0]) / d[y0] * 100, reg, y0, y1))
    worst.sort(reverse=True)
    out["pop_max_yoy_pct"] = [f"{w:.2f}% {reg} {y0}->{y1}" for w, reg, y0, y1 in worst[:5]]

    # ---- industry shares ----
    shares = defaultdict(dict)
    for r in a:
        if r["指标代码"] in ("GDP_P2_SHARE", "GDP_P3_SHARE") and r["状态"] == "已确认有数据":
            shares[(r["地区"], r["统计年份"])][r["指标代码"]] = float(r["数值"])
    bad = []
    for k, d in shares.items():
        if "GDP_P2_SHARE" in d and "GDP_P3_SHARE" in d:
            s = d["GDP_P2_SHARE"] + d["GDP_P3_SHARE"]
            if not (80 <= s < 100):
                bad.append((k, round(s, 2)))
    out["share_sum_out_of_range"] = bad[:10]
    out["share_pairs_checked"] = len(shares)

    # ---- monthly: values parse as numbers, months within target ----
    badv = [r for r in m if r["状态"] == "已确认有数据" and not _isnum(r["数值"])]
    out["monthly_non_numeric"] = len(badv)
    months = sorted({r["统计月份"] for r in m})
    out["monthly_month_range"] = [months[0], months[-1], len(months)]
    out["monthly_status"] = dict(Counter(r["状态"] for r in m))
    out["annual_status"] = dict(Counter(r["状态"] for r in a))

    print(json.dumps(out, ensure_ascii=False, indent=1))
    (DOCS / "quality_checks.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")


def _isnum(s: str) -> bool:
    try:
        float(s)
        return True
    except ValueError:
        return False


if __name__ == "__main__":
    main()
