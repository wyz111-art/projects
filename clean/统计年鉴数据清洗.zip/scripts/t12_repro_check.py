"""Recompute the wide per-city tables from the source long tables and compare
cell by cell with the files on disk. Proves the split is reproducible.

Read-only: writes nothing except a JSON summary under docs/.
"""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"

CITIES = ["南京", "无锡", "徐州", "常州", "苏州", "南通", "连云港",
          "淮安", "盐城", "扬州", "镇江", "泰州", "宿迁"]
CITY_FULL = [c + "市" for c in CITIES]

AN_ORDER = ["年末常住人口(万人)", "城镇化率(%)", "地区生产总值(亿元)",
            "地区生产总值增速(%)", "第一产业增加值(亿元)", "第二产业增加值(亿元)",
            "第三产业增加值(亿元)", "第二产业增加值占GDP比重(%)",
            "第三产业增加值占GDP比重(%)", "人均地区生产总值(元)",
            "建成区绿化覆盖率(%)", "建成区面积(平方公里)", "人均公园绿地面积(平方米)"]
MO_ORDER = ["规模以上工业增加值_同比增长(%)", "规模以上工业增加值_累计增长(%)",
            "规模以上服务业营业收入_累计增长(%)", "固定资产投资_累计增长(%)",
            "社会消费品零售总额_同比增长(%)", "社会消费品零售总额_累计增长(%)"]


def recompute_annual() -> pd.DataFrame:
    src = pd.read_csv(ROOT / "annual" / "integrated" / "annual_city_attributes.csv",
                      dtype=str, keep_default_na=False).fillna("")
    s = src[src["地区"].isin(CITY_FULL)].copy()
    s["列名"] = s["指标名称"] + "(" + s["单位"] + ")"
    w = s.pivot(index=["地区", "统计年份"], columns="列名", values="数值")
    w = w.reindex(columns=AN_ORDER).reset_index()
    w["城市"] = w["地区"].str.replace("市", "", regex=False)
    w["年份"] = w["统计年份"].astype(int)
    return w[["城市", "年份"] + AN_ORDER]


def recompute_monthly() -> pd.DataFrame:
    src = pd.read_csv(ROOT / "monthly" / "integrated" /
                      "monthly_city_attributes_updated.csv",
                      dtype=str, keep_default_na=False).fillna("")
    s = src[src["地区"].isin(CITY_FULL)].copy()
    s["列名"] = (s["指标名称"] + "_" + s["子指标名称"] + "(" + s["单位"] + ")")
    w = s.pivot(index=["地区", "统计月份"], columns="列名", values="数值")
    w = w.reindex(columns=MO_ORDER).reset_index()
    w["城市"] = w["地区"].str.replace("市", "", regex=False)
    w = w.rename(columns={"统计月份": "年月"})
    return w[["城市", "年月"] + MO_ORDER]


def compare(expected: pd.DataFrame, folder: Path, meta: list[str]) -> dict:
    diffs = 0
    checked = 0
    per_city = {}
    for c in CITIES:
        exp = expected[expected["城市"] == c].reset_index(drop=True)
        act = pd.read_csv(folder / f"{c}.csv", dtype=str,
                          keep_default_na=False).fillna("")
        cols = [x for x in exp.columns if x not in meta]
        if len(exp) != len(act):
            per_city[c] = f"行数不符 {len(exp)} vs {len(act)}"
            diffs += 1
            continue
        bad = 0
        for col in cols:
            # a combination absent from the long table pivots to NaN; the CSV
            # stores it as an empty string — treat both as "missing"
            e = exp[col].fillna("").astype(str)
            a = act[col].fillna("").astype(str)
            bad += int((e != a).sum())
        checked += len(exp) * len(cols)
        diffs += bad
        per_city[c] = "一致" if bad == 0 else f"{bad} 格不一致"
    return {"核对单元格": checked, "不一致单元格": diffs, "逐城市": per_city}


def main() -> None:
    out = {
        "annual": compare(recompute_annual(), DATA / "annual", ["城市", "年份"]),
        "monthly": compare(recompute_monthly(), DATA / "monthly", ["城市", "年月"]),
    }
    print(json.dumps(out, ensure_ascii=False, indent=1))
    (ROOT / "docs" / "split_reproducibility.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=1), encoding="utf-8")
    ok = out["annual"]["不一致单元格"] == 0 and out["monthly"]["不一致单元格"] == 0
    print("\n" + ("可复现：源长表重算与磁盘文件完全一致" if ok else "存在差异"))


if __name__ == "__main__":
    main()
