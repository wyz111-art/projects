"""Compact print of docs/split_input_inventory.json."""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
d = json.loads((ROOT / "docs" / "split_input_inventory.json").read_text(encoding="utf-8"))
for kind in ("annual", "monthly"):
    x = d[kind]
    print(f"===== {kind} =====")
    print(f"文件 {x['文件']} | 行数 {x['行数']} | 指标数 {x['指标数']} | "
          f"时间点 {x['时间点个数']} ({x['时间取值范围'][0]}—{x['时间取值范围'][1]})")
    print(f"字段: {x['字段']}")
    print(f"状态: {x['状态分布']}")
    print(f"非空数值 {x['非空数值记录数']} / 空 {x['空数值记录数']} | 重复键 {x['重复键数量']}")
    print(f"缺预期城市: {x['缺少的预期城市']} | 非13市: {x['非13市的城市']}")
    print("指标清单:")
    for i in x["指标清单"]:
        print("   ", " | ".join(i))
    print("每城市记录数/非空数值:")
    for c in sorted(x["每城市记录数"]):
        print(f"    {c}: {x['每城市记录数'][c]} / {x['每城市非空数值数'].get(c, 0)}")
    print()
