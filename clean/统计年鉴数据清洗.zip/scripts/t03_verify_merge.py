"""Verify the updated monthly table against the original: no silent changes.

Reports added / removed / changed records, duplicate keys and conflicts.
"""

from __future__ import annotations

import csv
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT / "monthly" / "integrated" / "monthly_city_attributes.csv"
NEW = ROOT / "monthly" / "integrated" / "monthly_city_attributes_updated.csv"
OUT = ROOT / "docs" / "merge_verification.md"

KEY = ["指标代码", "子指标名称", "地区", "统计月份"]


def read(p: Path) -> list[dict]:
    return list(csv.DictReader(p.open(encoding="utf-8-sig")))


def main() -> None:
    old, new = read(OLD), read(NEW)
    L: list[str] = []

    def say(s: str = "") -> None:
        print(s)
        L.append(s)

    say("# 合并一致性校验\n")
    say(f"- 原表 `{OLD.name}`：{len(old)} 行")
    say(f"- 新表 `{NEW.name}`：{len(new)} 行")
    say("")

    ok_old = Counter(tuple(r[k] for k in KEY) for r in old)
    ok_new = Counter(tuple(r[k] for k in KEY) for r in new)
    say(f"- 唯一键（指标代码+子指标+地区+月份）重复行：原表 "
        f"{sum(v - 1 for v in ok_old.values() if v > 1)}，新表 "
        f"{sum(v - 1 for v in ok_new.values() if v > 1)}")

    ko = {tuple(r[k] for k in KEY): r for r in old}
    kn = {tuple(r[k] for k in KEY): r for r in new}
    added = [k for k in kn if k not in ko]
    removed = [k for k in ko if k not in kn]
    say(f"- 新增记录：{len(added)}")
    say(f"- 删除记录：{len(removed)}")

    changed_num, changed_note, changed_status = [], [], []
    for k in ko:
        if k not in kn:
            continue
        a, b = ko[k], kn[k]
        if a["数值"] != b["数值"]:
            changed_num.append((k, a["数值"], b["数值"]))
        if a["状态"] != b["状态"]:
            changed_status.append((k, a["状态"], b["状态"]))
        if a["备注"] != b["备注"]:
            changed_note.append(k)
    say(f"- **数值发生变化：{len(changed_num)}**（应为 0）")
    say(f"- 状态发生变化：{len(changed_status)}")
    say(f"- 备注发生变化：{len(changed_note)}（预期为之前 12 条“已确认无数据”）")
    say("")

    if changed_num:
        say("| 唯一键 | 旧值 | 新值 |")
        say("|---|---|---|")
        for k, a, b in changed_num:
            say(f"| {'/'.join(k)} | {a} | {b} |")
        say("")

    # conflict check: same key present in both with different source/value
    conflicts = []
    for k in ko:
        if k in kn and ko[k]["数值"] and kn[k]["数值"] and ko[k]["数值"] != kn[k]["数值"]:
            conflicts.append(k)
    say(f"- 同键数值冲突：{len(conflicts)}")
    say("")
    say("> 结论：" + ("未发现数值改动或冲突，仅按计划更新了缺口记录的备注。"
                    if not changed_num and not removed and not conflicts
                    else "存在需要人工复核的差异，见上表。"))

    OUT.write_text("\n".join(L), encoding="utf-8")
    print(f"\n-> {OUT}")


if __name__ == "__main__":
    main()
