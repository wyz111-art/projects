"""Build monthly/integrated/monthly_city_attributes.csv.

Status classification is evidence based:
  * a value in the official export            -> 已确认有数据
  * January                                   -> 不适用
      justified by 《江苏省统计局主要统计信息发布指南和目录》, which states
      "根据统计报表制度，2月不发布1月份规模以上工业生产、工业经济效益、
      固定资产投资、房地产开发和销售、社会消费品零售总额、规模以上服务业
      营业收入等数据"
  * February, the second growth column        -> 不适用 (the February release is the
      combined January-February figure, so only one growth measure exists)
  * missing in the export but present for the same indicator in other cities
                                              -> 已确认无数据
  * anything else                             -> 待核实
"""

from __future__ import annotations

import csv
import html as htmllib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from netutil import MONTHLY_RAW, MONTHLY_INTERIM, MONTHLY_INTEGRATED, fetch, save_raw  # noqa: E402

EXPORT_DIR = MONTHLY_RAW / "export"
PLAN_URLS = [
    ("2026年发布指南", "https://tj.jiangsu.gov.cn/art/2026/1/28/art_85274_11722766.html"),
    ("2025年发布指南", "https://tj.jiangsu.gov.cn/art/2025/1/6/art_85274_11464659.html"),
]

CITY_ROWS = ["南京市", "无锡市", "徐州市", "常州市", "苏州市", "南通市",
             "连云港市", "淮安市", "盐城市", "扬州市", "镇江市", "泰州市", "宿迁市"]
REGION_ROWS = ["苏南", "苏中", "苏北"]
CODE2REG = {"GX3200": "全省", "GX3201": "南京市", "GX3202": "无锡市",
            "GX3203": "徐州市", "GX3204": "常州市", "GX3205": "苏州市",
            "GX3206": "南通市", "GX3207": "连云港市", "GX3208": "淮安市",
            "GX3209": "盐城市", "GX3210": "扬州市", "GX3211": "镇江市",
            "GX3212": "泰州市", "GX3213": "宿迁市"}

IND = {
    "M0101": ("规模以上工业增加值", [("同比增长", "%"), ("累计增长", "%")]),
    "M0201": ("规模以上服务业营业收入", [("累计增长", "%")]),
    "M0301": ("固定资产投资", [("累计增长", "%")]),
    "M0401": ("社会消费品零售总额", [("同比增长", "%"), ("累计增长", "%")]),
}

# 2023-08 .. 2026-07
TARGET_MONTHS = []
for y, m0, m1 in ((2023, 8, 12), (2024, 1, 12), (2025, 1, 12), (2026, 1, 7)):
    for m in range(m0, m1 + 1):
        TARGET_MONTHS.append(f"{y}-{m:02d}")

FIELDS = ["指标代码", "指标名称", "子指标名称", "单位", "地区", "地区代码",
          "统计月份", "数值", "数据来源", "原始链接", "状态", "备注"]


def save_plan_docs() -> dict[str, str]:
    """Persist the official publication-schedule pages used to justify status."""
    out = {}
    for label, url in PLAN_URLS:
        res = fetch(url)
        if res["status"] != 200:
            continue
        save_raw(MONTHLY_RAW / "policy" / f"{label}.html", res["content"], url,
                 bool(res.get("reused")), note=label)
        text = htmllib.unescape(re.sub(r"<[^>]+>", " ", res["text"]))
        text = re.sub(r"\s+", " ", text)
        m = re.search(r"根据统计报表制度[^。]{0,200}。", text)
        out[label] = m.group(0) if m else ""
    return out


def main() -> None:
    rule = save_plan_docs()
    for k, v in rule.items():
        print(f"  规则[{k}]: {v[:110]}")

    idx = list(csv.DictReader(
        (MONTHLY_INTERIM / "monthly_export_index.csv").open(encoding="utf-8-sig")))
    long_rows = list(csv.DictReader(
        (MONTHLY_INTERIM / "monthly_export_long.csv").open(encoding="utf-8-sig")))

    got: dict[tuple, dict] = {}
    for r in long_rows:
        got[(r["指标代码"], r["地区代码"], r["统计月份"], r["子指标名称"])] = r
    present_months: dict[tuple, set] = {}
    for (ind, reg, month, sub) in got:
        present_months.setdefault((ind, reg), set()).add(month)
    # for each (indicator, month, sub-measure): which regions actually carry a value?
    sub_regions: dict[tuple, set] = {}
    for (ind, reg, month, sub) in got:
        sub_regions.setdefault((ind, month, sub), set()).add(reg)

    src = "江苏省统计局统计数据平台·设区市月度（页面导出，时间选择：最近36个月）"
    url = "https://data.jsstjj.cn:30443/pub/easyquery/easyquery.htm?cn=A0201"
    jan_note = ("1月不单独发布：依据《江苏省统计局主要统计信息发布指南和目录》"
                "（2月不发布1月份规上工业、固定资产投资、社会消费品零售总额、"
                "规上服务业营业收入等数据）")

    rows: list[dict] = []
    for ind, (ind_name, subs) in IND.items():
        for code, region in CODE2REG.items():
            for month in TARGET_MONTHS:
                is_jan = month.endswith("-01")
                is_feb = month.endswith("-02")
                for sub, unit in subs:
                    key = (ind, code, month, sub)
                    if key in got:
                        r = got[key]
                        rows.append({"指标代码": ind, "指标名称": ind_name,
                                     "子指标名称": sub, "单位": unit,
                                     "地区": region, "地区代码": code,
                                     "统计月份": month, "数值": r["数值"],
                                     "数据来源": src, "原始链接": url,
                                     "状态": "已确认有数据", "备注": ""})
                        continue
                    month_present = month in present_months.get((ind, code), set())
                    all_regions = sub_regions.get((ind, month, sub), set())
                    others = all_regions - {code}
                    if not month_present and is_jan:
                        status, note = "不适用", jan_note
                    elif not month_present:
                        status, note = "已确认无数据", (
                            "官方导出结果在该地区缺此月份；同指标其他地区该月份有值，"
                            "已核对接口快照同样不含更早的历史月份")
                    elif others and is_feb:
                        status, note = "不适用", ("2月发布的是1—2月合并口径，"
                                                 "仅有累计增长率，另一列不适用")
                    elif others:
                        status, note = "已确认无数据", (
                            "该月份行已发布（同月另一子指标有值），但本子指标为空；"
                            "同指标其他地区该月份该子指标有值")
                    elif is_feb:
                        status, note = "不适用", ("2月发布的是1—2月合并口径，"
                                                 "仅有累计增长率，另一列不适用")
                    else:
                        status, note = "待核实", ("该月该子指标在所有地区均为空且非2月，"
                                                 "原因未能确认")
                    rows.append({"指标代码": ind, "指标名称": ind_name,
                                 "子指标名称": sub, "单位": unit,
                                 "地区": region, "地区代码": code,
                                 "统计月份": month, "数值": "",
                                 "数据来源": src, "原始链接": url,
                                 "状态": status, "备注": note})

    dest = MONTHLY_INTEGRATED / "monthly_city_attributes.csv"
    with dest.open("w", encoding="utf-8-sig", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        w.writerows(rows)
    from collections import Counter
    print(f"{len(rows)} rows -> {dest}")
    print("状态:", dict(Counter(r["状态"] for r in rows)))


if __name__ == "__main__":
    main()
