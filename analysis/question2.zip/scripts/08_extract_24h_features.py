# -*- coding: utf-8 -*-
"""
步骤 8：从原始逐日 CSV 中提取江苏省站点的【完整 24 小时】污染物数据，
聚合成一份紧凑特征文件（不再只取 0/8/16 三个时刻）。

输入：
  - 绔欑偣_20260101-20261031/   逐日 CSV（date,hour,type + 全国站点，24 小时全覆盖）
  - 站点列表-2025.02.25起.xlsx  取江苏站点编码

输出：
  - 江苏站点_24h特征.csv
    每站一行：
      站点编码, 有效记录数,
      PM2.5_mean, PM10_mean, SO2_mean, NO2_mean, O3_mean, CO_mean,   (全年均值)
      PM2.5_h00 ... PM2.5_h23, PM10_h00 ... CO_h23                     (24 小时均值)
"""
import csv
import glob
import os
import sys
import zipfile
from xml.etree import ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
# 目录名有乱码版与正常版两种，find 取第一个存在的
SRC_DIR = find(['绔欑偣_20260101-20261031', '站点_20260101-20261031'],
               desc='逐日 CSV 目录')
STATION_XLSX = find('站点列表-2025.02.25起.xlsx', desc='全国站点列表 xlsx')
OUT = path('江苏站点_24h特征.csv')

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
HOURS = list(range(24))

JS_CITIES = {
    '南京', '无锡', '徐州', '常州', '苏州', '南通', '连云港', '淮安', '盐城',
    '扬州', '镇江', '泰州', '宿迁',
    '昆山', '张家港', '太仓', '常熟', '吴江',
    '江阴', '宜兴', '金坛', '溧阳', '句容', '海门',
}

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'


def jiangsu_codes_from_xlsx(path):
    """从站点列表 xlsx 中取江苏站点编码（保持列表顺序）。"""
    z = zipfile.ZipFile(path)
    ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t'))
              for si in ss.iter(f'{{{NS}}}si')]
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    codes = []
    for row in root.iter(f'{{{NS}}}row'):
        cells = {}
        for c in row.findall(f'{{{NS}}}c'):
            ref = c.get('r')
            col = ''.join(ch for ch in ref if ch.isalpha())
            t = c.get('t')
            v = c.find(f'{{{NS}}}v')
            val = ''
            if v is not None:
                val = v.text or ''
                if t == 's':
                    val = shared[int(val)]
            cells[col] = val
        code = cells.get('A', '')
        if code and code != '监测点编码' and cells.get('C', '') in JS_CITIES:
            codes.append(code)
    return codes


def main():
    js_codes = jiangsu_codes_from_xlsx(STATION_XLSX)
    js_set = set(js_codes)
    print(f'江苏站点编码数: {len(js_codes)}')

    files = sorted(glob.glob(os.path.join(SRC_DIR, 'china_sites_*.csv')))
    print(f'待处理文件数: {len(files)}')

    # acc[code][pollutant] = (sum, count)          全年累计
    # acc[code]['_hour'][pollutant][hour] = (sum, count)  逐小时累计
    acc = {}
    for fi, f in enumerate(files, 1):
        with open(f, encoding='utf-8') as fh:
            r = csv.reader(fh)
            header = next(r)
            idx = [(j, header[j]) for j in range(3, len(header)) if header[j] in js_set]
            for row in r:
                typ = row[2]
                if typ not in POLLUTANTS:
                    continue
                hour = int(row[1])
                for j, code in idx:
                    try:
                        v = float(row[j])
                    except (ValueError, TypeError):
                        continue
                    d = acc.setdefault(code, {})
                    s, c = d.get(typ, (0.0, 0))
                    d[typ] = (s + v, c + 1)
                    hp = d.setdefault('_hour', {}).setdefault(typ, {})
                    hs, hc = hp.get(hour, (0.0, 0))
                    hp[hour] = (hs + v, hc + 1)
        if fi % 100 == 0:
            print(f'  已处理 {fi}/{len(files)}')

    print(f'有数据的站点数: {len(acc)}')

    # 输出特征文件
    cols = (['站点编码', '有效记录数']
            + [f'{p}_mean' for p in POLLUTANTS]
            + [f'{p}_h{h:02d}' for p in POLLUTANTS for h in HOURS])
    rows = []
    for code in js_codes:
        d = acc.get(code)
        if not d:
            continue
        row = {'站点编码': code, '有效记录数': 0}
        total = 0
        for p in POLLUTANTS:
            s, c = d.get(p, (0.0, 0))
            total += c
            row[f'{p}_mean'] = round(s / c, 4) if c > 0 else ''
            for h in HOURS:
                hs, hc = d.get('_hour', {}).get(p, {}).get(h, (0.0, 0))
                row[f'{p}_h{h:02d}'] = round(hs / hc, 4) if hc > 0 else ''
        row['有效记录数'] = total
        rows.append(row)

    rows.sort(key=lambda x: x['站点编码'])
    with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for row in rows:
            w.writerow(row)

    print(f'已生成: {OUT}，共 {len(rows)} 站')
    n_ok = sum(1 for r in rows if r['有效记录数'] >= 1000)
    print(f'有效记录数 ≥ 1000 的站点数: {n_ok}')


if __name__ == '__main__':
    main()
