# -*- coding: utf-8 -*-
"""
步骤 7（分析改进方向）：早晚高峰(8h/16h) 与 夜间(0h) 的污染物差值。

思路：交通相关污染物（NO2、CO、PM）在早晚高峰高于夜间；用「峰值 − 夜间」可
剥离区域背景浓度，突出与道路/交通相关的增量。

对每个站点、每种污染物分别聚合：
  - 夜间均值 night = hour 0 的均值
  - 高峰均值 peak  = hour 8、16 的均值
  - 差值   diff   = peak - night   （可为负）

输出：分析宽表_峰夜差值.csv（结构与 分析宽表.csv 类似，但污染物列为
      {污染物}_night / {污染物}_peak / {污染物}_diff 三组）。
"""
import csv
import glob
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
SRC_DIR = find('江苏站点_0h8h16h', desc='江苏 0/8/16 时 CSV 目录')
BASE_WIDE = find('分析宽表.csv', desc='基础分析宽表')   # 用于取站点信息 + 道路变量
OUT = path('分析宽表_峰夜差值.csv')

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']
BUFFERS = ['500m', '1000m', '2000m']


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def aggregate_hour_groups(src_dir):
    """返回 {站点编码: {污染物: {hour_group: (sum, count)}}}，hour_group∈{night,peak}。"""
    files = sorted(glob.glob(os.path.join(src_dir, '*.csv')))
    acc = {}
    for f in files:
        with open(f, encoding='utf-8') as fh:
            r = csv.reader(fh)
            header = next(r)
            codes = header[3:]
            for row in r:
                typ = row[2]
                if typ not in POLLUTANTS:
                    continue
                hour = row[1]
                if hour == '0':
                    grp = 'night'
                elif hour in ('8', '16'):
                    grp = 'peak'
                else:
                    continue
                for j, code in enumerate(codes):
                    val = to_float(row[3 + j])
                    if val is None:
                        continue
                    d = acc.setdefault(code, {})
                    dd = d.setdefault(typ, {})
                    s, c = dd.get(grp, (0.0, 0))
                    dd[grp] = (s + val, c + 1)
    return acc


def main():
    print('聚合 0h(夜间) 与 8h/16h(高峰) 均值 ...')
    print(f'输入目录: {SRC_DIR}')
    acc = aggregate_hour_groups(SRC_DIR)
    print(f'有数据的站点数: {len(acc)}')

    # 站点信息 + 道路变量（直接复用步骤 4 的宽表）
    base = {}
    with open(BASE_WIDE, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            base[r['站点编码']] = r

    cols = (['站点编码', '站点名称', '城市', '对照点', '经度', '纬度']
            + [f'{p}_{g}' for p in POLLUTANTS for g in ('night', 'peak', 'diff')]
            + ['有效记录数']
            + ['最近道路距离_m', '最近主干距离_m']
            + [f'{b}_{c}_m' for b in BUFFERS for c in ROAD_CLASSES])

    rows = []
    for code, d in acc.items():
        r = base.get(code, {})
        row = {
            '站点编码': code,
            '站点名称': r.get('站点名称', ''),
            '城市': r.get('城市', ''),
            '对照点': r.get('对照点', ''),
            '经度': r.get('经度', ''),
            '纬度': r.get('纬度', ''),
        }
        total_n = 0
        for p in POLLUTANTS:
            dd = d.get(p, {})
            night = peak = diff = ''
            sn, cn = dd.get('night', (0.0, 0))
            sp, cp = dd.get('peak', (0.0, 0))
            total_n += cn + cp
            if cn > 0:
                night = sn / cn
            if cp > 0:
                peak = sp / cp
            if cn > 0 and cp > 0:
                diff = peak - night
            row[f'{p}_night'] = round(night, 3) if isinstance(night, float) else ''
            row[f'{p}_peak'] = round(peak, 3) if isinstance(peak, float) else ''
            row[f'{p}_diff'] = round(diff, 3) if isinstance(diff, float) else ''
        row['有效记录数'] = total_n
        row['最近道路距离_m'] = r.get('最近道路距离_m', '')
        row['最近主干距离_m'] = r.get('最近主干距离_m', '')
        for b in BUFFERS:
            for c in ROAD_CLASSES:
                row[f'{b}_{c}_m'] = r.get(f'{b}_{c}_m', '')
        rows.append(row)

    rows.sort(key=lambda x: x['站点编码'])
    with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    print(f'已生成: {OUT}，共 {len(rows)} 站')
    n_ok = sum(1 for r in rows if all(r[f'{p}_diff'] != '' for p in POLLUTANTS))
    print(f'6 种污染物差值均非空的站点数: {n_ok}')


if __name__ == '__main__':
    main()
