# -*- coding: utf-8 -*-
"""
步骤 2：从「站点_20260101-20261031/」逐日 CSV 中提取江苏省 139 个站点，
只保留每天 0h、8h、16h 三个时刻，输出到「江苏站点_0h8h16h/」。

说明：
  - 原目录名在磁盘上是乱码「绔欑偣_20260101-20261031」（应为「站点」二字），
    脚本里用变量 SRC_DIR 指定，可自行修改。
  - 每个 CSV 是宽表：date, hour, type + 各站点编码列。
  - 江苏站点编码取自「站点列表-2025.02.25起.xlsx」，再与 CSV 表头求交集，
    得到 139 个（列表里 4186A / 4206A / 4249A 三个站点在 CSV 中无数据）。
"""
import csv
import glob
import os
import sys
import zipfile
from xml.etree import ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path, ensure_dir

# 输入目录兼容两种名字：磁盘上的乱码名「绔欑偣_…」与正常名「站点_…」
SRC_DIR = find(['绔欑偣_20260101-20261031', '站点_20260101-20261031'],
               desc='全国逐日 CSV 目录')
STATION_XLSX = find('站点列表-2025.02.25起.xlsx', desc='全国站点列表 xlsx')
OUT_DIR = path('江苏站点_0h8h16h')      # 输出目录（项目根目录下）
KEEP_HOURS = {'0', '8', '16'}          # 只保留这三个整点

# 江苏城市名单（与步骤 1 一致）
JS_CITIES = {
    '南京', '无锡', '徐州', '常州', '苏州', '南通', '连云港', '淮安', '盐城',
    '扬州', '镇江', '泰州', '宿迁',
    '昆山', '张家港', '太仓', '常熟', '吴江',
    '江阴', '宜兴',
    '金坛', '溧阳',
    '句容',
    '海门',
}

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'


def jiangsu_codes_from_xlsx(path):
    """从站点列表 xlsx 中取江苏站点编码（保持列表顺序）。"""
    z = zipfile.ZipFile(path)
    ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t'))
              for si in ss.iter(f'{{{NS}}}si')]
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    codes = []
    for row in root.iter(f'{{{NS}}}row'):
        cells = {}
        for c in row.findall(f'{{{NS}}}c'):
            ref = c.get('r')
            col = ''.join(ch for ch in ref if ch.isalpha())
            t = c.get('t')
            v = c.find(f'{{{NS}}}v')
            val = ''
            if v is not None:
                val = v.text or ''
                if t == 's':
                    val = shared[int(val)]
            cells[col] = val
        code = cells.get('A', '')
        if code and code != '监测点编码' and cells.get('C', '') in JS_CITIES:
            codes.append(code)
    return codes


def main():
    js_codes = jiangsu_codes_from_xlsx(STATION_XLSX)
    js_set = set(js_codes)

    ensure_dir(OUT_DIR)
    files = sorted(glob.glob(os.path.join(SRC_DIR, 'china_sites_*.csv')))
    print(f'输入目录: {SRC_DIR}')
    print(f'待处理文件数: {len(files)}')

    written = 0
    total_rows = 0
    for i, f in enumerate(files, 1):
        bname = os.path.basename(f)
        out_path = os.path.join(OUT_DIR, 'jiangsu_' + bname)
        with open(f, encoding='utf-8') as fin, \
                open(out_path, 'w', encoding='utf-8', newline='') as fout:
            r = csv.reader(fin)
            w = csv.writer(fout)
            header = next(r)
            # 保留 date/hour/type 三列 + 江苏站点列（按原表头顺序）
            keep_idx = [0, 1, 2] + [j for j, c in enumerate(header) if c in js_set]
            w.writerow([header[j] for j in keep_idx])
            n = 0
            for row in r:
                if row[1] in KEEP_HOURS:
                    w.writerow([row[j] for j in keep_idx])
                    n += 1
            total_rows += n
        written += 1
        if i % 50 == 0:
            print(f'  已处理 {i}/{len(files)}')

    print(f'完成！写入 {written} 个文件，共 {total_rows} 数据行（不含表头）。')
    print(f'输出目录: {OUT_DIR}')


if __name__ == '__main__':
    main()
