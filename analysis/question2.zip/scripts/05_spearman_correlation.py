# -*- coding: utf-8 -*-
"""
步骤 5（分析第 1 步）：Spearman 秩相关矩阵。

因变量：6 种污染物（PM2.5 / PM10 / SO2 / NO2 / O3 / CO）的每站周期均值。
自变量：11 个道路变量（3 缓冲区 × 3 道路等级 + 最近道路距离 + 最近主干距离）。

输出：
  - 相关性矩阵_长表.csv   （污染物, 变量, r, p, 显著性）
  - 相关性矩阵_宽表.csv   （行=污染物，列=道路变量，值为 r 带显著性星号）
"""
import csv
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis_lib import spearman
from paths import find, path

# 可通过命令行传入变量后缀与宽表文件，例如：
#   python3 05_spearman_correlation.py _diff 分析宽表_峰夜差值.csv
# 宽表既可以是相对/绝对路径，也可以只写文件名（由 paths 在各候选目录里查找）
SUFFIX = sys.argv[1] if len(sys.argv) > 1 else '_mean'
WIDE_NAME = sys.argv[2] if len(sys.argv) > 2 else '分析宽表.csv'
WIDE = find(WIDE_NAME, desc='分析宽表 CSV')
OUT_LONG = path(f'相关性矩阵_长表{SUFFIX}.csv')
OUT_WIDE = path(f'相关性矩阵_宽表{SUFFIX}.csv')
MIN_RECORDS = 1000   # 有效记录数阈值，剔除几乎无数据的站点

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
BUFFERS = ['500m', '1000m', '2000m']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']
ROAD_VARS = [f'{b}_{c}_m' for b in BUFFERS for c in ROAD_CLASSES] + \
            ['最近道路距离_m', '最近主干距离_m']

# 变量中文标签（用于输出）
VAR_LABELS = {
    '500m_高速/快速路_m': '500m高速', '500m_主干道_m': '500m主干', '500m_次干/支路_m': '500m次干',
    '1000m_高速/快速路_m': '1000m高速', '1000m_主干道_m': '1000m主干', '1000m_次干/支路_m': '1000m次干',
    '2000m_高速/快速路_m': '2000m高速', '2000m_主干道_m': '2000m主干', '2000m_次干/支路_m': '2000m次干',
    '最近道路距离_m': '最近道路距离', '最近主干距离_m': '最近主干距离',
}


def stars(p):
    if p < 0.001:
        return '***'
    if p < 0.01:
        return '**'
    if p < 0.05:
        return '*'
    return ''


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def main():
    rows = []
    with open(WIDE, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            if to_float(r['有效记录数']) >= MIN_RECORDS:
                rows.append(r)
    print(f'用于相关分析的站点数: {len(rows)}')

    long_rows = []
    for p in POLLUTANTS:
        col = f'{p}{SUFFIX}'
        y = [to_float(r[col]) for r in rows]
        for v in ROAD_VARS:
            x = [to_float(r[v]) for r in rows]
            # 去掉任一缺失的配对
            pairs = [(xi, yi) for xi, yi in zip(x, y) if xi is not None and yi is not None]
            if len(pairs) < 3:
                continue
            xx = [a for a, b in pairs]
            yy = [b for a, b in pairs]
            r, pval = spearman(xx, yy)
            long_rows.append({'污染物': p, '变量': VAR_LABELS[v],
                              'Spearman_r': round(r, 4), 'p值': round(pval, 4),
                              '显著性': stars(pval)})

    with open(OUT_LONG, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=['污染物', '变量', 'Spearman_r', 'p值', '显著性'])
        w.writeheader()
        w.writerows(long_rows)

    # 宽表
    with open(OUT_WIDE, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(['污染物'] + [VAR_LABELS[v] for v in ROAD_VARS])
        for p in POLLUTANTS:
            line = [p]
            for v in ROAD_VARS:
                match = next((lr for lr in long_rows
                              if lr['污染物'] == p and lr['变量'] == VAR_LABELS[v]), None)
                if match:
                    line.append(f"{match['Spearman_r']:.3f}{match['显著性']}")
                else:
                    line.append('')
            w.writerow(line)

    print(f'已生成: {OUT_LONG} 和 {OUT_WIDE}')
    print('\n==== Spearman 相关矩阵 (r 值，* p<0.05, ** p<0.01, *** p<0.001) ====')
    header = f"{'污染物':<8}" + ''.join(f'{VAR_LABELS[v]:>10}' for v in ROAD_VARS)
    print(header)
    for p in POLLUTANTS:
        line = f'{p:<8}'
        for v in ROAD_VARS:
            match = next((lr for lr in long_rows
                          if lr['污染物'] == p and lr['变量'] == VAR_LABELS[v]), None)
            if match:
                line += f"{match['Spearman_r']:>7.3f}{match['显著性']:<3}"
            else:
                line += f"{'':>10}"
        print(line)


if __name__ == '__main__':
    main()
