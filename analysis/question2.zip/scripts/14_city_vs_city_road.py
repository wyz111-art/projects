# -*- coding: utf-8 -*-
"""
步骤 15：城市模型 vs 城市+道路模型 的嵌套 F 检验 + FDR 校正。

目的：在保留「城市差异主导」判断的前提下，检验「在已控制城市固定效应的模型里，
再额外加入 3 个道路变量（高速/快速路、主干道、次干/支路，单位 km）」是否显著改善
拟合。若道路项整体不显著，则说明路网密度对站点污染物水平的增量解释力很弱，
主要变异仍来自城市差异——这正是「城市差异主导」的量化依据。

检验内容：
  1. 嵌套 F 检验（6 污染物 × 3 缓冲区 = 18 个）：
       精简模型（城市）     : y ~ 城市哑变量
       完整模型（城市+道路）: y ~ 城市哑变量 + 高速 + 主干 + 次干
       H0: 高速 = 主干 = 次干 = 0
       F = [(SSE_reduced - SSE_full) / (df_reduced - df_full)] / (SSE_full / df_full)
  2. 对 18 个嵌套 F 检验 p 值做 BH-FDR 校正；
  3. 对完整模型中 54 个道路系数检验 p 值同样做 BH-FDR 校正。

命令行参数与脚本 05/06 一致（变量后缀 + 宽表文件）：
  python3 15_city_vs_city_road.py _diff 分析宽表_峰夜差值.csv

输入查找：由 paths.find 按「原样 → 绝对 → 环境变量 ROAD_AQ_DATA_DIR →
项目根 → data/ → scripts/ → CWD」顺序定位，跟启动目录无关。
输出文件：一律落在项目根目录。

输出：
  城市vs城市道路_模型比较{SUFFIX}.csv    18 个嵌套 F 检验结果（含 FDR）
  道路系数_FDR校正{SUFFIX}.csv          54 个道路系数检验结果（含 FDR）
"""
import csv
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis_lib import ols, f_pvalue, bh_fdr
from paths import find, path as out_path

SUFFIX = sys.argv[1] if len(sys.argv) > 1 else '_mean'
WIDE = sys.argv[2] if len(sys.argv) > 2 else '分析宽表.csv'

OUT_COMPARE = out_path(f'城市vs城市道路_模型比较{SUFFIX}.csv')
OUT_COEF = out_path(f'道路系数_FDR校正{SUFFIX}.csv')
MIN_RECORDS = 1000

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
BUFFERS = ['500m', '1000m', '2000m']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def aic_bic(n, k, sse):
    """AIC 与 BIC（基于 SSE 的高斯对数似然，同因变量下可比较）。"""
    if sse <= 0 or n <= 0:
        return None, None
    ll = n * math.log(sse / n)
    return ll + 2.0 * k, ll + k * math.log(n)


def design(rows, use_roads, buf, other_cities, has_ctrl, ctrl_values):
    """构建设计矩阵；use_roads=True 时在截距后追加 3 个道路变量(km)。"""
    X = []
    for i, r in enumerate(rows):
        xrow = [1.0]
        if use_roads:
            xrow += [to_float(r[f'{buf}_{c}_m']) / 1000.0 for c in ROAD_CLASSES]
        xrow += [1.0 if r['城市'] == c else 0.0 for c in other_cities]
        if has_ctrl:
            xrow.append(ctrl_values[i])
        X.append(xrow)
    return X


def main():
    wide_path = find(WIDE, desc='分析宽表 CSV')
    print(f'输入宽表: {wide_path}')

    rows = []
    with open(wide_path, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            if to_float(r['有效记录数']) >= MIN_RECORDS:
                rows.append(r)
    n = len(rows)
    print(f'用于回归的站点数: {n}')

    cities = sorted({r['城市'] for r in rows if r['城市']})
    ref_city = max(cities, key=lambda c: sum(1 for r in rows if r['城市'] == c))
    other_cities = [c for c in cities if c != ref_city]
    print(f'城市数: {len(cities)}，参照城市: {ref_city}，哑变量数: {len(other_cities)}')

    ctrl_values = [1.0 if r['对照点'] == 'Y' else 0.0 for r in rows]
    has_ctrl = len(set(ctrl_values)) > 1
    print(f'对照点变量: {"纳入模型" if has_ctrl else "剔除（无方差）"}')

    compare_rows = []
    coef_rows = []

    for p in POLLUTANTS:
        y_raw = [to_float(r[f'{p}{SUFFIX}']) for r in rows]
        # 差值变量可能为负/零，不能用对数；均值变量全为正时才用 log
        if SUFFIX == '_diff':
            use_log = False
        else:
            use_log = all(v is not None and v > 0 for v in y_raw)
        y = [math.log(v) if use_log else v for v in y_raw]
        transform = 'log' if use_log else 'raw'

        for buf in BUFFERS:
            X_city = design(rows, False, buf, other_cities, has_ctrl, ctrl_values)
            X_full = design(rows, True, buf, other_cities, has_ctrl, ctrl_values)
            res_city = ols(X_city, y)
            res_full = ols(X_full, y, vif_cols=[1, 2, 3])

            # 嵌套 F 检验：在控制城市后，3 个道路变量是否整体显著
            sse_r = res_city['sse']
            sse_f = res_full['sse']
            df_r = n - res_city['k']
            df_f = n - res_full['k']
            df1 = df_r - df_f          # 应为 3
            df2 = df_f
            if df1 > 0 and df2 > 0 and sse_f > 1e-300:
                fstat = ((sse_r - sse_f) / df1) / (sse_f / df2)
                fp = f_pvalue(fstat, df1, df2)
            else:
                fstat = 0.0
                fp = 1.0
            delta_r2 = res_full['r2'] - res_city['r2']
            aic_c, bic_c = aic_bic(n, res_city['k'], res_city['sse'])
            aic_f, bic_f = aic_bic(n, res_full['k'], res_full['sse'])

            compare_rows.append({
                '污染物': p,
                '缓冲区': buf,
                '因变量变换': transform,
                'n': n,
                'R2_城市': round(res_city['r2'], 4),
                'R2_城市道路': round(res_full['r2'], 4),
                'ΔR2': round(delta_r2, 4),
                'AIC_城市': round(aic_c, 2) if aic_c is not None else '',
                'AIC_城市道路': round(aic_f, 2) if aic_f is not None else '',
                'BIC_城市': round(bic_c, 2) if bic_c is not None else '',
                'BIC_城市道路': round(bic_f, 2) if bic_f is not None else '',
                'F': round(fstat, 4),
                'df1': df1,
                'df2': df2,
                'p_raw': round(fp, 4),
            })

            # 完整模型中的道路系数（稍后统一做 FDR）
            for j, cls in enumerate(ROAD_CLASSES):
                coef_rows.append({
                    '污染物': p,
                    '缓冲区': buf,
                    '道路等级': cls,
                    '系数': round(res_full['beta'][1 + j], 4),
                    'se': round(res_full['se'][1 + j], 4),
                    'p_raw': round(res_full['p'][1 + j], 4),
                })

    # ---- BH-FDR：18 个嵌套 F 检验 ----
    f_q = bh_fdr([r['p_raw'] for r in compare_rows])
    for r, q in zip(compare_rows, f_q):
        r['p_FDR'] = round(q, 4)
        r['显著(FDR<0.05)'] = '是' if q < 0.05 else '否'

    # ---- BH-FDR：54 个道路系数检验 ----
    c_q = bh_fdr([r['p_raw'] for r in coef_rows])
    for r, q in zip(coef_rows, c_q):
        r['p_FDR'] = round(q, 4)
        r['显著(FDR<0.05)'] = '是' if q < 0.05 else '否'

    # ---- 写出比较表（落在项目根目录） ----
    cmp_cols = ['污染物', '缓冲区', '因变量变换', 'n',
                'R2_城市', 'R2_城市道路', 'ΔR2',
                'AIC_城市', 'AIC_城市道路', 'BIC_城市', 'BIC_城市道路',
                'F', 'df1', 'df2', 'p_raw', 'p_FDR', '显著(FDR<0.05)']
    with open(OUT_COMPARE, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cmp_cols)
        w.writeheader()
        for r in compare_rows:
            w.writerow(r)

    coef_cols = ['污染物', '缓冲区', '道路等级', '系数', 'se',
                 'p_raw', 'p_FDR', '显著(FDR<0.05)']
    with open(OUT_COEF, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=coef_cols)
        w.writeheader()
        for r in coef_rows:
            w.writerow(r)

    # ---- 控制台摘要 ----
    print(f'已生成: {OUT_COMPARE}（{len(compare_rows)} 个嵌套 F 检验）')
    print(f'已生成: {OUT_COEF}（{len(coef_rows)} 个道路系数检验）')
    print('\n==== 城市 vs 城市+道路：嵌套 F 检验摘要 ====')
    print(f"{'污染物':<7}{'缓冲区':<7}{'R²城市':>8}{'ΔR²':>8}{'F':>8}{'p_raw':>8}{'p_FDR':>8}  显著")
    for r in compare_rows:
        print(f"{r['污染物']:<7}{r['缓冲区']:<7}{r['R2_城市']:>8}{r['ΔR2']:>8}"
              f"{r['F']:>8}{r['p_raw']:>8}{r['p_FDR']:>8}  {r['显著(FDR<0.05)']}")

    n_sig_f = sum(1 for r in compare_rows if r['显著(FDR<0.05)'] == '是')
    n_sig_c = sum(1 for r in coef_rows if r['显著(FDR<0.05)'] == '是')
    print(f'\nFDR<0.05 的嵌套 F 检验: {n_sig_f}/18；道路系数检验: {n_sig_c}/54')
    if n_sig_f == 0:
        print('结论：控制城市后加入道路变量未显著改善拟合 → 支持「城市差异主导」判断。')
    else:
        print('结论：个别模型在控制城市后道路变量仍显著，需结合缓冲区和污染物解读。')


if __name__ == '__main__':
    main()