# -*- coding: utf-8 -*-
"""
纯 Python 统计分析 / 线性代数工具库（无 numpy/scipy/statsmodels）。

包含：
  - rankdata / spearman：Spearman 秩相关（含 p 值）
  - 不完全 Beta 函数、t 分布 CDF、p 值计算
  - 矩阵运算：转置、乘法、逆（高斯-约当，部分主元）
  - OLS 回归（含标准误、t 值、p 值、R²、VIF）
"""
import math

# ---------------- 秩相关 ----------------

def rankdata(a):
    """返回数组 a 的秩（1-based，并列取平均秩）。"""
    n = len(a)
    order = sorted(range(n), key=lambda i: a[i])
    ranks = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j < n and a[order[j]] == a[order[i]]:
            j += 1
        avg = (i + j - 1) / 2.0 + 1.0
        for k in range(i, j):
            ranks[order[k]] = avg
        i = j
    return ranks


def pearson(x, y):
    n = len(x)
    mx = sum(x) / n
    my = sum(y) / n
    sxx = sum((xi - mx) ** 2 for xi in x)
    syy = sum((yi - my) ** 2 for yi in y)
    sxy = sum((xi - mx) * (yi - my) for xi, yi in zip(x, y))
    if sxx == 0 or syy == 0:
        return 0.0
    return sxy / math.sqrt(sxx * syy)


def spearman(x, y):
    """返回 (Spearman r, 双尾 p 值)。"""
    n = len(x)
    if n < 3:
        return 0.0, 1.0
    rx = rankdata(x)
    ry = rankdata(y)
    r = pearson(rx, ry)
    r = max(-1.0, min(1.0, r))
    if abs(r) >= 1.0:
        return r, 0.0
    t = r * math.sqrt((n - 2) / (1 - r * r))
    p = t_two_tail(t, n - 2)
    return r, p


# ---------------- t 分布 / 不完全 Beta ----------------

def betacf(a, b, x):
    """不完全 Beta 函数的连分式（Numerical Recipes）。"""
    MAXIT = 200
    EPS = 3e-14
    FPMIN = 1e-300
    qab = a + b
    qap = a + 1.0
    qam = a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < EPS:
            break
    return h


def betai(a, b, x):
    """正则化不完全 Beta 函数 I_x(a, b)。"""
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
                  + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * betacf(a, b, x) / a
    return 1.0 - bt * betacf(b, a, 1.0 - x) / b


def t_cdf(t, df):
    """Student t 分布累积分布函数。"""
    if df <= 0:
        return 0.5
    x = df / (df + t * t)
    ib = betai(df / 2.0, 0.5, x)
    return 1.0 - 0.5 * ib if t > 0 else 0.5 * ib


def t_two_tail(t, df):
    """双尾 p 值。"""
    return 2.0 * (1.0 - t_cdf(abs(t), df))


# ---------------- 矩阵运算 ----------------

def transpose(A):
    return [[A[i][j] for i in range(len(A))] for j in range(len(A[0]))]


def mat_mul(A, B):
    n = len(B)
    p = len(B[0])
    return [[sum(A[i][k] * B[k][j] for k in range(n)) for j in range(p)]
            for i in range(len(A))]


def mat_inv(A):
    n = len(A)
    M = [row[:] + [1.0 if i == j else 0.0 for j in range(n)]
         for i, row in enumerate(A)]
    for col in range(n):
        piv = max(range(col, n), key=lambda r: abs(M[r][col]))
        if abs(M[piv][col]) < 1e-15:
            raise ValueError('矩阵奇异，无法求逆')
        M[col], M[piv] = M[piv], M[col]
        d = M[col][col]
        M[col] = [x / d for x in M[col]]
        for r in range(n):
            if r != col:
                f = M[r][col]
                if f != 0.0:
                    M[r] = [M[r][j] - f * M[col][j] for j in range(2 * n)]
    return [row[n:] for row in M]


# ---------------- OLS 回归 ----------------

def ols(X, y, vif_cols=None):
    """
    普通最小二乘回归。
    X: n×k 设计矩阵（含截距列）；y: 长度 n 的因变量。
    返回 dict: beta, se, t, p, r2, adj_r2, n, k, vif(dict: 列索引->VIF)。
    """
    n = len(y)
    k = len(X[0])
    Xt = transpose(X)
    XtX = mat_mul(Xt, X)
    inv = mat_inv(XtX)
    Xty = mat_mul(Xt, [[yi] for yi in y])
    beta = [row[0] for row in mat_mul(inv, Xty)]

    yhat = [sum(X[i][j] * beta[j] for j in range(k)) for i in range(n)]
    resid = [y[i] - yhat[i] for i in range(n)]
    sse = sum(r * r for r in resid)
    df = n - k
    s2 = sse / df if df > 0 else 0.0
    se = [math.sqrt(inv[j][j] * s2) for j in range(k)]
    tstat = [beta[j] / se[j] if se[j] > 1e-300 else 0.0 for j in range(k)]
    pvals = [t_two_tail(tstat[j], df) if df > 0 else 1.0 for j in range(k)]

    ymean = sum(y) / n
    sst = sum((yi - ymean) ** 2 for yi in y)
    r2 = 1.0 - sse / sst if sst > 0 else 0.0
    adj_r2 = 1.0 - (1.0 - r2) * (n - 1) / df if df > 0 else 0.0

    vif = {}
    if vif_cols:
        for j in vif_cols:
            # 用其余所有列解释第 j 列
            Xj = [X[i][j] for i in range(n)]
            Xo = [[X[i][c] for c in range(k) if c != j] for i in range(n)]
            try:
                rj = ols(Xo, Xj)['r2']
                vif[j] = 1.0 / (1.0 - rj) if rj < 1.0 else float('inf')
            except ValueError:
                vif[j] = float('inf')

    return {'beta': beta, 'se': se, 't': tstat, 'p': pvals,
            'r2': r2, 'adj_r2': adj_r2, 'n': n, 'k': k, 'vif': vif,
            'sse': sse, 'sst': sst}
