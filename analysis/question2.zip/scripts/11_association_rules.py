# -*- coding: utf-8 -*-
"""
步骤 11：关联规则挖掘（Apriori）。

把连续变量离散化成“项”，每个站点看成一条事务，挖掘频繁项集与关联规则：
  污染物（高 = 上四分位数以上）：
    PM2.5高 / PM10高 / SO2高 / NO2高 / O3高 / CO高
  道路环境：
    主干近   （最近主干距离 ≤ 下四分位数，即 25% 最近）
    邻近高速 （500m 缓冲区内存在高速/快速路，即长度 > 0）
    路网密集 （1000m 内道路总长 ≥ 上四分位数）
  区域：
    苏南 / 苏中 / 苏北

输入：江苏站点_24h特征.csv + 站点-道路叠加分析.csv
输出：
  - 关联_频繁项集.csv   支持度满足阈值的项集
  - 关联_规则.csv       antecedent -> consequent，含支持度/置信度/提升度
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dm_lib import apriori, association_rules
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
FEAT24 = find('江苏站点_24h特征.csv', desc='步骤 8 产出的 24h 特征')
ROAD_CSV = find('站点-道路叠加分析.csv', desc='步骤 3 产出的站点-道路叠加表')
OUT_ITEMSET = path('关联_频繁项集.csv')
OUT_RULES = path('关联_规则.csv')
POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
MIN_SUPPORT = 0.12      # 至少约 10 个站点同时出现
MIN_CONFIDENCE = 0.6

SU_NAN = {'南京', '苏州', '无锡', '常州', '镇江'}
SU_ZHONG = {'南通', '扬州', '泰州'}
SU_BEI = {'徐州', '连云港', '淮安', '盐城', '宿迁'}


def read_csv_dict(path):
    with open(path, encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def quantile(a, q):
    s = sorted(a)
    n = len(s)
    idx = q * (n - 1)
    lo = int(idx)
    hi = min(lo + 1, n - 1)
    frac = idx - lo
    return s[lo] * (1 - frac) + s[hi] * frac


def main():
    feat = {r['站点编码']: r for r in read_csv_dict(FEAT24)}
    road = {r['站点编码']: r for r in read_csv_dict(ROAD_CSV)}

    codes = [c for c, f in feat.items()
             if int(f['有效记录数']) >= 1000
             and all(num(f[f'{p}_mean']) is not None for p in POLLUTANTS)]
    codes.sort()
    n = len(codes)
    print(f'有效站点数: {n}')

    # 各连续变量的分位数阈值
    th = {}
    for p in POLLUTANTS:
        th[p] = quantile([num(feat[c][f'{p}_mean']) for c in codes], 0.75)
    th['主干距离'] = quantile([num(road[c]['最近主干距离_m']) for c in codes], 0.25)
    th['1000m总长'] = quantile(
        [num(road[c]['1000m内总长_m']) for c in codes], 0.75)

    # 构造事务
    transactions = []
    for c in codes:
        items = set()
        for p in POLLUTANTS:
            if num(feat[c][f'{p}_mean']) >= th[p]:
                items.add(f'{p}高')
        if num(road[c]['最近主干距离_m']) <= th['主干距离']:
            items.add('主干近')
        if num(road[c]['500m_高速/快速路_m']) > 0:
            items.add('邻近高速')
        if num(road[c]['1000m内总长_m']) >= th['1000m总长']:
            items.add('路网密集')
        city = road[c].get('城市', '')
        if city in SU_NAN:
            items.add('苏南')
        elif city in SU_ZHONG:
            items.add('苏中')
        elif city in SU_BEI:
            items.add('苏北')
        transactions.append(frozenset(items))

    freq = apriori(transactions, MIN_SUPPORT)

    # 输出频繁项集
    with open(OUT_ITEMSET, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(['项集大小', '项集', '支持度', '站点数'])
        for level in freq:
            for itemset, supp in level:
                w.writerow([len(itemset), '&'.join(sorted(itemset)),
                            round(supp, 3), round(supp * n)])
    print('已生成 ' + OUT_ITEMSET)

    # 生成规则
    rules = association_rules(transactions, freq, MIN_CONFIDENCE)
    with open(OUT_RULES, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.writer(fh)
        w.writerow(['前件', '后件', '支持度', '置信度', '提升度'])
        for r in rules:
            w.writerow(['&'.join(sorted(r['antecedent'])),
                        '&'.join(sorted(r['consequent'])),
                        round(r['support'], 3),
                        round(r['confidence'], 3),
                        round(r['lift'], 3)])
    print(f'已生成 {OUT_RULES}，规则数: {len(rules)}')

    # 控制台打印 top 规则
    print('\n提升度最高的 15 条规则：')
    for r in rules[:15]:
        ant = '&'.join(sorted(r['antecedent']))
        con = '&'.join(sorted(r['consequent']))
        print(f'  {ant}  =>  {con}  (sup={r["support"]:.2f}, '
              f'conf={r["confidence"]:.2f}, lift={r["lift"]:.2f})')


if __name__ == '__main__':
    main()
