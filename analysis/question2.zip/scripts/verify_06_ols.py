# verify_06_ols.py
import csv, math, sys, os
import numpy as np
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

SUFFIX = sys.argv[1] if len(sys.argv) > 1 else '_mean'
WIDE_NAME = sys.argv[2] if len(sys.argv) > 2 else '分析宽表.csv'
WIDE = find(WIDE_NAME, desc='分析宽表 CSV')
OUT = path(f'复核_OLS{SUFFIX}.csv')

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
BUFFERS = ['500m', '1000m', '2000m']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']
MIN_RECORDS = 1000


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


rows = []
with open(WIDE, encoding='utf-8-sig') as fh:
    for r in csv.DictReader(fh):
        if to_float(r['有效记录数']) >= MIN_RECORDS:
            rows.append(r)

n = len(rows)
print(f'用于复核的站点数: {n}')
if n < 10:
    sys.exit('站点数不足')

cities = sorted({r['城市'] for r in rows if r['城市']})
ref_city = max(cities, key=lambda c: sum(1 for r in rows if r['城市'] == c))
other_cities = [c for c in cities if c != ref_city]

ctrl = np.array([1.0 if r['对照点'] == 'Y' else 0.0 for r in rows])
has_ctrl = len(set(ctrl)) > 1
print(f'城市数: {len(cities)}，参照城市: {ref_city}，哑变量数: {len(other_cities)}')
print(f'对照点(Y): {int(ctrl.sum())}', '(有方差)' if has_ctrl else '(无方差，剔除)')

out_rows = []
for p in POLLUTANTS:
    y_raw = np.array([to_float(r[f'{p}{SUFFIX}']) for r in rows], dtype=float)
    if SUFFIX == '_diff':
        use_log = False
    else:
        use_log = bool(np.all(y_raw > 0))
    y = np.log(y_raw) if use_log else y_raw

    for buf in BUFFERS:
        road_km = np.array([
            [to_float(r[f'{buf}_{c}_m']) / 1000.0 for c in ROAD_CLASSES]
            for r in rows
        ], dtype=float)
        city_dummies = np.array([
            [1.0 if r['城市'] == c else 0.0 for c in other_cities]
            for r in rows
        ], dtype=float)

        parts = [road_km, city_dummies]
        if has_ctrl:
            parts.append(ctrl[:, None])
        X = np.column_stack(parts)
        X = sm.add_constant(X)

        model = sm.OLS(y, X).fit()
        # VIF：仅对道路三列（截距后索引 1,2,3），与原脚本 vif_cols=[1,2,3] 对应
        X_vif = X[:, [1, 2, 3]]
        vifs = [variance_inflation_factor(X_vif, j) for j in range(3)]

        row = {
            '污染物': p, '缓冲区': buf,
            'n': n,
            'R2': round(model.rsquared, 6),
            '调整R2': round(model.rsquared_adj, 6),
        }
        for j, cls in enumerate(ROAD_CLASSES):
            b = model.params[1 + j]
            pct = (math.exp(b) - 1) * 100 if use_log else None
            row[f'{cls}_系数'] = round(b, 6)
            row[f'{cls}_se'] = round(model.bse[1 + j], 6)
            row[f'{cls}_p'] = round(model.pvalues[1 + j], 6)
            row[f'{cls}_每km%'] = round(pct, 4) if pct is not None else ''
            row[f'{cls}_VIF'] = round(vifs[j], 4)
        if has_ctrl:
            row['对照点_系数'] = round(model.params[-1], 6)
            row['对照点_p'] = round(model.pvalues[-1], 6)
        else:
            row['对照点_系数'] = ''
            row['对照点_p'] = ''
        out_rows.append(row)

cols = ['污染物', '缓冲区', 'n', 'R2', '调整R2']
for cls in ROAD_CLASSES:
    cols += [f'{cls}_系数', f'{cls}_se', f'{cls}_p', f'{cls}_每km%', f'{cls}_VIF']
cols += ['对照点_系数', '对照点_p']

with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    w.writerows(out_rows)

print(f'已生成: {OUT}')
print('\n==== 前 3 个回归的 statsmodels 结果 ====')
for r in out_rows[:3]:
    print({k: r[k] for k in ['污染物', '缓冲区', 'R2', '高速/快速路_系数',
                             '高速/快速路_p', '高速/快速路_VIF']})