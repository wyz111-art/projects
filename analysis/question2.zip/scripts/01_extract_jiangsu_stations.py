# -*- coding: utf-8 -*-
"""
步骤 1：从「站点列表-2025.02.25起.xlsx」中提取江苏省站点，生成「站点列表-江苏.xlsx」。

说明：
  - 原表为 xlsx（本质是 zip + XML），这里不依赖 openpyxl/pandas，
    直接解析 sharedStrings.xml 和 sheet1.xml。
  - 江苏城市名单 = 13 个地级市 + 数据中出现的县级市。
  - 输出保留 6 列：监测点编码 / 监测点名称 / 城市 / 经度 / 纬度 / 对照点，
    其中经度、纬度保留为数值类型。
"""
import os
import sys
import zipfile
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

# 输入/输出路径都由 paths 解析：不再依赖当前工作目录，项目整体移动也能找到文件
SRC = find('站点列表-2025.02.25起.xlsx', desc='全国站点列表 xlsx')
OUT = path('站点列表-江苏.xlsx')

# 江苏城市名单（地级市 + 县级市，县级市按所属地级市分组）
JS_CITIES = {
    '南京', '无锡', '徐州', '常州', '苏州', '南通', '连云港', '淮安', '盐城',
    '扬州', '镇江', '泰州', '宿迁',
    # 苏州下辖县级市/区
    '昆山', '张家港', '太仓', '常熟', '吴江',
    # 无锡
    '江阴', '宜兴',
    # 常州
    '金坛', '溧阳',
    # 镇江
    '句容',
    # 南通
    '海门',
}

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'


def read_xlsx_cells(path):
    """读取 xlsx 第一个工作表，返回 [ {列字母: 值}, ... ]，首行为表头。"""
    z = zipfile.ZipFile(path)
    ss_root = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t'))
              for si in ss_root.iter(f'{{{NS}}}si')]
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    rows = []
    for row in root.iter(f'{{{NS}}}row'):
        cells = {}
        for c in row.findall(f'{{{NS}}}c'):
            ref = c.get('r')
            col = ''.join(ch for ch in ref if ch.isalpha())
            t = c.get('t')
            v = c.find(f'{{{NS}}}v')
            val = ''
            if v is not None:
                val = v.text or ''
                if t == 's':
                    val = shared[int(val)]
            cells[col] = val
        rows.append(cells)
    return rows


def cell_xml(col, r, value, is_number=False):
    ref = f'{col}{r}'
    if is_number:
        return f'<c r="{ref}"><v>{value}</v></c>'
    return f'<c r="{ref}" t="inlineStr"><is><t>{escape(str(value))}</t></is></c>'


def write_xlsx(path, header, data_rows, sheet_name='江苏站点'):
    """用最小 xlsx 结构写出数据（inlineStr 文本 + 数值单元格）。"""
    rows_xml = []
    rows_xml.append('<row r="1">' + ''.join(
        cell_xml(ch, 1, v) for ch, v in zip('ABCDEF', header)) + '</row>')
    for i, r in enumerate(data_rows, start=2):
        cells = ''
        for ch, key, isnum in [('A', 'A', False), ('B', 'B', False), ('C', 'C', False),
                               ('D', 'D', True), ('E', 'E', True), ('F', 'F', False)]:
            v = r.get(key, '')
            if isnum:
                try:
                    v = float(v)
                    cells += cell_xml(ch, i, repr(v), True)
                except (ValueError, TypeError):
                    cells += cell_xml(ch, i, v, False)
            else:
                cells += cell_xml(ch, i, v, False)
        rows_xml.append(f'<row r="{i}">' + cells + '</row>')

    sheet_xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                 '<sheetData>' + ''.join(rows_xml) + '</sheetData></worksheet>')

    content_types = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>'''

    rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>'''

    workbook_xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="''' + sheet_name + '''" sheetId="1" r:id="rId1"/></sheets>
</workbook>'''

    workbook_rels = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>'''

    styles_xml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"/>'''

    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as out:
        out.writestr('[Content_Types].xml', content_types)
        out.writestr('_rels/.rels', rels)
        out.writestr('xl/workbook.xml', workbook_xml)
        out.writestr('xl/_rels/workbook.xml.rels', workbook_rels)
        out.writestr('xl/styles.xml', styles_xml)
        out.writestr('xl/worksheets/sheet1.xml', sheet_xml)


def main():
    rows = read_xlsx_cells(SRC)
    header = rows[0]
    data = rows[1:]
    filtered = [r for r in data if r.get('C', '') in JS_CITIES]
    write_xlsx(OUT, [header.get(k, '') for k in 'ABCDEF'], filtered)
    print(f'江苏站点数: {len(filtered)}')
    print(f'已生成: {OUT}')


if __name__ == '__main__':
    main()
