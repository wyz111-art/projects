# -*- coding: utf-8 -*-
"""
步骤 6（分析第 2 步）：城市固定效应多元回归。

对每个污染物（6 种）× 每个缓冲区（500/1000/2000m）分别建模（共 18 个）：

    ln(污染物) = β0 + β1·高速 + β2·主干 + β3·次干 + Σ城市哑变量 + δ·对照点 + ε

道路长度单位为 km，故 β 的指数化 (e^β - 1)×100% 表示
「该等级道路每增加 1 km，污染物浓度变化的百分比」。

输出：回归结果汇总.csv
"""
import csv
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from analysis_lib import ols
from paths import find, path

# 可通过命令行传入变量后缀与宽表文件，例如：
#   python3 06_fixed_effects_regression.py _diff 分析宽表_峰夜差值.csv
# 宽表既可以是相对/绝对路径，也可以只写文件名（由 paths 在各候选目录里查找）
SUFFIX = sys.argv[1] if len(sys.argv) > 1 else '_mean'
WIDE_NAME = sys.argv[2] if len(sys.argv) > 2 else '分析宽表.csv'
WIDE = find(WIDE_NAME, desc='分析宽表 CSV')
OUT = path(f'回归结果汇总{SUFFIX}.csv')
MIN_RECORDS = 1000

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
BUFFERS = ['500m', '1000m', '2000m']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def main():
    rows = []
    with open(WIDE, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            if to_float(r['有效记录数']) >= MIN_RECORDS:
                rows.append(r)
    n = len(rows)
    print(f'用于回归的站点数: {n}')

    cities = sorted({r['城市'] for r in rows if r['城市']})
    ref_city = max(cities, key=lambda c: sum(1 for r in rows if r['城市'] == c))
    other_cities = [c for c in cities if c != ref_city]
    print(f'城市数: {len(cities)}，参照城市: {ref_city}，哑变量数: {len(other_cities)}')

    # 对照点分布；若在样本中无方差（全为 N），则需剔除该变量
    ctrl_values = [1.0 if r['对照点'] == 'Y' else 0.0 for r in rows]
    has_ctrl = len(set(ctrl_values)) > 1
    n_ctrl = sum(ctrl_values)
    print(f'对照点(Y)数量: {n_ctrl}', '(有方差)' if has_ctrl else '(无方差，将从模型剔除)')
    if not has_ctrl:
        print('注意：81 站样本中所有站点对照点均为 N（对照点站点本身没有监测数据）。')

    out_rows = []
    for p in POLLUTANTS:
        y_raw = [to_float(r[f'{p}{SUFFIX}']) for r in rows]
        # 差值变量可能为负/零，不能用对数；均值变量全为正时才用 log
        if SUFFIX == '_diff':
            use_log = False
        else:
            use_log = all(v is not None and v > 0 for v in y_raw)
        y = [math.log(v) if use_log else v for v in y_raw]
        transform = 'log' if use_log else 'raw'

        for buf in BUFFERS:
            # 设计矩阵：截距 + 3 道路变量(km) + 城市哑变量 + 对照点
            X = []
            for i, r in enumerate(rows):
                road_km = [to_float(r[f'{buf}_{c}_m']) / 1000.0 for c in ROAD_CLASSES]
                city_dummies = [1.0 if r['城市'] == c else 0.0 for c in other_cities]
                xrow = [1.0] + road_km + city_dummies
                if has_ctrl:
                    xrow.append(ctrl_values[i])
                X.append(xrow)

            res = ols(X, y, vif_cols=[1, 2, 3])

            def fmt(v, d=4):
                return round(v, d) if v is not None else ''

            row = {
                '污染物': p,
                '缓冲区': buf,
                '因变量变换': transform,
                'n': res['n'],
                'R2': round(res['r2'], 4),
                '调整R2': round(res['adj_r2'], 4),
            }
            for j, cls in enumerate(ROAD_CLASSES):
                b = res['beta'][1 + j]
                pct = (math.exp(b) - 1.0) * 100.0 if use_log else b
                row[f'{cls}_系数'] = fmt(b, 4)
                row[f'{cls}_se'] = fmt(res['se'][1 + j], 4)
                row[f'{cls}_p'] = fmt(res['p'][1 + j], 4)
                row[f'{cls}_每km%'] = fmt(pct, 2) if use_log else ''
                row[f'{cls}_VIF'] = fmt(res['vif'].get(1 + j), 2)
            # 对照点系数（最后一列，若该变量被剔除则留空）
            if has_ctrl:
                row['对照点_系数'] = fmt(res['beta'][-1], 4)
                row['对照点_p'] = fmt(res['p'][-1], 4)
            else:
                row['对照点_系数'] = ''
                row['对照点_p'] = ''
            out_rows.append(row)

    with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
        cols = ['污染物', '缓冲区', '因变量变换', 'n', 'R2', '调整R2']
        for cls in ROAD_CLASSES:
            cols += [f'{cls}_系数', f'{cls}_se', f'{cls}_p', f'{cls}_每km%', f'{cls}_VIF']
        cols += ['对照点_系数', '对照点_p']
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        w.writerows(out_rows)

    print(f'已生成: {OUT}，共 {len(out_rows)} 个回归')
    print('\n==== 汇总（仅看显著项） ====')
    print(f"{'污染物':<7}{'缓冲区':<7}{'R²':>7}{'高速β':>9}{'主干β':>9}{'次干β':>9}")
    for r in out_rows:
        def star(p):
            try:
                pv = float(p)
            except (ValueError, TypeError):
                return ''
            return '*' if pv < 0.05 else ''
        print(f"{r['污染物']:<7}{r['缓冲区']:<7}{r['R2']:>7}"
              f"{float(r['高速/快速路_系数']):>9.3f}{star(r['高速/快速路_p'])}"
              f"{float(r['主干道_系数']):>9.3f}{star(r['主干道_p'])}"
              f"{float(r['次干/支路_系数']):>9.3f}{star(r['次干/支路_p'])}")


if __name__ == '__main__':
    main()
