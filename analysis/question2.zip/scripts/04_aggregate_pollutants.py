# -*- coding: utf-8 -*-
"""
步骤 4（分析第 0 步）：聚合污染物数据 + 合并道路变量，生成分析用宽表。

输入：
  - 江苏站点_0h8h16h/         逐日 CSV（date,hour,type + 139 站，仅 0/8/16 时）
  - 站点-道路叠加分析.csv       每站道路变量（步骤 3 产出）
  - 站点列表-2025.02.25起.xlsx  取「对照点」标记

输出：
  - 分析宽表.csv   （139 站 × [6 污染物均值 + 道路变量 + 控制变量]）
"""
import csv
import glob
import os
import sys
import zipfile
from xml.etree import ElementTree as ET

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
SRC_DIR = find('江苏站点_0h8h16h', desc='江苏 0/8/16 时 CSV 目录')
ROAD_CSV = find('站点-道路叠加分析.csv', desc='道路叠加分析结果')
STATION_XLSX = find('站点列表-2025.02.25起.xlsx', desc='全国站点列表 xlsx')
OUT = path('分析宽表.csv')

# 6 种污染物（AQI 是指数，不算；_24h / O3_8h 是滑动均值，不用）
POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']

# 参与分析的 3 类道路（服务性、其他不算）× 3 缓冲区
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']
BUFFERS = ['500m', '1000m', '2000m']

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'


def read_control_flag(path):
    """返回 {站点编码: 对照点}。"""
    z = zipfile.ZipFile(path)
    ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
    shared = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t'))
              for si in ss.iter(f'{{{NS}}}si')]
    root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
    flag = {}
    for row in root.iter(f'{{{NS}}}row'):
        cells = {}
        for c in row.findall(f'{{{NS}}}c'):
            ref = c.get('r')
            col = ''.join(ch for ch in ref if ch.isalpha())
            t = c.get('t')
            v = c.find(f'{{{NS}}}v')
            val = ''
            if v is not None:
                val = v.text or ''
                if t == 's':
                    val = shared[int(val)]
            cells[col] = val
        code = cells.get('A', '')
        if code and code != '监测点编码':
            flag[code] = cells.get('F', '')
    return flag


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def aggregate_pollutants(src_dir):
    """返回 {站点编码: {污染物: (总和, 计数)}}。"""
    files = sorted(glob.glob(os.path.join(src_dir, '*.csv')))
    acc = {}
    for f in files:
        with open(f, encoding='utf-8') as fh:
            r = csv.reader(fh)
            header = next(r)
            codes = header[3:]
            for row in r:
                typ = row[2]
                if typ not in POLLUTANTS:
                    continue
                for j, code in enumerate(codes):
                    val = to_float(row[3 + j])
                    if val is None:
                        continue
                    d = acc.setdefault(code, {})
                    s, c = d.get(typ, (0.0, 0))
                    d[typ] = (s + val, c + 1)
    return acc


def main():
    print('聚合污染物小时数据 ...')
    print(f'输入目录: {SRC_DIR}')
    acc = aggregate_pollutants(SRC_DIR)
    print(f'有数据的站点数: {len(acc)}')

    # 道路变量
    road = {}
    with open(ROAD_CSV, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            road[r['站点编码']] = r

    # 对照点
    flag = read_control_flag(STATION_XLSX)

    # 合并
    cols = (['站点编码', '站点名称', '城市', '对照点', '经度', '纬度']
            + [f'{p}_mean' for p in POLLUTANTS]
            + ['有效记录数']
            + ['最近道路距离_m', '最近主干距离_m']
            + [f'{b}_{c}_m' for b in BUFFERS for c in ROAD_CLASSES])

    rows = []
    for code, d in acc.items():
        r = road.get(code, {})
        means = {}
        total_n = 0
        for p in POLLUTANTS:
            s, c = d.get(p, (None, 0))
            total_n += c
            means[p] = (s / c) if c > 0 else ''
        row = {
            '站点编码': code,
            '站点名称': r.get('站点名称', ''),
            '城市': r.get('城市', ''),
            '对照点': flag.get(code, ''),
            '经度': r.get('经度', ''),
            '纬度': r.get('纬度', ''),
        }
        for p in POLLUTANTS:
            v = means[p]
            row[f'{p}_mean'] = (round(v, 3) if isinstance(v, float) else '')
        row['有效记录数'] = total_n
        row['最近道路距离_m'] = r.get('最近道路距离_m', '')
        row['最近主干距离_m'] = r.get('最近主干距离_m', '')
        for b in BUFFERS:
            for c in ROAD_CLASSES:
                row[f'{b}_{c}_m'] = r.get(f'{b}_{c}_m', '')
        rows.append(row)

    rows.sort(key=lambda x: x['站点编码'])
    with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for row in rows:
            w.writerow(row)

    print(f'已生成: {OUT}，共 {len(rows)} 站')
    # 数据完整性统计
    n_complete = sum(1 for r in rows if all(r[f'{p}_mean'] != '' for p in POLLUTANTS))
    print(f'6 种污染物均非空的站点数: {n_complete}')


if __name__ == '__main__':
    main()
