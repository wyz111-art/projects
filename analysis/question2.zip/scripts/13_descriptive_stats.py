# -*- coding: utf-8 -*-
"""
步骤 13：六种污染物的描述性统计。

两个层面：
  1. 站点年均值层面（分析单元，n=81 站）：给出完整统计量
     样本量 / 缺失数 / 均值 / 标准差 / 变异系数 / 最小值 / P25 / 中位数 / P75 / 最大值 / 偏度 / 峰度
  2. 逐小时原始值层面：从原始 CSV 直接累计 n / 均值 / 标准差 / 最小值 / 最大值

输入：
  - 江苏站点_24h特征.csv          站点年均值
  - 绔欑偣_20260101-20261031/      原始逐小时数据

输出：
  - 描述性统计_站点年均值.csv
  - 描述性统计_小时值.csv
"""
import csv
import glob
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dm_lib import mean, std, median, quantile, skew, kurtosis
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
FEAT24 = find('江苏站点_24h特征.csv', desc='步骤 8 产出的 24h 特征')
# 目录名有乱码版与正常版两种，find 取第一个存在的
SRC_DIR = find(['绔欑偣_20260101-20261031', '站点_20260101-20261031'],
               desc='逐日 CSV 目录')
OUT_STATION = path('描述性统计_站点年均值.csv')
OUT_HOURLY = path('描述性统计_小时值.csv')
POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
UNITS = {'PM2.5': 'μg/m³', 'PM10': 'μg/m³', 'SO2': 'μg/m³',
         'NO2': 'μg/m³', 'O3': 'μg/m³', 'CO': 'mg/m³'}


def read_csv_dict(csv_path):
    with open(csv_path, encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def describe(values):
    """返回列表 values 的完整描述统计 dict。"""
    n = len(values)
    if n == 0:
        return None
    m = mean(values)
    s = std(values)
    return {
        '样本量': n,
        '均值': round(m, 3),
        '标准差': round(s, 3),
        '变异系数%': round(100 * s / m, 2) if m != 0 else 0.0,
        '最小值': round(min(values), 3),
        'P25': round(quantile(values, 0.25), 3),
        '中位数': round(median(values), 3),
        'P75': round(quantile(values, 0.75), 3),
        '最大值': round(max(values), 3),
        '偏度': round(skew(values), 3),
        '峰度': round(kurtosis(values), 3),
    }


def station_level():
    """站点年均值层面。"""
    feat = read_csv_dict(FEAT24)
    # 有效站点：≥1000 记录且 6 污染物齐全
    valid = [r for r in feat
             if int(r['有效记录数']) >= 1000
             and all(num(r[f'{p}_mean']) is not None for p in POLLUTANTS)]
    print(f'有效站点数: {len(valid)}（原始共 {len(feat)} 站有数据）')

    rows = []
    for p in POLLUTANTS:
        vals = [num(r[f'{p}_mean']) for r in valid]
        d = describe(vals)
        d['污染物'] = p
        d['单位'] = UNITS[p]
        d['缺失站数'] = len(feat) - len(vals)
        rows.append(d)

    cols = ['污染物', '单位', '样本量', '缺失站数', '均值', '标准差', '变异系数%',
            '最小值', 'P25', '中位数', 'P75', '最大值', '偏度', '峰度']
    with open(OUT_STATION, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f'已生成 {OUT_STATION}')
    return rows, cols


def hourly_level(js_codes):
    """逐小时原始值层面（一次遍历累计，不存原始值），只统计江苏站点。"""
    js_set = set(js_codes)
    files = sorted(glob.glob(os.path.join(SRC_DIR, 'china_sites_*.csv')))
    # 每个污染物：n, sum, sumsq, min, max
    acc = {p: {'n': 0, 'sum': 0.0, 'sumsq': 0.0,
               'min': float('inf'), 'max': float('-inf')} for p in POLLUTANTS}
    for fi, f in enumerate(files, 1):
        with open(f, encoding='utf-8') as fh:
            r = csv.reader(fh)
            header = next(r)
            idx = [j for j, c in enumerate(header) if c in js_set]
            for row in r:
                typ = row[2]
                if typ not in POLLUTANTS:
                    continue
                a = acc[typ]
                for j in idx:
                    v = row[j]
                    if v == '':
                        continue
                    try:
                        x = float(v)
                    except ValueError:
                        continue
                    a['n'] += 1
                    a['sum'] += x
                    a['sumsq'] += x * x
                    if x < a['min']:
                        a['min'] = x
                    if x > a['max']:
                        a['max'] = x
        if fi % 150 == 0:
            print(f'  已处理 {fi}/{len(files)}')

    rows = []
    for p in POLLUTANTS:
        a = acc[p]
        n = a['n']
        m = a['sum'] / n if n else 0.0
        var = (a['sumsq'] - a['sum'] ** 2 / n) / (n - 1) if n > 1 else 0.0
        rows.append({
            '污染物': p, '单位': UNITS[p], '样本量': n,
            '均值': round(m, 3), '标准差': round(math.sqrt(var), 3),
            '最小值': round(a['min'], 3), '最大值': round(a['max'], 3),
        })

    cols = ['污染物', '单位', '样本量', '均值', '标准差', '最小值', '最大值']
    with open(OUT_HOURLY, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f'已生成 {OUT_HOURLY}')
    return rows, cols


def print_table(rows, cols):
    header = ' | '.join(cols)
    print('\n' + header)
    print('-+-'.join('-' * len(c) for c in cols))
    for r in rows:
        print(' | '.join(str(r.get(c, '')) for c in cols))


if __name__ == '__main__':
    print('== 层面 1：站点年均值（n=81 站）==')
    rows1, cols1 = station_level()
    print_table(rows1, cols1)

    # 江苏站点编码（与站点年均值同口径：有效 81 站）
    feat = read_csv_dict(FEAT24)
    js_codes = [r['站点编码'] for r in feat
                if int(r['有效记录数']) >= 1000
                and all(num(r[f'{p}_mean']) is not None for p in POLLUTANTS)]

    print(f'\n== 层面 2：逐小时原始值（江苏 {len(js_codes)} 站）==')
    rows2, cols2 = hourly_level(js_codes)
    print_table(rows2, cols2)
