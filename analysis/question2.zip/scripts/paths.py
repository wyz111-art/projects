# -*- coding: utf-8 -*-
"""
统一路径解析：让所有脚本不再依赖「当前工作目录」，也不再写死任何绝对路径。

核心思路
--------
项目根目录 = 本文件（scripts/paths.py）所在目录的上一级。
因此整个「问题二」文件夹整体复制/移动到任何位置（含中文路径、含空格路径），
脚本都能自己找到同级的数据文件，无论从哪个目录用 python 启动。

输入文件查找顺序（find）
------------------------
  1. 按传入的名字原样判断（相对名字按当前工作目录解析）——显式路径优先
  2. 绝对路径
  3. 环境变量 ROAD_AQ_DATA_DIR 中列出的目录（多个用 os.pathsep 分隔）
  4. 项目根目录
  5. 项目根目录下的 data/ 子目录
  6. scripts/ 目录自身
  7. 当前工作目录

输出文件（path）
----------------
一律落在项目根目录，便于整包移动后结果仍在同一处，
并与原有行为（在根目录下运行、输出写在根目录）保持一致。

用法
----
    from paths import find, path, ensure_dir

    SRC = find('站点列表-2025.02.25起.xlsx')          # 输入：必须存在，找不到会报清晰的错
    SRC2 = find(['绔欑偣_20260101-20261031',           # 输入：多个候选名，取第一个存在的
                 '站点_20260101-20261031'])
    OUT = path('分析宽表.csv')                          # 输出：项目根目录/分析宽表.csv
    ensure_dir(OUT_DIR)                                 # 建目录（已存在则跳过）
"""
import os

# 本文件所在目录：.../问题二：道路密度与空气质量/scripts
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
# 项目根目录：scripts 的上一级，数据与结果都在这一级
PROJECT_ROOT = os.path.dirname(SCRIPT_DIR)


def _extra_dirs():
    """环境变量 ROAD_AQ_DATA_DIR 指定的额外数据目录（可多个）。"""
    raw = os.environ.get('ROAD_AQ_DATA_DIR', '')
    return [p.strip().strip('"').strip("'")
            for p in raw.split(os.pathsep) if p.strip()]


def search_dirs():
    """返回输入文件可能所在的目录（已去重、已规范化，按优先级排列）。"""
    dirs = _extra_dirs() + [
        PROJECT_ROOT,
        os.path.join(PROJECT_ROOT, 'data'),
        SCRIPT_DIR,
        os.getcwd(),
    ]
    seen = set()
    out = []
    for d in dirs:
        try:
            d = os.path.abspath(d)
        except (TypeError, ValueError):
            continue
        if d not in seen:
            seen.add(d)
            out.append(d)
    return out


def path(name):
    """把文件名解析成「项目根目录下」的绝对路径（不检查是否存在）。"""
    if os.path.isabs(name):
        return name
    return os.path.join(PROJECT_ROOT, name)


def find(names, desc=None):
    """
    查找输入文件或输入目录，返回其绝对路径；找不到时抛出带搜索目录清单的错误。

    names : str 或 list[str]，多个名字时按顺序取第一个存在的（可用于兼容乱码名/正常名）。
    desc  : 可选的说明，用于错误信息（例如「站点列表 xlsx」）。
    """
    if isinstance(names, str):
        names = [names]

    tried = []
    for name in names:
        # 1) 原样判断（相对名字按当前工作目录）
        if os.path.exists(name):
            return os.path.abspath(name)
        # 2) 绝对路径（不存在时无需再拼接）
        if os.path.isabs(name):
            tried.append(name)
            continue
        # 3) 依次在各候选目录中查找
        for d in search_dirs():
            cand = os.path.join(d, name)
            tried.append(cand)
            if os.path.exists(cand):
                return cand

    label = f'（{desc}）' if desc else ''
    lines = [f'找不到输入{label}: ' + ' / '.join(names),
             '已尝试以下位置：']
    lines += ['  ' + t for t in tried]
    lines += [
        '如果文件在别处，请把该文件（或所在目录）放进项目根目录：',
        f'  {PROJECT_ROOT}',
        '或用环境变量指定额外数据目录（多个目录用系统路径分隔符隔开）：',
        '  Windows : set ROAD_AQ_DATA_DIR=D:\\我的数据',
        '  Linux/macOS: export ROAD_AQ_DATA_DIR=/path/to/data',
    ]
    raise FileNotFoundError('\n'.join(lines))


def ensure_dir(target):
    """建目录（接受目录名或文件路径；传入文件路径时建其父目录）。"""
    d = target
    if not os.path.isdir(d):
        d = os.path.dirname(os.path.abspath(d))
    os.makedirs(d, exist_ok=True)
    return d


def describe():
    """返回一段便于打印的路径说明，出错时方便核对。"""
    return f'项目根目录: {PROJECT_ROOT}\n当前工作目录: {os.getcwd()}'
