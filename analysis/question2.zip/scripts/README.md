# 江苏空气质量站点 × 道路网络分析 —— 脚本说明

本目录保存了完整处理流程的代码。**脚本不依赖当前工作目录，也不写死任何绝对路径**：
无论从哪个目录启动、无论整个项目文件夹被复制/移动到哪台机器或哪个路径（含中文、空格），
脚本都会自己定位到「项目根目录」= 本 `scripts/` 目录的上一级，据此寻找输入、写出结果。
所有路径解析集中在 `paths.py`（见下文「路径约定」）。

> 环境说明：本机无 numpy / pandas / statsmodels / openpyxl，也没有 pip，
> 所以所有脚本都只用 Python 标准库（zipfile / sqlite3 / csv / struct / math 等）实现。

## 脚本清单

| 脚本 | 作用 | 输入 | 输出 |
|------|------|------|------|
| `01_extract_jiangsu_stations.py` | 从全国站点列表筛出江苏站点 | `站点列表-2025.02.25起.xlsx` | `站点列表-江苏.xlsx`（142 站） |
| `02_extract_jiangsu_hours.py` | 提取江苏 139 站、每天 0/8/16 时 | `绔欑偣_20260101-20261031/`（逐日 CSV） | `江苏站点_0h8h16h/`（300 文件） |
| `03_spatial_overlay.py` | 站点经纬度 × 道路网络叠加分析 | `jiangsu_roads_clean.gpkg` + 站点列表 | `站点-道路叠加分析.csv`（142 行） |
| `analysis_lib.py` | 纯 Python 统计/线代库（Spearman、t 分布、OLS） | — | 被 05/06 引用 |
| `paths.py` | 统一路径解析（项目根目录定位、输入查找、输出落盘） | — | 被所有脚本引用 |
| `04_aggregate_pollutants.py` | 聚合 6 污染物小时均值 + 合并道路变量 | `江苏站点_0h8h16h/` + 叠加分析表 | `分析宽表.csv`（87 站） |
| `05_spearman_correlation.py` | Spearman 秩相关矩阵 | `分析宽表.csv` | `相关性矩阵_长表.csv` / `_宽表.csv` |
| `06_fixed_effects_regression.py` | 城市固定效应回归（18 模型） | `分析宽表.csv` | `回归结果汇总.csv` |
| `07_peak_night_difference.py` | 早晚高峰(8/16h)与夜间(0h)差值聚合 | `江苏站点_0h8h16h/` + `分析宽表.csv` | `分析宽表_峰夜差值.csv` |

> 脚本 05/06 支持命令行传入「变量后缀 + 宽表文件」，可复用到差值变量：
> ```bash
> python scripts/05_spearman_correlation.py _diff 分析宽表_峰夜差值.csv
> python scripts/06_fixed_effects_regression.py _diff 分析宽表_峰夜差值.csv
> ```
> 第二个参数写文件名即可（由 `paths.py` 在各候选目录里查找），也可传相对/绝对路径。

## 路径约定（`paths.py`）

所有脚本都不再自己拼路径，统一通过 `paths.py` 解析：

| 需求 | 写法 | 行为 |
|------|------|------|
| 找输入文件/目录 | `find('文件名')` | 依次在「当前路径原样 → 绝对路径 → `ROAD_AQ_DATA_DIR` → 项目根目录 → `根目录/data` → `scripts/` → 当前工作目录」查找，返回绝对路径；找不到时报错并列出所有试过的位置 |
| 同名多候选 | `find(['绔欑偣_20260101-20261031', '站点_20260101-20261031'])` | 取第一个存在的（兼容乱码目录名与正常目录名） |
| 输出文件 | `path('分析宽表.csv')` | 一律写到项目根目录，整包搬家后结果仍在同一处 |
| 建输出目录 | `ensure_dir(OUT_DIR)` | 已存在则跳过 |

- **项目根目录** = `scripts/paths.py` 所在目录的上一级，即「问题二：道路密度与空气质量」这一层。
  所以**保持 `scripts/` 与数据文件在同一层**即可，文件夹随便改名、随便移动。
- 输入文件放在项目目录之外时，两种办法：
  1. 设环境变量指定额外数据目录（可多个，用系统路径分隔符隔开，且优先于项目根目录查找）：
     ```powershell
     # Windows PowerShell
     $env:ROAD_AQ_DATA_DIR = "D:\数据;E:\另一个数据目录"
     python scripts/04_aggregate_pollutants.py
     ```
     ```bash
     # Linux / macOS
     export ROAD_AQ_DATA_DIR=/path/to/data
     ```
  2. 大文件（如 2 GB 的道路 gpkg）用命令行参数显式指定，免去复制：
     ```bash
     python scripts/03_spatial_overlay.py --gpkg "/path/to/jiangsu_roads_clean.gpkg"
     ```

## 运行顺序

```bash
# 在任意目录下都可以执行（脚本自己定位项目根目录）
python scripts/01_extract_jiangsu_stations.py   # 可选，生成江苏站点表
python scripts/02_extract_jiangsu_hours.py      # 可选，生成 0/8/16 时数据
python scripts/03_spatial_overlay.py            # 核心：叠加分析（gpkg 不在项目目录时用 --gpkg）
```

以下是相对路径版（等价，仅当当前目录就在项目根目录时有效）：

```bash
python scripts/01_extract_jiangsu_stations.py
python scripts/02_extract_jiangsu_hours.py
python scripts/03_spatial_overlay.py
```

## 关键实现细节

### 1. xlsx 的读取与写出（无 openpyxl）
- xlsx 本质是 zip 包，`xl/sharedStrings.xml` 存共享字符串，`xl/worksheets/sheet1.xml` 存单元格。
- 读：解析 XML 得到 `{列字母: 值}`。
- 写：用「inlineStr」单元格 + 最小 xlsx 结构（Content_Types、workbook、worksheet、styles）。

### 2. 目录名乱码
输入目录在磁盘上名为 `绔欑偣_20260101-20261031`，是「站点」二字被 GBK 误解码的结果。
`02_extract_jiangsu_hours.py` 用 `find(['绔欑偣_…', '站点_…'])` 两种名字都试，正常名或乱码名都能读到。

### 3. GPKG 道路几何解析
- `jiangsu_roads_clean.gpkg` 是 GeoPackage（SQLite 底层），含 6 张道路表 + RTree 空间索引。
- 坐标系 EPSG:32650（UTM 50N，单位米）。
- 几何以 GPKG 二进制格式存于 `geom` 列：`'GP'` 魔数 + 版本 + flags + srs_id + 包络 + 标准 WKB。
  - flags 的 bit0 = 包络字节序（0=大端，1=小端），bits1-3 = 包络维度指示（1=XY 4个double）。
- WKB 为 MultiLineString，逐段解析出坐标点。

### 4. 坐标投影
站点经纬度是 WGS84（EPSG:4326），道路是 UTM 50N。脚本用横轴墨卡托公式把站点
投影到 UTM 50N（中央经线 117°E，假东 500000m），才能与道路做米制距离计算。

### 5. 空间分析内容（对每个站点）
- 最近道路距离 / 等级 / 名称（RTree 迭代扩半径搜索，保证找到真最近）
- 最近主干道（高速/快速路 + 主干道）距离
- 500 / 1000 / 2000 m 缓冲区内道路总长，并按 5 等级拆分
  （等级：高速/快速路、主干道、次干/支路、服务性道路、其他）
  - 线段与圆相交长度用「二次方程求根 + 参数区间裁剪」精确计算。

## 数据文件（项目根目录，即 `scripts/` 的上一级）

- `站点列表-2025.02.25起.xlsx`：全国 2127 个空气质量监测站点
- `jiangsu_roads_clean.gpkg`：江苏省 OSM 道路（约 51.6 万段，27 万公里）
  —— 体积约 2 GB，可不放在项目里，运行时用 `--gpkg` 指向实际位置
- `绔欑偣_20260101-20261031/`：全国站点逐小时污染物数据（2026-01-01 ~ 10-31）
  （脚本同时兼容正常名 `站点_20260101-20261031/`）
- `江苏站点_0h8h16h/`：提取后的江苏站点 0/8/16 时数据
- `站点-道路叠加分析.csv`：叠加分析结果

## 运行顺序（完整）

```bash
# 任意工作目录下执行均可
python scripts/01_extract_jiangsu_stations.py
python scripts/02_extract_jiangsu_hours.py
python scripts/03_spatial_overlay.py            # gpkg 不在项目内时：--gpkg "/path/to/jiangsu_roads_clean.gpkg"
python scripts/04_aggregate_pollutants.py
python scripts/05_spearman_correlation.py
python scripts/06_fixed_effects_regression.py
python scripts/07_peak_night_difference.py
```

## 分析结果要点（截至 2026-11）

**数据可用性（重要）**：
- 江苏 142 站中，有污染物数据的仅 **87 站**；其中 6 站几乎无数据（有效记录 <100），
  有效样本 **81 站**（13 个地级市，县级市站点基本全部无数据）。
- **18 个对照点(Y)站点全部无监测数据**，因此无法把「对照点」作为控制变量（已从模型剔除）。

**Spearman 相关**：整体相关很弱，仅少数显著：
- O3 与 500m 主干负相关（-0.222*，符合 NO 滴定效应）；
- PM2.5 与 2000m 高速/次干负相关（-0.236* / -0.219*，疑似城市结构混杂）；
- SO2 与最近道路距离正相关（0.259*，工业源特征）。

**固定效应回归（18 模型）**：
- 城市哑变量解释了绝大部分方差（R²：PM2.5 0.89、PM10 0.77、SO2 0.71、NO2 0.70、O3 0.47、CO 0.31）；
- **控制城市后，3 类道路长度在 500/1000/2000m 均无显著效应（p<0.05）**，
  仅个别边缘显著（SO2×次干 p≈0.05、NO2×2000m p≈0.08）。
- 结论：在当前样本（81 站、仅 0/8/16 时、10 个月均值）下，缓冲区内路网密度
  对污染物年均水平的解释力很弱，主要变异来自城市差异。

**局限**：
- 样本从 139 缩到 81，县级市与对照点全缺失；
- 只用 0/8/16 三个时刻，O3 等日变化强的污染物代表性不足；
- 未纳入气象、工业、人口等混杂变量。

## 峰夜差值分析（步骤 7）

用「高峰(8h/16h)均值 − 夜间(0h)均值」试图剥离区域背景、突出交通增量。

**结果（81 站）**：
- 交通标志物 NO2 的峰夜差值反而为负（夜间 23.5 > 高峰 19.1 μg/m³，仅 5% 站点为正），
  说明夜间逆温层使污染物近地累积，0h 并非干净的「低交通基线」；
- O3 峰夜差 +18.3（100% 为正），来自午后光化学，与道路无关；
- Spearman 仅 SO2×1000m主干显著（-0.232*）；回归仅 SO2×1000m主干显著（p=0.003），
  NO2/CO 等交通标志物均不显著。
- 结论：在 0/8/16 三个时刻 + 81 站条件下，峰夜差值也无法显著识别道路密度效应；
  根本限制是夜间逆温与缺少真高峰/中午时段，以及道路密度并非真实车流量。
