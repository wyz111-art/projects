# verify_05_spearman.py
import csv, sys, os
import numpy as np
from scipy.stats import spearmanr

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path

# ===== 与原脚本保持一致的配置 =====
SUFFIX = sys.argv[1] if len(sys.argv) > 1 else '_mean'
WIDE_NAME = sys.argv[2] if len(sys.argv) > 2 else '分析宽表.csv'
WIDE = find(WIDE_NAME, desc='分析宽表 CSV')
OUT = path(f'复核_Spearman{SUFFIX}.csv')

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
BUFFERS = ['500m', '1000m', '2000m']
ROAD_CLASSES = ['高速/快速路', '主干道', '次干/支路']
ROAD_VARS = [f'{b}_{c}_m' for b in BUFFERS for c in ROAD_CLASSES] + \
            ['最近道路距离_m', '最近主干距离_m']
MIN_RECORDS = 1000

VAR_LABELS = {
    '500m_高速/快速路_m': '500m高速', '500m_主干道_m': '500m主干', '500m_次干/支路_m': '500m次干',
    '1000m_高速/快速路_m': '1000m高速', '1000m_主干道_m': '1000m主干', '1000m_次干/支路_m': '1000m次干',
    '2000m_高速/快速路_m': '2000m高速', '2000m_主干道_m': '2000m主干', '2000m_次干/支路_m': '2000m次干',
    '最近道路距离_m': '最近道路距离', '最近主干距离_m': '最近主干距离',
}


def to_float(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def stars(p):
    if p < 0.001: return '***'
    if p < 0.01:  return '**'
    if p < 0.05:  return '*'
    return ''


rows = []
with open(WIDE, encoding='utf-8-sig') as fh:
    for r in csv.DictReader(fh):
        if to_float(r['有效记录数']) >= MIN_RECORDS:
            rows.append(r)

print(f'用于复核的站点数: {len(rows)}')
if len(rows) < 3:
    sys.exit('站点数不足')

out_rows = []
for p in POLLUTANTS:
    y = np.array([to_float(r[f'{p}{SUFFIX}']) for r in rows], dtype=float)
    for v in ROAD_VARS:
        x = np.array([to_float(r[v]) for r in rows], dtype=float)
        mask = ~np.isnan(x) & ~np.isnan(y)
        if mask.sum() < 3:
            continue
        rho, pval = spearmanr(x[mask], y[mask])   # SciPy 标准实现
        out_rows.append({
            '污染物': p,
            '变量': VAR_LABELS[v],
            'Spearman_r': round(float(rho), 6),
            'p值': round(float(pval), 6),
            '显著性': stars(pval),
            'n': int(mask.sum()),
        })

with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.DictWriter(fh, fieldnames=['污染物', '变量', 'Spearman_r', 'p值', '显著性', 'n'])
    w.writeheader()
    w.writerows(out_rows)

print(f'已生成: {OUT}')
print('\n==== SciPy spearmanr 复核结果（前 12 行） ====')
for r in out_rows[:12]:
    print(r)