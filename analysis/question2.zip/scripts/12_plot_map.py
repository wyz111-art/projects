# -*- coding: utf-8 -*-
"""
步骤 12：把三套聚类结果画成江苏地图（纯 Python 生成 SVG，无需 matplotlib）。

底图 = 道路网络（gpkg 抽样，浅灰线，勾勒江苏轮廓）；散点 = 站点，按簇着色；
城市标签 = 各城市站点质心。

输入：
  - 聚类结果_污染画像.csv / 聚类结果_道路环境.csv / 聚类结果_日变化模式.csv
  - 站点-道路叠加分析.csv   （取 UTM_X / UTM_Y 用于与道路同坐标系绘图）
  - jiangsu_roads_clean.gpkg（道路底图，抽样）

输出：
  - 地图_污染画像.svg / 地图_道路环境.svg / 地图_日变化模式.svg
  - 地图_汇总.html   （把三张图并排嵌入，浏览器直接打开）
"""
import csv
import sqlite3
import struct
import math
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path


def arg_value(flag):
    """取命令行参数 --flag=值 或 --flag 值 中的值；未给出返回 None。"""
    for i, a in enumerate(sys.argv):
        if a.startswith(flag + '='):
            return a.split('=', 1)[1]
        if a == flag and i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None


# 输入/输出路径由 paths 解析，与当前工作目录无关
# 道路 gpkg 约 2 GB、通常放在项目目录之外，可用 --gpkg 显式指定：
#   python 12_plot_map.py --gpkg "D:/数据/jiangsu_roads_clean.gpkg"
# 未指定时按 paths 的搜索规则（项目根目录 → data/ → scripts/ → 当前目录）查找
GPKG = find(arg_value('--gpkg') or 'jiangsu_roads_clean.gpkg',
            desc='道路网络 GeoPackage（可用 --gpkg 指定路径）')
ROAD_CSV = find('站点-道路叠加分析.csv', desc='步骤 3 产出的站点-道路叠加表')

# 各聚类的簇配色与图例
TASKS = {
    '污染画像': {
        'csv': '聚类结果_污染画像.csv',
        'colors': {0: '#2E86AB', 1: '#E8A628', 2: '#C94C4C'},
        'legend': {0: '簇0 交通/生活型（苏南，NO₂·CO 高）',
                   1: '簇1 工业/燃煤型（苏中苏北，SO₂ 高）',
                   2: '簇2 高颗粒物型（苏北西部，PM 高）'},
        'title': '江苏空气质量站点 · 污染画像聚类（K=3）',
    },
    '道路环境': {
        'csv': '聚类结果_道路环境.csv',
        'colors': {0: '#5B8DB8', 1: '#D96459'},
        'legend': {0: '簇0 低密度路网（外围/背景）',
                   1: '簇1 高密度路网（城市核心）'},
        'title': '江苏空气质量站点 · 道路环境聚类（K=2）',
    },
    '日变化模式': {
        'csv': '聚类结果_日变化模式.csv',
        'colors': {0: '#67000D', 1: '#A50F15', 2: '#EF3B2C', 3: '#FB6A4A', 4: '#FCBBA1'},
        'legend': {0: '簇0 NO₂ 最高（夜间逆温累积）',
                   1: '簇1 NO₂ 较高', 2: '簇2 NO₂ 中等',
                   3: '簇3 NO₂ 较低', 4: '簇4 NO₂ 最低（相对清洁）'},
        'title': '江苏空气质量站点 · NO₂ 日变化模式聚类（K=5）',
    },
}

# 13 个地级市（用于标签）
PREFECTURES = ['南京', '无锡', '徐州', '常州', '苏州', '南通', '连云港',
               '淮安', '盐城', '扬州', '镇江', '泰州', '宿迁']

WIDTH = 1100.0
MARGIN = 40.0


# ---------------- WKB / GPKG 几何解析（同 03） ----------------

def parse_geom(blob):
    if blob[0:2] != b'GP':
        return []
    flags = blob[3]
    env_ind = (flags >> 1) & 0x07
    env_doubles = {0: 0, 1: 4, 2: 6, 3: 6, 4: 8}.get(env_ind, 0)
    off = 8 + env_doubles * 8
    if off >= len(blob):
        return []
    lines = []

    def read_linestring(dim):
        nonlocal off
        b = blob[off]
        off += 1
        e = '<' if b == 1 else '>'
        struct.unpack_from(e + 'I', blob, off)[0]
        off += 4
        n = struct.unpack_from(e + 'I', blob, off)[0]
        off += 4
        pts = []
        for _ in range(n):
            x, y = struct.unpack_from(e + 'dd', blob, off)
            off += 16
            if dim == 3:
                off += 8
            pts.append((x, y))
        return pts

    bo = blob[off]
    off += 1
    endian = '<' if bo == 1 else '>'
    gtype = struct.unpack_from(endian + 'I', blob, off)[0]
    off += 4
    dim = 2
    if gtype in (1002, 1005):
        dim = 3
        gtype -= 1000
    elif gtype in (2002, 2005):
        dim = 3
        gtype -= 2000
    if gtype == 2:
        lines.append(read_linestring(dim))
    elif gtype == 5:
        n = struct.unpack_from(endian + 'I', blob, off)[0]
        off += 4
        for _ in range(n):
            lines.append(read_linestring(dim))
    return lines


# ---------------- 投影与画布 ----------------

def build_transform(min_x, min_y, max_x, max_y):
    """UTM(米) -> SVG 像素。北朝上，故 y 反向。"""
    aspect = (max_x - min_x) / (max_y - min_y)
    height = WIDTH / aspect
    def f(x, y):
        px = MARGIN + (x - min_x) / (max_x - min_x) * (WIDTH - 2 * MARGIN)
        py = MARGIN + (max_y - y) / (max_y - min_y) * (height - 2 * MARGIN)
        return px, py
    return f, height


def svg_polyline(points, transform, color, width, opacity, min_px=0.8):
    """生成 polyline，并抽稀间距小于 min_px 的相邻点，减小文件体积。"""
    parts = []
    last = None
    for (x, y) in points:
        px, py = transform(x, y)
        if last is not None and (px - last[0]) ** 2 + (py - last[1]) ** 2 < min_px * min_px:
            continue
        parts.append(f'{px:.1f},{py:.1f}')
        last = (px, py)
    if len(parts) < 2:
        return ''
    return (f'<polyline points="{" ".join(parts)}" fill="none" '
            f'stroke="{color}" stroke-width="{width}" opacity="{opacity}"/>')


def main():
    # ---- 站点（含 UTM 坐标）与簇标签 ----
    utm = {}
    city_pts = {}
    with open(ROAD_CSV, encoding='utf-8-sig') as fh:
        for r in csv.DictReader(fh):
            utm[r['站点编码']] = (float(r['UTM_X']), float(r['UTM_Y']))
            city = r['城市']
            if city in PREFECTURES:
                city_pts.setdefault(city, []).append((float(r['UTM_X']), float(r['UTM_Y'])))

    # 画布范围：用道路 bbox（覆盖全省）
    con = sqlite3.connect(GPKG)
    min_x, min_y, max_x, max_y = con.execute(
        "SELECT min_x, min_y, max_x, max_y FROM gpkg_contents WHERE table_name='roads_all'"
    ).fetchone()
    transform, height = build_transform(min_x, min_y, max_x, max_y)

    # ---- 道路底图（抽样）----
    def road_lines(sql):
        out = []
        for (blob,) in con.execute(sql):
            for line in parse_geom(blob):
                if len(line) >= 2:
                    out.append(line)
        return out

    print('读取道路底图 ...')
    bg_lines = road_lines("SELECT geom FROM roads_all WHERE rowid % 25 = 0")
    mw_lines = road_lines("SELECT geom FROM roads_motorway WHERE rowid % 4 = 0")
    con.close()
    print(f'  底图线段 {len(bg_lines)} 条，高速 {len(mw_lines)} 条')

    svgs = {}
    for task, cfg in TASKS.items():
        # 读簇标签
        labels = {}
        with open(find(cfg['csv'], desc=f'{task} 聚类结果'), encoding='utf-8-sig') as fh:
            for r in csv.DictReader(fh):
                labels[r['站点编码']] = int(r['簇'])

        body = []
        # 底图
        for line in bg_lines:
            body.append(svg_polyline(line, transform, '#d0d4d8', 0.6, 1.0))
        for line in mw_lines:
            body.append(svg_polyline(line, transform, '#a8adb3', 1.1, 1.0))

        # 站点散点
        for code, lab in labels.items():
            if code not in utm:
                continue
            px, py = transform(*utm[code])
            color = cfg['colors'].get(lab, '#000')
            body.append(
                f'<circle cx="{px:.1f}" cy="{py:.1f}" r="7" fill="{color}" '
                f'stroke="white" stroke-width="1.2">'
                f'<title>{code}</title></circle>')

        # 城市标签
        for city, pts in city_pts.items():
            cx = sum(p[0] for p in pts) / len(pts)
            cy = sum(p[1] for p in pts) / len(pts)
            px, py = transform(cx, cy)
            body.append(
                f'<text x="{px:.1f}" y="{py:.1f}" font-size="15" font-weight="600" '
                f'fill="#333" text-anchor="middle" font-family="sans-serif">{city}</text>')

        # 图例
        lx = WIDTH - 360
        ly = MARGIN + 14
        body.append(f'<text x="{MARGIN}" y="{MARGIN}" font-size="20" font-weight="700" '
                    f'fill="#222" font-family="sans-serif">{cfg["title"]}</text>')
        body.append(f'<rect x="{lx}" y="{MARGIN}" width="330" height="{22 + 24*len(cfg["legend"])}" '
                    f'fill="white" stroke="#ccc" rx="6"/>')
        for lab, text in cfg['legend'].items():
            body.append(f'<circle cx="{lx + 14}" cy="{ly}" r="7" fill="{cfg["colors"][lab]}"/>')
            body.append(f'<text x="{lx + 30}" y="{ly + 4}" font-size="13" '
                        f'fill="#333" font-family="sans-serif">{text}</text>')
            ly += 24

        svg = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" '
               f'height="{height:.0f}" viewBox="0 0 {WIDTH} {height:.0f}" '
               f'font-family="sans-serif">'
               f'<rect width="{WIDTH}" height="{height:.0f}" fill="#f6f8fa"/>'
               + ''.join(body) + '</svg>')
        svgs[task] = svg
        out = path(f'地图_{task}.svg')
        with open(out, 'w', encoding='utf-8') as fh:
            fh.write(svg)
        print(f'已生成 {out}')

    # ---- 汇总 HTML ----
    html = ['<!DOCTYPE html><html lang="zh"><head><meta charset="utf-8">'
            '<title>江苏站点聚类地图</title><style>'
            'body{font-family:sans-serif;background:#eee;margin:16px}'
            '.card{background:#fff;margin:16px 0;padding:8px;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.2)}'
            'img{width:100%;height:auto;display:block}'
            '</style></head><body><h2>江苏省空气质量站点数据挖掘 · 聚类结果地图</h2>']
    for task in TASKS:
        html.append(f'<div class="card"><img src="地图_{task}.svg" alt="{task}"></div>')
    html.append('</body></html>')
    out_html = path('地图_汇总.html')
    # newline='' 让换行固定为 LF，避免同一脚本在 Windows 写出 CRLF、
    # 在 Linux 写出 LF，保证任何机器上重跑的 html 逐字节一致
    with open(out_html, 'w', encoding='utf-8', newline='') as fh:
        fh.write('\n'.join(html))
    print(f'已生成 {out_html}')


if __name__ == '__main__':
    main()
