# -*- coding: utf-8 -*-
"""江苏空气质量站点 × 道路网络叠加分析"""
import csv, math, os, sqlite3, struct, sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from paths import find, path


def arg_value(flag):
    """取命令行参数 --flag=值 或 --flag 值 中的值；未给出返回 None。"""
    for i, a in enumerate(sys.argv):
        if a.startswith(flag + '='):
            return a.split('=', 1)[1]
        if a == flag and i + 1 < len(sys.argv):
            return sys.argv[i + 1]
    return None


# 输入/输出路径由 paths 解析，与当前工作目录无关
# 道路网络数据很大、常放在项目目录之外，可用 --gpkg 显式指定：
#   python 03_spatial_overlay.py --gpkg "D:/数据/jiangsu_roads_clean.gpkg"
# 未指定时按 paths 的搜索规则（项目根目录 → data/ → scripts/ → 当前目录）查找
GPKG_ARG = arg_value('--gpkg')
GPKG = find(GPKG_ARG or 'jiangsu_roads_clean.gpkg',
            desc='道路网络 GeoPackage（可用 --gpkg 指定路径）')
STATION_XLSX = find('站点列表-2025.02.25起.xlsx', desc='全国站点列表 xlsx')
OUT = path('站点-道路叠加分析.csv')

# ---------------- UTM 投影 (WGS84 -> UTM zone 50N) ----------------
A = 6378137.0
F = 1/298.257223563
E2 = F*(2-F)
EP2 = E2/(1-E2)
K0 = 0.9996
ZONE = 50
LON0 = math.radians((ZONE-1)*6 - 180 + 3)   # 117°E
E0 = 500000.0

def utm(lon, lat):
    phi = math.radians(lat)
    lam = math.radians(lon)
    N = A/math.sqrt(1-E2*math.sin(phi)**2)
    T = math.tan(phi)**2
    C = EP2*math.cos(phi)**2
    Aang = math.cos(phi)*(lam-LON0)
    M = A*((1-E2/4-3*E2**2/64-5*E2**3/256)*phi
           -(3*E2/8+3*E2**2/32+45*E2**3/1024)*math.sin(2*phi)
           +(15*E2**2/256+45*E2**3/1024)*math.sin(4*phi)
           -(35*E2**3/3072)*math.sin(6*phi))
    E = E0 + K0*N*(Aang+(1-T+C)*Aang**3/6+(5-18*T+T**2+72*C-58*EP2)*Aang**5/120)
    Nor = K0*(M+N*math.tan(phi)*(Aang**2/2+(5-T+9*C+4*C**2)*Aang**4/24
           +(61-58*T+T**2+600*C-330*EP2)*Aang**6/720))
    return E, Nor

# ---------------- WKB / GPKG 几何解析 ----------------
def parse_geom(blob):
    if blob[0:2] != b'GP':
        return []
    flags = blob[3]
    env_ind = (flags >> 1) & 0x07
    env_doubles = {0:0, 1:4, 2:6, 3:6, 4:8}.get(env_ind, 0)
    off = 8 + env_doubles*8
    if off >= len(blob):
        return []
    lines = []
    def read_linestring(dim):
        nonlocal off
        b = blob[off]; off += 1
        e = '<' if b == 1 else '>'
        t = struct.unpack_from(e+'I', blob, off)[0]; off += 4
        n = struct.unpack_from(e+'I', blob, off)[0]; off += 4
        pts = []
        for _ in range(n):
            x, y = struct.unpack_from(e+'dd', blob, off); off += 16
            if dim == 3:
                off += 8  # 跳过 z
            pts.append((x, y))
        return pts
    bo = blob[off]; off += 1
    endian = '<' if bo == 1 else '>'
    gtype = struct.unpack_from(endian+'I', blob, off)[0]; off += 4
    dim = 2
    if gtype in (1002, 1005):
        dim = 3
        gtype -= 1000
    elif gtype in (2002, 2005):
        dim = 3  # 有 M，跳过
        gtype -= 2000
    if gtype == 2:
        lines.append(read_linestring(dim))
    elif gtype == 5:
        n = struct.unpack_from(endian+'I', blob, off)[0]; off += 4
        for _ in range(n):
            lines.append(read_linestring(dim))
    return lines

# ---------------- 几何计算 ----------------
def min_dist_to_lines(cx, cy, lines):
    best = float('inf')
    for line in lines:
        for (ax, ay), (bx, by) in zip(line, line[1:]):
            dx = bx-ax; dy = by-ay
            L2 = dx*dx+dy*dy
            if L2 == 0:
                d = math.hypot(cx-ax, cy-ay)
            else:
                t = ((cx-ax)*dx+(cy-ay)*dy)/L2
                if t < 0: t = 0.0
                elif t > 1: t = 1.0
                qx = ax+t*dx; qy = ay+t*dy
                d = math.hypot(cx-qx, cy-qy)
            if d < best:
                best = d
    return best

def seg_in_circle(ax, ay, bx, by, cx, cy, R):
    dx = bx-ax; dy = by-ay
    L2 = dx*dx+dy*dy
    if L2 == 0:
        return 0.0
    L = math.sqrt(L2)
    fx = ax-cx; fy = ay-cy
    a = L2
    b = 2*(fx*dx+fy*dy)
    c = fx*fx+fy*fy-R*R
    disc = b*b-4*a*c
    if disc < 0:
        return L if (fx*fx+fy*fy) <= R*R else 0.0
    sq = math.sqrt(disc)
    t1 = (-b-sq)/(2*a)
    t2 = (-b+sq)/(2*a)
    lo = 0.0 if t1 < 0 else t1
    hi = 1.0 if t2 > 1 else t2
    return max(0.0, hi-lo)*L

def len_in_circle(cx, cy, R, lines):
    total = 0.0
    for line in lines:
        for (ax, ay), (bx, by) in zip(line, line[1:]):
            total += seg_in_circle(ax, ay, bx, by, cx, cy, R)
    return total

# ---------------- 数据库 ----------------
print('道路数据:', GPKG)
con = sqlite3.connect(GPKG)

def rtree_query(cx, cy, R):
    q = ('SELECT id FROM rtree_roads_all_geom '
         'WHERE minx<=? AND maxx>=? AND miny<=? AND maxy>=?')
    return [r[0] for r in con.execute(q, (cx+R, cx-R, cy+R, cy-R))]

def load(ids, cache):
    missing = [i for i in ids if i not in cache]
    if missing:
        for i in range(0, len(missing), 500):
            chunk = missing[i:i+500]
            q = ('SELECT fid, geom, road_class, name FROM roads_all '
                 'WHERE fid IN (%s)' % ','.join('?'*len(chunk)))
            for fid, geom, rc, name in con.execute(q, chunk):
                cache[fid] = (parse_geom(geom), rc, name)
    return [cache[i] for i in ids]

CLASSES = ['高速/快速路', '主干道', '次干/支路', '服务性道路', '其他']
MAJOR = {'高速/快速路', '主干道'}

# ---------------- 站点 ----------------
stations = []
import zipfile
from xml.etree import ElementTree as ET
z = zipfile.ZipFile(STATION_XLSX)
NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ss = ET.fromstring(z.read('xl/sharedStrings.xml'))
shared = [''.join(t.text or '' for t in si.iter(f'{{{NS}}}t')) for si in ss.iter(f'{{{NS}}}si')]
root = ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
js_cities = {'南京','无锡','徐州','常州','苏州','南通','连云港','淮安','盐城','扬州','镇江','泰州','宿迁',
             '昆山','张家港','太仓','常熟','吴江','江阴','宜兴','金坛','溧阳','句容','海门'}
for row in root.iter(f'{{{NS}}}row'):
    cells = {}
    for c in row.findall(f'{{{NS}}}c'):
        ref = c.get('r'); col = ''.join(ch for ch in ref if ch.isalpha())
        t = c.get('t'); v = c.find(f'{{{NS}}}v')
        val = ''
        if v is not None:
            val = v.text or ''
            if t == 's':
                val = shared[int(val)]
        cells[col] = val
    code = cells.get('A','')
    if code and code != '监测点编码' and cells.get('C','') in js_cities:
        stations.append((code, cells.get('B',''), cells.get('C',''),
                         float(cells.get('D','0')), float(cells.get('E','0'))))

print('江苏站点数:', len(stations))

def nearest(cx, cy, cache, major_only):
    R = 500.0
    seen = set()
    best = None
    while R <= 200000.0:
        ids = rtree_query(cx, cy, R)
        new = [i for i in ids if i not in seen]
        seen.update(ids)
        if new:
            for lines, rc, name in load(new, cache):
                if major_only and rc not in MAJOR:
                    continue
                d = min_dist_to_lines(cx, cy, lines)
                if best is None or d < best[0]:
                    best = (d, rc, name)
        if best is not None and best[0] < R:
            break
        R *= 2
    return best

rows = []
for idx, (code, name, city, lon, lat) in enumerate(stations, 1):
    cx, cy = utm(lon, lat)
    cache = {}
    # 最近道路
    b_any = nearest(cx, cy, cache, major_only=False)
    # 最近主干(高速/快速路 + 主干道)
    b_maj = nearest(cx, cy, cache, major_only=True)
    # 缓冲区内道路长度(500/1000/2000m, 分等级)
    buf = {R: {c: 0.0 for c in CLASSES} for R in (500, 1000, 2000)}
    for lines, rc, _ in load(rtree_query(cx, cy, 2000), cache):
        cls = rc if rc in CLASSES else '其他'
        for R in (500, 1000, 2000):
            buf[R][cls] += len_in_circle(cx, cy, R, lines)
    row = {
        '站点编码': code, '站点名称': name, '城市': city,
        '经度': lon, '纬度': lat,
        'UTM_X': round(cx, 1), 'UTM_Y': round(cy, 1),
        '最近道路距离_m': (round(b_any[0], 1) if b_any else ''),
        '最近道路等级': (b_any[1] if b_any else ''),
        '最近道路名称': (b_any[2] if b_any else ''),
        '最近主干距离_m': (round(b_maj[0], 1) if b_maj else ''),
    }
    for R in (500, 1000, 2000):
        prefix = f'{R}m'
        row[f'{prefix}内总长_m'] = round(sum(buf[R].values()), 1)
        for cls in CLASSES:
            row[f'{prefix}_{cls}_m'] = round(buf[R][cls], 1)
    rows.append(row)
    if idx % 20 == 0:
        print(f'  已处理 {idx}/{len(stations)}')

# ---------------- 输出 ----------------
cols = ['站点编码','站点名称','城市','经度','纬度','UTM_X','UTM_Y',
        '最近道路距离_m','最近道路等级','最近道路名称','最近主干距离_m']
for R in (500, 1000, 2000):
    cols.append(f'{R}m内总长_m')
    for cls in CLASSES:
        cols.append(f'{R}m_{cls}_m')
with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
    w = csv.DictWriter(fh, fieldnames=cols)
    w.writeheader()
    for row in rows:
        w.writerow(row)
print('已输出:', OUT, '共', len(rows), '行')
con.close()
