# -*- coding: utf-8 -*-
"""
步骤 10：异常检测。

用两种互补方法找出“与众不同”的站点：
  1. 单变量稳健 z 分数（MAD）：对每种污染物全年均值计算基于中位数/MAD 的稳健 z 分数，
     任一项 |z| > 3 即视为该项异常（对单个极值不敏感，适合有缺测/极值的环境数据）。
  2. 多变量 k 近邻距离（k=5）：把 6 污染物均值标准化后在特征空间里算每个站点到
     其 5 个最近邻的平均距离，用 Tukey 上界（Q3 + 1.5×IQR）标出离群站。

输入：
  - 江苏站点_24h特征.csv    6 污染物全年均值
  - 站点-道路叠加分析.csv    站点名称/城市/经纬度

输出：
  - 异常站点.csv   站点 + 各污染物 MAD-z + 是否单变量异常 + kNN 距离 + 是否多变量异常
"""
import csv
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dm_lib import mad, knn_distance, zscore_matrix
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
FEAT24 = find('江苏站点_24h特征.csv', desc='步骤 8 产出的 24h 特征')
ROAD_CSV = find('站点-道路叠加分析.csv', desc='步骤 3 产出的站点-道路叠加表')
OUT = path('异常站点.csv')
POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
MAD_THRESHOLD = 3.0
KNN_K = 5


def read_csv_dict(path):
    with open(path, encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def main():
    feat = {r['站点编码']: r for r in read_csv_dict(FEAT24)}
    road = {r['站点编码']: r for r in read_csv_dict(ROAD_CSV)}

    # 有效站点（≥1000 记录且 6 污染物齐全）
    codes = []
    for code, f in feat.items():
        if int(f['有效记录数']) < 1000:
            continue
        if any(num(f[f'{p}_mean']) is None for p in POLLUTANTS):
            continue
        codes.append(code)
    codes.sort()
    print(f'有效站点数: {len(codes)}')

    # ---- 1. 单变量 MAD 稳健 z 分数 ----
    mad_z = {p: {} for p in POLLUTANTS}
    for p in POLLUTANTS:
        vals = [num(feat[c][f'{p}_mean']) for c in codes]
        zs = mad(vals)
        for c, z in zip(codes, zs):
            mad_z[p][c] = z

    # ---- 2. 多变量 kNN 距离 ----
    data = [[num(feat[c][f'{p}_mean']) for p in POLLUTANTS] for c in codes]
    Z = zscore_matrix(data)
    dists = knn_distance(Z, k=KNN_K)
    # 用分位数函数：Q3 = 75 百分位
    s = sorted(dists)
    def quantile(a, q):
        n = len(a)
        idx = q * (n - 1)
        lo = int(idx)
        hi = min(lo + 1, n - 1)
        frac = idx - lo
        return a[lo] * (1 - frac) + a[hi] * frac
    q3 = quantile(s, 0.75)
    iqr = quantile(s, 0.75) - quantile(s, 0.25)
    upper = q3 + 1.5 * iqr

    rows = []
    for i, c in enumerate(codes):
        uni_flags = [p for p in POLLUTANTS if abs(mad_z[p][c]) > MAD_THRESHOLD]
        is_multi = dists[i] > upper
        r = road.get(c, {})
        row = {
            '站点编码': c,
            '站点名称': r.get('站点名称', ''),
            '城市': r.get('城市', ''),
            '经度': r.get('经度', ''),
            '纬度': r.get('纬度', ''),
        }
        for p in POLLUTANTS:
            row[f'{p}_MADz'] = round(mad_z[p][c], 2)
        row['单变量异常项'] = '+'.join(uni_flags) if uni_flags else ''
        row['是否单变量异常'] = '是' if uni_flags else '否'
        row['kNN距离'] = round(dists[i], 3)
        row['是否多变量异常'] = '是' if is_multi else '否'
        rows.append(row)

    # 按 kNN 距离降序，方便查看最异常的站
    rows.sort(key=lambda x: -x['kNN距离'])

    cols = (['站点编码', '站点名称', '城市', '经度', '纬度']
            + [f'{p}_MADz' for p in POLLUTANTS]
            + ['单变量异常项', '是否单变量异常', 'kNN距离', '是否多变量异常'])
    with open(OUT, 'w', newline='', encoding='utf-8-sig') as fh:
        w = csv.DictWriter(fh, fieldnames=cols)
        w.writeheader()
        for row in rows:
            w.writerow(row)

    n_uni = sum(1 for r in rows if r['是否单变量异常'] == '是')
    n_multi = sum(1 for r in rows if r['是否多变量异常'] == '是')
    print(f'已生成 {OUT}')
    print(f'单变量异常站点数: {n_uni}')
    print(f'多变量异常站点数: {n_multi}')
    print(f'kNN 距离上界 (Q3+1.5IQR): {round(upper, 3)}')


if __name__ == '__main__':
    main()
