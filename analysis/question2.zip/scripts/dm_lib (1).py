# -*- coding: utf-8 -*-
"""
纯 Python 数据挖掘工具库（无 numpy/scipy/sklearn，仅标准库）。

包含：
  - 描述统计：mean / std / median
  - 标准化：zscore（单列）、zscore_matrix（逐列）
  - 聚类：kmeans（k-means++ 初始化、多次重启）、silhouette（轮廓系数）
  - 降维：pca（协方差矩阵 + 幂迭代法求主成分）
  - 关联规则：apriori（先验算法）、association_rules（生成规则，含置信度/提升度）
  - 异常检测：mad（稳健 z 分数，基于中位数与 MAD）、knn_distance（k 近邻平均距离）
"""
import math
import random
from itertools import combinations


# ---------------- 描述统计 ----------------

def mean(x):
    return sum(x) / len(x) if x else 0.0


def std(x, ddof=1):
    n = len(x)
    if n < 2:
        return 0.0
    m = mean(x)
    return math.sqrt(sum((v - m) ** 2 for v in x) / (n - ddof))


def median(x):
    n = len(x)
    if n == 0:
        return 0.0
    s = sorted(x)
    if n % 2 == 1:
        return s[n // 2]
    return (s[n // 2 - 1] + s[n // 2]) / 2.0


def quantile(a, q):
    """线性插值的 q 分位数（q∈[0,1]）。"""
    s = sorted(a)
    n = len(s)
    if n == 0:
        return 0.0
    if n == 1:
        return s[0]
    idx = q * (n - 1)
    lo = int(idx)
    hi = min(lo + 1, n - 1)
    frac = idx - lo
    return s[lo] * (1 - frac) + s[hi] * frac


def skew(a):
    """样本偏度（Fisher-Pearson 调整，对称分布=0）。"""
    n = len(a)
    if n < 3:
        return 0.0
    m = mean(a)
    s = std(a)
    if s == 0:
        return 0.0
    z3 = sum(((x - m) / s) ** 3 for x in a)
    return n / ((n - 1) * (n - 2)) * z3


def kurtosis(a):
    """超额峰度（Fisher，正态分布=0，正值=尖峰厚尾）。"""
    n = len(a)
    if n < 4:
        return 0.0
    m = mean(a)
    s = std(a)
    if s == 0:
        return 0.0
    z4 = sum(((x - m) / s) ** 4 for x in a)
    return (n * (n + 1) / ((n - 1) * (n - 2) * (n - 3))) * z4 \
        - 3 * (n - 1) ** 2 / ((n - 2) * (n - 3))


# ---------------- 标准化 ----------------

def zscore(x):
    """返回列表 x 的 z 分数（(x-均值)/标准差）。方差为 0 时返回全 0。"""
    m = mean(x)
    s = std(x)
    if s == 0:
        return [0.0] * len(x)
    return [(v - m) / s for v in x]


def zscore_matrix(data):
    """按列标准化矩阵 data（list of rows），返回新矩阵。"""
    n = len(data)
    d = len(data[0])
    out = [[0.0] * d for _ in range(n)]
    for j in range(d):
        col = [data[i][j] for i in range(n)]
        z = zscore(col)
        for i in range(n):
            out[i][j] = z[i]
    return out


# ---------------- 距离 ----------------

def euclid(a, b):
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


# ---------------- K-means 聚类 ----------------

def kmeans(data, k, restarts=20, max_iter=200, seed=42):
    """
    K-means 聚类（k-means++ 初始化 + 多次随机重启取最优）。

    返回 (labels, centers, sse)：
      labels  : 每个样本的簇编号
      centers : 簇中心（标准化空间）
      sse     : 簇内平方和（inertia）
    """
    rng = random.Random(seed)
    n = len(data)
    d = len(data[0])
    best = None

    for _ in range(restarts):
        # k-means++ 初始化：第一个中心随机，其余按“距最近中心距离平方”加权抽取
        centers = [data[rng.randrange(n)][:]]
        for _ in range(k - 1):
            ds = [min(euclid(p, c) ** 2 for c in centers) for p in data]
            total = sum(ds)
            if total <= 0:
                centers.append(data[rng.randrange(n)][:])
                continue
            r = rng.random() * total
            acc = 0.0
            idx = n - 1
            for i, dist in enumerate(ds):
                acc += dist
                if acc >= r:
                    idx = i
                    break
            centers.append(data[idx][:])

        labels = [0] * n
        for _ in range(max_iter):
            changed = False
            for i, p in enumerate(data):
                new = min(range(k), key=lambda c: euclid(p, centers[c]))
                if new != labels[i]:
                    labels[i] = new
                    changed = True
            sums = [[0.0] * d for _ in range(k)]
            counts = [0] * k
            for i, p in enumerate(data):
                c = labels[i]
                counts[c] += 1
                for j in range(d):
                    sums[c][j] += p[j]
            for c in range(k):
                if counts[c]:
                    centers[c] = [sums[c][j] / counts[c] for j in range(d)]
            if not changed:
                break

        sse = sum(euclid(p, centers[labels[i]]) ** 2 for i, p in enumerate(data))
        if best is None or sse < best[0]:
            best = (sse, labels, centers)

    return best[1], best[2], best[0]


def silhouette(data, labels, k):
    """
    平均轮廓系数（-1 ~ 1，越大聚类越紧凑且分离）。
    """
    n = len(data)
    if k < 2 or k >= n:
        return 0.0
    members = [[] for _ in range(k)]
    for i, l in enumerate(labels):
        members[l].append(i)

    a = [0.0] * n
    b = [float('inf')] * n
    for i in range(n):
        li = labels[i]
        if len(members[li]) > 1:
            a[i] = sum(euclid(data[i], data[j]) for j in members[li] if j != i) \
                   / (len(members[li]) - 1)
        for c in range(k):
            if c == li:
                continue
            d = sum(euclid(data[i], data[j]) for j in members[c]) / len(members[c])
            if d < b[i]:
                b[i] = d

    s = 0.0
    for i in range(n):
        denom = max(a[i], b[i])
        if denom > 0:
            s += (b[i] - a[i]) / denom
    return s / n


# ---------------- PCA 主成分分析 ----------------

def pca(data, k):
    """
    主成分分析：对列中心化后的协方差矩阵用幂迭代法求前 k 个主成分。

    返回 (scores, components, mean_vec, var_ratio)：
      scores     : 每个样本在前 k 主成分上的得分（n×k）
      components : 每个主成分的载荷向量（k×d）
      mean_vec   : 各列原始均值
      var_ratio  : 各主成分解释的方差占总方差（trace）的比例
    """
    n = len(data)
    d = len(data[0])
    mean_vec = [sum(row[j] for row in data) / n for j in range(d)]
    X = [[row[j] - mean_vec[j] for j in range(d)] for row in data]

    # 协方差矩阵 C = X^T X / (n-1)
    cov = [[sum(X[i][a] * X[i][b] for i in range(n)) / (n - 1)
            for b in range(d)] for a in range(d)]
    total_var = sum(cov[j][j] for j in range(d))

    components = []
    evals = []
    rng = random.Random(0)
    for _ in range(k):
        v = [rng.random() for _ in range(d)]
        norm = math.sqrt(sum(x * x for x in v)) or 1.0
        v = [x / norm for x in v]
        for _ in range(500):
            w = [sum(cov[i][j] * v[j] for j in range(d)) for i in range(d)]
            nw = math.sqrt(sum(x * x for x in w))
            if nw < 1e-15:
                break
            w = [x / nw for x in w]
            diff = sum(abs(w[i] - v[i]) for i in range(d))
            v = w
            if diff < 1e-13:
                break
        lam = sum(v[i] * sum(cov[i][j] * v[j] for j in range(d)) for i in range(d))
        evals.append(lam)
        components.append(v)
        # 收缩（deflation），去掉已提取的成分
        cov = [[cov[i][j] - lam * v[i] * v[j] for j in range(d)] for i in range(d)]

    scores = [[sum(X[i][j] * components[c][j] for j in range(d))
               for c in range(k)] for i in range(n)]
    var_ratio = [e / total_var for e in evals] if total_var > 0 else [0.0] * k
    return scores, components, mean_vec, var_ratio


# ---------------- 关联规则（Apriori） ----------------

def _count_support(transactions, itemset):
    return sum(1 for t in transactions if itemset <= t)


def apriori(transactions, min_support):
    """
    先验（Apriori）算法挖掘频繁项集。

    transactions : list of set/frozenset（每个样本是一组“项”）
    min_support  : 最小支持度（0~1）
    返回 [[(itemset, support), ...], ...]，按项集大小分层。
    """
    n = len(transactions)
    result = []

    # 1-项集
    cnt = {}
    for t in transactions:
        for it in t:
            cnt[it] = cnt.get(it, 0) + 1
    Lk = sorted(frozenset([it]) for it in cnt if cnt[it] / n >= min_support)

    while Lk:
        result.append([(s, _count_support(transactions, s) / n) for s in Lk])
        k = len(next(iter(Lk)))
        # 候选生成：两个频繁 k-项集共享前 k-1 个元素则拼接
        cand = set()
        Lk_list = [sorted(list(s)) for s in Lk]
        for i in range(len(Lk_list)):
            for j in range(i + 1, len(Lk_list)):
                a, b = Lk_list[i], Lk_list[j]
                if a[:-1] == b[:-1]:
                    cand.add(frozenset(a + [b[-1]]))
        # 剪枝：所有 k-子集必须频繁；再数支持度
        Lk_set = set(Lk)
        pruned = []
        for c in cand:
            subs = [frozenset(s) for s in combinations(c, k)]
            if all(s in Lk_set for s in subs) and \
                    _count_support(transactions, c) / n >= min_support:
                pruned.append(c)
        Lk = sorted(pruned)

    return result


def association_rules(transactions, freq_itemsets, min_confidence):
    """
    由频繁项集生成关联规则。

    返回 [dict(antecedent, consequent, support, confidence, lift), ...]，
    按提升度降序排列。
    """
    n = len(transactions)
    support_of = {}
    for level in freq_itemsets:
        for itemset, supp in level:
            support_of[itemset] = supp

    rules = []
    for level in freq_itemsets:
        for itemset, supp in level:
            if len(itemset) < 2:
                continue
            items = list(itemset)
            for r in range(1, len(items)):
                for ant in combinations(items, r):
                    ant = frozenset(ant)
                    cons = itemset - ant
                    conf = supp / support_of[ant] if support_of[ant] > 0 else 0.0
                    if conf < min_confidence:
                        continue
                    lift = conf / support_of[cons] if support_of[cons] > 0 else 0.0
                    rules.append({
                        'antecedent': ant,
                        'consequent': cons,
                        'support': supp,
                        'confidence': conf,
                        'lift': lift,
                    })
    rules.sort(key=lambda x: -x['lift'])
    return rules


# ---------------- 异常检测 ----------------

def mad(x):
    """稳健 z 分数：(0.6745*(x-中位数)/MAD)。对单点异常不敏感。"""
    n = len(x)
    med = median(x)
    mad_v = median([abs(v - med) for v in x])
    if mad_v == 0:
        # MAD 为 0 时退化为普通 z 分数
        m = mean(x)
        s = std(x)
        return [(v - m) / s if s > 0 else 0.0 for v in x]
    return [0.6745 * (v - med) / mad_v for v in x]


def knn_distance(data, k=5):
    """返回每个点到其 k 个最近邻的平均欧氏距离（越大越可能是离群点）。"""
    n = len(data)
    out = []
    for i in range(n):
        ds = sorted(euclid(data[i], data[j]) for j in range(n) if j != i)
        out.append(sum(ds[:k]) / k)
    return out
