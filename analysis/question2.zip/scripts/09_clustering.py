# -*- coding: utf-8 -*-
"""
步骤 9：聚类分析（数据挖掘主方法）。

三套聚类，全部用 K-means（k-means++ 初始化、多次重启），K 用轮廓系数在 2~5 之间选取：
  A. 污染画像聚类：6 种污染物全年均值（识别站点污染类型）
  B. 道路环境聚类：11 个道路变量（识别站点周边道路密度类型）
  C. 日变化模式聚类：NO2 的 24 小时曲线 → PCA 降维 → K-means（识别交通/背景日变化形态）

输入：
  - 江苏站点_24h特征.csv        步骤 8 产出
  - 站点-道路叠加分析.csv        步骤 3 产出（含经纬度、城市、道路变量）

输出：
  - 聚类_轮廓系数.csv            各任务各 K 的轮廓系数（选 K 依据）
  - 聚类结果_污染画像.csv        站点 + 簇标签 + 6 污染物原始均值
  - 聚类结果_道路环境.csv        站点 + 簇标签 + 11 道路原始变量
  - 聚类结果_日变化模式.csv      站点 + 簇标签 + NO2 24h 曲线 + PCA 得分
  - 聚类_簇中心.csv              各任务各簇在原始单位的特征均值
  - 聚类_交叉表_污染x道路.csv    两套簇标签的列联表
"""
import csv
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from dm_lib import (zscore_matrix, kmeans, silhouette, pca, mean)
from paths import find, path

# 输入/输出路径由 paths 解析，与当前工作目录无关
FEAT24 = find('江苏站点_24h特征.csv', desc='步骤 8 产出的 24h 特征')
ROAD_CSV = find('站点-道路叠加分析.csv', desc='步骤 3 产出的站点-道路叠加表')

OUT_SIL = path('聚类_轮廓系数.csv')
OUT_CENTER = path('聚类_簇中心.csv')
OUT_CROSS = path('聚类_交叉表_污染x道路.csv')

POLLUTANTS = ['PM2.5', 'PM10', 'SO2', 'NO2', 'O3', 'CO']
ROAD_FEATURES = [
    '最近道路距离_m', '最近主干距离_m',
    '500m_高速/快速路_m', '500m_主干道_m', '500m_次干/支路_m',
    '1000m_高速/快速路_m', '1000m_主干道_m', '1000m_次干/支路_m',
    '2000m_高速/快速路_m', '2000m_主干道_m', '2000m_次干/支路_m',
]


def read_csv_dict(path):
    with open(path, encoding='utf-8-sig') as fh:
        return list(csv.DictReader(fh))


def num(s):
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def valid_stations():
    """返回有完整数据的站点记录（≥1000 条记录 且 6 污染物均值齐全）。"""
    feat = {r['站点编码']: r for r in read_csv_dict(FEAT24)}
    road = {r['站点编码']: r for r in read_csv_dict(ROAD_CSV)}
    out = []
    for code, f in feat.items():
        if int(f['有效记录数']) < 1000:
            continue
        if any(num(f[f'{p}_mean']) is None for p in POLLUTANTS):
            continue
        r = road.get(code, {})
        out.append({
            '站点编码': code,
            '站点名称': r.get('站点名称', ''),
            '城市': r.get('城市', ''),
            '经度': num(r.get('经度', '')),
            '纬度': num(r.get('纬度', '')),
            'feat': f,
            'road': r,
        })
    out.sort(key=lambda x: x['站点编码'])
    return out


def relabel_by_key(labels, k, key):
    """按各簇的 key 均值升序重排簇编号（0=最小,1=次小...），便于解释。"""
    sums = [0.0] * k
    cnt = [0] * k
    for lab, kv in zip(labels, key):
        sums[lab] += kv
        cnt[lab] += 1
    means = [(sums[c] / cnt[c] if cnt[c] else 0.0) for c in range(k)]
    order = sorted(range(k), key=lambda c: means[c])
    remap = {old: new for new, old in enumerate(order)}
    return [remap[lab] for lab in labels]


def pick_k(data, task_name):
    """对标准化后的数据在 K=2..5 上跑 K-means，返回 (最优K, labels, centers, 轮廓记录)。"""
    Z = zscore_matrix(data)
    best = None
    rec = []
    for k in range(2, 6):
        labels, centers, sse = kmeans(Z, k)
        sil = silhouette(Z, labels, k)
        rec.append((k, round(sil, 4)))
        if best is None or sil > best[0]:
            best = (sil, k, labels, centers)
    _, k, labels, centers = best
    print(f'  [{task_name}] 各 K 轮廓系数: {rec} -> 选 K={k}')
    return k, labels, centers, rec


def cluster_centers_original(data_rows, labels, k, feature_names):
    """返回各簇在【原始单位】下的特征均值：list of dict(feature -> 值)。"""
    sums = [[0.0] * len(feature_names) for _ in range(k)]
    cnt = [0] * k
    for row, lab in zip(data_rows, labels):
        cnt[lab] += 1
        for j in range(len(feature_names)):
            sums[lab][j] += row[j]
    out = []
    for c in range(k):
        out.append({fn: round(sums[c][j] / cnt[c], 3) for j, fn in enumerate(feature_names)})
    return out


def main():
    stations = valid_stations()
    n = len(stations)
    print(f'有效站点数: {n}')
    if n < 10:
        print('样本太少，无法聚类。')
        return

    sil_rows = []      # 轮廓系数记录
    center_rows = []   # 簇中心（原始单位）
    results = {}       # 任务 -> labels

    # ---------------- A. 污染画像聚类 ----------------
    pol_rows = [[num(s['feat'][f'{p}_mean']) for p in POLLUTANTS] for s in stations]
    k, labels, _, rec = pick_k(pol_rows, '污染画像')
    labels = relabel_by_key(labels, k, [num(s['feat']['PM2.5_mean']) for s in stations])
    results['污染画像'] = labels
    for kk, ss in rec:
        sil_rows.append({'任务': '污染画像', 'K': kk, '轮廓系数': ss})
    for c, center in enumerate(cluster_centers_original(pol_rows, labels, k, POLLUTANTS)):
        for fn, v in center.items():
            center_rows.append({'任务': '污染画像', '簇': c, '特征': fn, '均值': v})

    # ---------------- B. 道路环境聚类 ----------------
    road_rows = [[num(s['road'][fn]) for fn in ROAD_FEATURES] for s in stations]
    # 剔除任一道路特征缺失的站（理论上 142 站都有，防御性处理）
    road_valid = [(i, r) for i, r in enumerate(road_rows) if all(v is not None for v in r)]
    if len(road_valid) < n:
        print(f'  警告：{n - len(road_valid)} 站缺道路特征，道路聚类样本减少')
    ridx = [i for i, _ in road_valid]
    road_data = [r for _, r in road_valid]
    k, labels, _, rec = pick_k(road_data, '道路环境')
    # 用 1000m 内总路网长度作为“道路密度”排序键
    key1000 = [sum(road_data[i][5:8]) for i in range(len(road_data))]
    labels = relabel_by_key(labels, k, key1000)
    full_labels = [None] * n
    for pos, i in enumerate(ridx):
        full_labels[i] = labels[pos]
    results['道路环境'] = full_labels
    for kk, ss in rec:
        sil_rows.append({'任务': '道路环境', 'K': kk, '轮廓系数': ss})
    for c, center in enumerate(cluster_centers_original(road_data, labels, k, ROAD_FEATURES)):
        for fn, v in center.items():
            center_rows.append({'任务': '道路环境', '簇': c, '特征': fn, '均值': v})

    # ---------------- C. 日变化模式聚类（NO2 24h -> PCA -> K-means） ----------------
    no2_rows = [[num(s['feat'][f'NO2_h{h:02d}']) for h in range(24)] for s in stations]
    scores, comps, _, var_ratio = pca(no2_rows, 2)
    print(f'  [日变化模式] PCA 前2主成分解释方差比: '
          f'{round(var_ratio[0], 3)}, {round(var_ratio[1], 3)}')
    k, labels, _, rec = pick_k(scores, '日变化模式')
    # 排序键：NO2 早高峰(8h) 与夜间(0h) 差值，反映“交通峰”强度
    amp = [num(s['feat']['NO2_h08']) - num(s['feat']['NO2_h00']) for s in stations]
    labels = relabel_by_key(labels, k, amp)
    results['日变化模式'] = labels
    for kk, ss in rec:
        sil_rows.append({'任务': '日变化模式', 'K': kk, '轮廓系数': ss})
    # 簇中心用 NO2 各小时原始均值表示
    no2_names = [f'NO2_h{h:02d}' for h in range(24)]
    for c, center in enumerate(cluster_centers_original(no2_rows, labels, k, no2_names)):
        for fn, v in center.items():
            center_rows.append({'任务': '日变化模式', '簇': c, '特征': fn, '均值': v})

    # ---------------- 输出 ----------------
    def wcsv(out_path, fieldnames, rows):
        with open(out_path, 'w', newline='', encoding='utf-8-sig') as fh:
            w = csv.DictWriter(fh, fieldnames=fieldnames)
            w.writeheader()
            for r in rows:
                w.writerow(r)

    wcsv(OUT_SIL, ['任务', 'K', '轮廓系数'], sil_rows)
    wcsv(OUT_CENTER, ['任务', '簇', '特征', '均值'], center_rows)

    base = ['站点编码', '站点名称', '城市', '经度', '纬度', '簇']
    for task, fname, extra_names, extra_fn in [
        ('污染画像', '聚类结果_污染画像.csv', [f'{p}_mean' for p in POLLUTANTS],
         lambda s: [s['feat'][f'{p}_mean'] for p in POLLUTANTS]),
        ('道路环境', '聚类结果_道路环境.csv', ROAD_FEATURES,
         lambda s: [s['road'][fn] for fn in ROAD_FEATURES]),
        ('日变化模式', '聚类结果_日变化模式.csv', no2_names,
         lambda s: [s['feat'][fn] for fn in no2_names]),
    ]:
        rows = []
        for i, s in enumerate(stations):
            lab = results[task][i]
            if lab is None:
                continue
            row = {'站点编码': s['站点编码'], '站点名称': s['站点名称'],
                   '城市': s['城市'], '经度': s['经度'], '纬度': s['纬度'],
                   '簇': lab}
            for fn, v in zip(extra_names, extra_fn(s)):
                row[fn] = v
            rows.append(row)
        wcsv(path(fname), base + extra_names, rows)
        print(f'已生成 {fname}（{len(rows)} 站）')

    # 交叉表：污染簇 × 道路簇
    cross = {}
    for i, s in enumerate(stations):
        a = results['污染画像'][i]
        b = results['道路环境'][i]
        if b is None:
            continue
        cross[(a, b)] = cross.get((a, b), 0) + 1
    cross_rows = []
    for (a, b), c in sorted(cross.items()):
        cross_rows.append({'污染簇': a, '道路簇': b, '站点数': c})
    wcsv(OUT_CROSS, ['污染簇', '道路簇', '站点数'], cross_rows)
    print('已生成 聚类_交叉表_污染x道路.csv')

    print('聚类分析完成。')


if __name__ == '__main__':
    main()
